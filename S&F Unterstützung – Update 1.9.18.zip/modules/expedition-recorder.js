(() => {
  'use strict';
  if (globalThis.__SF_SUPPORT_EXPEDITION_RECORDER__) return;
  globalThis.__SF_SUPPORT_EXPEDITION_RECORDER__ = true;

  const VERSION = '1.7.0-clean-runs-editor';
  const STORAGE_KEY = 'sfSupportExpeditionSilentV1';
  const ENABLE_KEY = 'sfSupportExpeditionRecorderEnabled';
  const RESEARCH_STATE_KEY = 'sfSupportExpeditionResearchV1';
  const EDITOR_STATE_KEY = 'sfSupportExpeditionEditorV1';
  const MAX_RUNS = 500;
  const MAX_TIMELINE = 140;
  const MAX_UPLOAD_RUNS = 50;
  const DEFAULT_BATCH_SIZE = 20;
  const CLEAN_RUN_STEPS = 10;
  const EDITOR_PASSWORD_SHA256 = 'b968e8bbbac5318680e60cee33b2cad83d75ea30b4005ac8903c7d3c66895146';
  const RETRY_INTERVAL_MS = 5 * 60 * 1000;

  const SEED = globalThis.SF_EXPEDITION_RECORDER_SEED || { events: {}, missions: {} };

  let db = null;
  let ready = false;
  let enabled = false;
  let latestOffers = [];
  let latestStateRaw = '';
  let activeCharacter = null;
  let research = null;
  let researchUploading = false;
  let researchTimer = null;
  let researchQueued = false;
  let editor = null;
  let editorUnlocked = false;
  let editorFocus = null;
  const editorPending = [];

  const buffered = [];
  const subscribers = new Set();
  const nowIso = () => new Date().toISOString();

  const storageGet = key => new Promise(resolve =>
    chrome.storage.local.get([key], result => resolve(result?.[key]))
  );

  const storageSet = (key, value) => new Promise((resolve, reject) =>
    chrome.storage.local.set({ [key]: value }, () =>
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve()
    )
  );

  function createReporterId() {
    return globalThis.crypto?.randomUUID?.() ||
      'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 3 | 8);
        return v.toString(16);
      });
  }

  function makeResearchState() {
    return {
      schemaVersion: 1,
      enabled: false,
      reporterId: createReporterId(),
      batchSize: DEFAULT_BATCH_SIZE,
      uploadedRuns: 0,
      uploadedBatches: 0,
      lastUploadAt: null,
      lastBatchId: null,
      lastError: '',
      lastConnectionOk: null,
      lastConnectionAt: null
    };
  }

  function normalizeResearch(raw) {
    const r = raw && typeof raw === 'object' && !Array.isArray(raw)
      ? { ...raw }
      : makeResearchState();
    r.schemaVersion = 1;
    r.enabled = Boolean(r.enabled);
    r.reporterId = String(r.reporterId || createReporterId());
    r.batchSize = DEFAULT_BATCH_SIZE;
    r.uploadedRuns = Math.max(0, Number(r.uploadedRuns || 0));
    r.uploadedBatches = Math.max(0, Number(r.uploadedBatches || 0));
    r.lastUploadAt ||= null;
    r.lastBatchId ||= null;
    r.lastError = String(r.lastError || '');
    if (!('lastConnectionOk' in r)) r.lastConnectionOk = null;
    r.lastConnectionAt ||= null;
    return r;
  }

  function makeEditorState() {
    return {
      schemaVersion: 1,
      enabled: false,
      eventOverrides: {},
      missionOverrides: {},
      reviewedEvents: [],
      reviewedMissions: []
    };
  }

  function normalizeEditor(raw) {
    const value = raw && typeof raw === 'object' && !Array.isArray(raw)
      ? { ...raw }
      : makeEditorState();
    value.schemaVersion = 1;
    value.enabled = Boolean(value.enabled);
    value.eventOverrides = value.eventOverrides && typeof value.eventOverrides === 'object' ? value.eventOverrides : {};
    value.missionOverrides = value.missionOverrides && typeof value.missionOverrides === 'object' ? value.missionOverrides : {};
    value.reviewedEvents = Array.from(new Set((value.reviewedEvents || []).map(Number).filter(Number.isFinite)));
    value.reviewedMissions = Array.from(new Set((value.reviewedMissions || []).map(Number).filter(Number.isFinite)));
    return value;
  }

  async function sha256Text(value) {
    const bytes = new TextEncoder().encode(String(value ?? ''));
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    return [...new Uint8Array(digest)].map(v => v.toString(16).padStart(2, '0')).join('');
  }

  async function unlockEditor(password) {
    editorUnlocked = (await sha256Text(password)) === EDITOR_PASSWORD_SHA256;
    notify();
    return editorUnlocked;
  }

  async function saveEditor() {
    if (!editor) return;
    await storageSet(EDITOR_STATE_KEY, editor);
    notify();
  }

  function makeDb() {
    return {
      schemaVersion: 4,
      recorderVersion: VERSION,
      createdAt: nowIso(),
      updatedAt: nowIso(),
      characters: {},
      events: {},
      missions: {},
      runs: [],
      latestOffers: [],
      activeRunId: null
    };
  }

  function normalize() {
    db ||= makeDb();
    db.characters ||= {};
    db.events ||= {};
    db.missions ||= {};
    db.runs ||= [];
    db.latestOffers ||= [];

    for (const [id, s] of Object.entries(SEED.events || {})) {
      db.events[id] ||= {
        id: Number(id),
        name: s.name || '',
        basePoints: Number.isFinite(Number(s.basePoints)) ? Number(s.basePoints) : null,
        source: 'seed',
        firstSeen: null,
        lastSeen: null,
        seenCount: 0,
        observedPoints: {}
      };
    }

    for (const [id, s] of Object.entries(SEED.missions || {})) {
      db.missions[id] ||= {
        id: Number(id),
        name: s.name || '',
        chain: Array.isArray(s.chain) ? [...s.chain] : [],
        successBonus: s.successBonus ?? null,
        failurePenalty: s.failurePenalty ?? null,
        perCompletionBonus: s.perCompletionBonus ?? null,
        maxCompletions: s.maxCompletions ?? null,
        source: 'seed',
        firstSeen: null,
        lastSeen: null,
        seenCount: 0,
        offerBlocks: []
      };
    }

    const activeId = db.activeRunId || null;
    db.runs = db.runs.filter(run => {
      if (!run || typeof run !== 'object') return false;
      if (run.id === activeId && !run.completed && !run.endedAt) return true;
      return Boolean(run.completed && run.endedAt && Array.isArray(run.steps) && run.steps.length === CLEAN_RUN_STEPS);
    });

    if (db.activeRunId && !db.runs.some(r => r.id === db.activeRunId && !r.completed && !r.endedAt)) {
      db.activeRunId = null;
    }
    latestOffers = Array.isArray(db.latestOffers) ? db.latestOffers : [];
    applyEditorOverrides();
  }

  function applyEditorOverrides() {
    if (!editor) return;
    const advisor = globalThis.SFExpeditionAdvisorData;
    for (const [id, override] of Object.entries(editor.eventOverrides || {})) {
      if (!override || typeof override !== 'object') continue;
      const key = String(id);
      if (db?.events?.[key]) {
        if (override.name != null) db.events[key].name = String(override.name);
        if (Number.isFinite(Number(override.points))) db.events[key].basePoints = Number(override.points);
      }
      if (advisor?.events) {
        advisor.events[Number(id)] ||= {
          id: Number(id),
          name: db?.events?.[key]?.name || '',
          points: Number.isFinite(Number(db?.events?.[key]?.basePoints)) ? Number(db.events[key].basePoints) : 0
        };
        Object.assign(advisor.events[Number(id)], override, { id: Number(id) });
      }
    }
    for (const [id, override] of Object.entries(editor.missionOverrides || {})) {
      if (!override || typeof override !== 'object') continue;
      const key = String(id);
      if (db?.missions?.[key]) {
        if (override.name != null) db.missions[key].name = String(override.name);
        for (const field of ['chain','successBonus','failurePenalty','perCompletionBonus','maxCompletions']) {
          if (field in override) db.missions[key][field] = Array.isArray(override[field]) ? [...override[field]] : override[field];
        }
      }
      if (advisor?.missions) {
        advisor.missions[Number(id)] ||= { id: Number(id), name: db?.missions?.[key]?.name || '', chain: db?.missions?.[key]?.chain || [] };
        Object.assign(advisor.missions[Number(id)], override, { id: Number(id) });
      }
    }
  }

  function notify() {
    const status = getStatus();
    for (const fn of subscribers) {
      try { fn(status); } catch (error) { console.error(error); }
    }
  }

  async function save() {
    if (!db) return;
    db.updatedAt = nowIso();
    db.recorderVersion = VERSION;
    db.latestOffers = latestOffers;
    await storageSet(STORAGE_KEY, db);
    notify();
  }

  async function saveResearch() {
    if (!research) return;
    await storageSet(RESEARCH_STATE_KEY, research);
    notify();
  }

  function injectHook() {
    if (document.documentElement.dataset.sfExpeditionHook === '1') return;
    document.documentElement.dataset.sfExpeditionHook = '1';
    const parent = document.head || document.documentElement;
    if (!parent) {
      setTimeout(injectHook, 10);
      return;
    }
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('expedition-hook.js');
    script.async = false;
    script.onload = () => script.remove();
    parent.appendChild(script);
  }

  function parseNumbers(raw) {
    if (!raw) return [];
    return String(raw).split('/').filter(v => v !== '').map(v => {
      const n = Number(v);
      return Number.isFinite(n) ? n : v;
    });
  }

  function parseState(raw = latestStateRaw) { return parseNumbers(raw); }
  function stateAt(index, raw = latestStateRaw) {
    const n = Number(parseState(raw)[index]);
    return Number.isFinite(n) ? n : null;
  }

  function parseCrossroad(raw) {
    const values = parseNumbers(raw);
    const out = [];
    for (let i = 0; i + 1 < values.length; i += 2) {
      out.push({
        position: out.length + 1,
        eventId: Number(values[i]),
        serverPoints: Number(values[i + 1])
      });
    }
    return out;
  }

  function parseOffers(raw) {
    const values = parseNumbers(raw);
    const out = [];
    for (let i = 0; i + 7 < values.length; i += 8) {
      const block = values.slice(i, i + 8).map(Number);
      out.push({
        position: out.length + 1,
        missionId: Number(block[0]),
        block,
        adventureThirst: Number.isFinite(block[6]) ? block[6] / 60 : null
      });
    }
    return out;
  }

  const positiveInt = value => {
    const n = Number(String(value || '').trim());
    return Number.isInteger(n) && n > 0 ? n : null;
  };

  function editorReviewed(kind, id) {
    const list = kind === 'mission' ? editor?.reviewedMissions : editor?.reviewedEvents;
    return Array.isArray(list) && list.includes(Number(id));
  }

  function queueEditorReview(kind, id) {
    if (!editor?.enabled) return;
    const numericId = Number(id);
    if (!Number.isFinite(numericId) || editorReviewed(kind, numericId)) return;
    if (!editorPending.some(item => item.kind === kind && item.id === numericId)) {
      editorPending.push({ kind, id: numericId });
    }
    if (!editorFocus && editorPending.length) editorFocus = { ...editorPending[0] };
    notify();
  }

  function editorSource(kind) {
    const advisor = globalThis.SFExpeditionAdvisorData || {};
    const source = {};
    if (kind === 'mission') {
      for (const [id, entry] of Object.entries(advisor.missions || {})) source[id] = { ...entry };
      for (const [id, entry] of Object.entries(db?.missions || {})) {
        source[id] ||= {
          id: Number(entry.id ?? id),
          name: String(entry.name || ''),
          chain: Array.isArray(entry.chain) ? [...entry.chain] : [],
          successBonus: entry.successBonus ?? null,
          failurePenalty: entry.failurePenalty ?? null,
          perCompletionBonus: entry.perCompletionBonus ?? null,
          maxCompletions: entry.maxCompletions ?? null
        };
      }
    } else {
      for (const [id, entry] of Object.entries(advisor.events || {})) source[id] = { ...entry };
      for (const [id, entry] of Object.entries(db?.events || {})) {
        source[id] ||= {
          id: Number(entry.id ?? id),
          name: String(entry.name || ''),
          points: Number.isFinite(Number(entry.basePoints)) ? Number(entry.basePoints) : 0
        };
      }
    }
    return source;
  }

  function getEditorEntries(kind) {
    const source = editorSource(kind);
    return Object.values(source)
      .map(entry => JSON.parse(JSON.stringify(entry)))
      .sort((a, b) => Number(a.id || 0) - Number(b.id || 0));
  }

  function getEditorEntry(kind, id) {
    const entry = editorSource(kind)?.[Number(id)];
    return entry ? JSON.parse(JSON.stringify(entry)) : null;
  }

  function setEditorFocus(kind, id = null) {
    if (!['event', 'mission'].includes(kind)) return false;
    const entries = getEditorEntries(kind);
    const selected = Number.isFinite(Number(id)) && getEditorEntry(kind, Number(id))
      ? Number(id)
      : Number(entries[0]?.id || 0) || null;
    editorFocus = { kind, id: selected };
    notify();
    return true;
  }

  function clearEditorFocus() {
    editorFocus = null;
    notify();
  }

  async function setEditorEnabled(value) {
    if (!editorUnlocked) throw new Error('Editor gesperrt.');
    editor.enabled = Boolean(value);
    await saveEditor();
    return editor.enabled;
  }

  async function saveEditorEntry(kind, id, payload) {
    if (!editorUnlocked) throw new Error('Editor gesperrt.');
    const numericId = Number(id);
    if (!Number.isFinite(numericId)) throw new Error('Ungültige ID.');
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) throw new Error('Ungültige Daten.');

    const target = kind === 'mission' ? editor.missionOverrides : editor.eventOverrides;
    target[String(numericId)] = JSON.parse(JSON.stringify({ ...payload, id: numericId }));

    const reviewed = kind === 'mission' ? editor.reviewedMissions : editor.reviewedEvents;
    if (!reviewed.includes(numericId)) reviewed.push(numericId);

    for (let i = editorPending.length - 1; i >= 0; i--) {
      if (editorPending[i].kind === kind && editorPending[i].id === numericId) editorPending.splice(i, 1);
    }
    applyEditorOverrides();
    await saveEditor();
    await save();

    editorFocus = editorPending.length ? { ...editorPending[0] } : { kind, id: numericId };
    notify();
    return getEditorEntry(kind, numericId);
  }

  function currentRun() {
    if (!db?.activeRunId) return null;
    return db.runs.find(r => r.id === db.activeRunId && !r.completed && !r.endedAt) || null;
  }

  function observeOffer(offer, at) {
    const id = String(offer.missionId);
    let mission = db.missions[id];
    if (!mission) {
      mission = db.missions[id] = {
        id: offer.missionId,
        name: '',
        chain: [],
        successBonus: null,
        failurePenalty: null,
        perCompletionBonus: null,
        maxCompletions: null,
        source: 'observed',
        firstSeen: new Date(at).toISOString(),
        lastSeen: new Date(at).toISOString(),
        seenCount: 0,
        offerBlocks: []
      };
    }
    mission.firstSeen ||= new Date(at).toISOString();
    mission.lastSeen = new Date(at).toISOString();
    mission.seenCount = Number(mission.seenCount || 0) + 1;
    mission.offerBlocks ||= [];
    const text = offer.block.join('/');
    if (!mission.offerBlocks.includes(text)) mission.offerBlocks.push(text);
  }

  function observeEvent(option, at) {
    const id = String(option.eventId);
    let event = db.events[id];
    if (!event) {
      event = db.events[id] = {
        id: option.eventId,
        name: '',
        basePoints: option.serverPoints,
        source: 'observed',
        firstSeen: new Date(at).toISOString(),
        lastSeen: new Date(at).toISOString(),
        seenCount: 0,
        observedPoints: {}
      };
    }
    event.firstSeen ||= new Date(at).toISOString();
    event.lastSeen = new Date(at).toISOString();
    event.seenCount = Number(event.seenCount || 0) + 1;
    event.observedPoints ||= {};
    event.observedPoints[String(option.serverPoints)] =
      Number(event.observedPoints[String(option.serverPoints)] || 0) + 1;
    queueEditorReview('event', option.eventId);
  }

  function removeRun(run) {
    if (!run) return;
    db.runs = (db.runs || []).filter(item => item.id !== run.id);
    if (db.activeRunId === run.id) db.activeRunId = null;
  }

  function startRun(at, request) {
    const selectedPosition = positiveInt(request.paramsDecoded);
    const selected = selectedPosition ? latestOffers.find(o => o.position === selectedPosition) : null;
    const missionId = selected?.missionId ?? null;
    const mission = missionId != null ? db.missions[String(missionId)] : null;
    const old = currentRun();

    if (old) {
      const ageMs = Math.max(0, Number(at || Date.now()) - new Date(old.startedAt || 0).getTime());
      const compatibleMission = old.missionId == null || missionId == null || Number(old.missionId) === Number(missionId);
      if (ageMs < 30 * 60 * 1000 && compatibleMission) {
        old.selectedOfferPosition ||= selectedPosition || null;
        old.missionId ??= missionId;
        if (old.missionId != null) old.missionName = db.missions[String(old.missionId)]?.name || old.missionName || null;
        old.offerBlock ||= selected?.block || null;
        old.adventureThirst ??= selected?.adventureThirst ?? null;
        if (old.missionId != null) queueEditorReview('mission', old.missionId);
        return old;
      }
      removeRun(old);
    }

    const run = {
      id: `run-${at}-${Math.random().toString(36).slice(2, 7)}`,
      startedAt: new Date(at).toISOString(),
      endedAt: null,
      completed: false,
      recovered: false,
      server: request.server || activeCharacter?.server || location.hostname,
      characterName: activeCharacter?.name || null,
      levelStart: activeCharacter?.level ?? null,
      levelEnd: activeCharacter?.level ?? null,
      selectedOfferPosition: selectedPosition || null,
      missionId,
      missionName: mission?.name || null,
      offerBlock: selected?.block || null,
      adventureThirst: selected?.adventureThirst ?? null,
      steps: [],
      timeline: []
    };

    db.runs.push(run);
    if (db.runs.length > MAX_RUNS) db.runs.splice(0, db.runs.length - MAX_RUNS);
    db.activeRunId = run.id;
    if (missionId != null) queueEditorReview('mission', missionId);
    return run;
  }

  function ensureRecoveredRun(at, request) {
    let run = currentRun();
    if (run) return run;

    run = {
      id: `run-${at}-recovered`,
      startedAt: new Date(at).toISOString(),
      endedAt: null,
      completed: false,
      recovered: true,
      server: request?.server || activeCharacter?.server || location.hostname,
      characterName: activeCharacter?.name || null,
      levelStart: activeCharacter?.level ?? null,
      levelEnd: activeCharacter?.level ?? null,
      missionId: stateAt(3),
      missionName: null,
      steps: [],
      timeline: []
    };

    if (run.missionId != null) {
      run.missionName = db.missions[String(run.missionId)]?.name || null;
      queueEditorReview('mission', run.missionId);
    }
    db.runs.push(run);
    db.activeRunId = run.id;
    return run;
  }

  function markChoice(run, request, at) {
    if (!run?.steps?.length) return;
    const position = positiveInt(request.paramsDecoded);
    if (!position || position > 3) return;

    for (let i = run.steps.length - 1; i >= 0; i--) {
      const step = run.steps[i];
      if (step.selectedPosition != null) continue;
      step.selectedPosition = position;
      step.selectedAt = new Date(at).toISOString();
      const option = step.options.find(o => o.position === position);
      step.selectedEventId = option?.eventId ?? null;
      step.selectedServerPoints = option?.serverPoints ?? null;
      return;
    }
  }

  function addStep(run, raw, at) {
    const options = parseCrossroad(raw);
    if (!options.length) return;
    const previous = run.steps.at(-1);
    if (previous && previous.rawCrossroad === raw && previous.stateRaw === latestStateRaw) return;
    for (const option of options) observeEvent(option, at);

    const nextStep = {
      at: new Date(at).toISOString(),
      round: stateAt(0),
      phase: stateAt(2),
      missionId: stateAt(3),
      heroism: stateAt(13),
      stars: stateAt(14),
      stateRaw: latestStateRaw,
      rawCrossroad: String(raw),
      options,
      selectedPosition: null,
      selectedEventId: null,
      selectedServerPoints: null
    };

    // Solange die aktuelle Kreuzung noch nicht gewählt wurde, ist eine weitere
    // Crossroad-Antwort nur ein Refresh derselben Begegnung und kein neuer Schritt.
    if (previous && previous.selectedPosition == null) {
      run.steps[run.steps.length - 1] = nextStep;
      return;
    }

    if (run.steps.length >= CLEAN_RUN_STEPS) return;
    run.steps.push(nextStep);
  }

  function appendTimeline(run, data) {
    if (!run) return;
    const fields = {};
    for (const [key, value] of Object.entries(data.fields || {})) {
      if (key === 'expeditions' || key.startsWith('expedition') || key === 'winnerid') fields[key] = value;
    }
    run.timeline.push({
      at: new Date(data.at).toISOString(),
      req: data.request?.req?.startsWith('Expedition') ? data.request.req : 'Sync',
      paramsDecoded: data.request?.req?.startsWith('Expedition') ? (data.request.paramsDecoded || '') : '',
      fields
    });
    if (run.timeline.length > MAX_TIMELINE) run.timeline.splice(0, run.timeline.length - MAX_TIMELINE);
  }

  function rememberCharacter(snapshot, at) {
    const server = String(snapshot?.server || 'unknown');
    const name = String(snapshot?.name || '').trim();
    const level = Number(snapshot?.level);
    if (!name || !Number.isFinite(level)) return;

    activeCharacter = { server, name, level };
    const key = `${server.toLowerCase()}::${name.toLowerCase()}`;
    const iso = new Date(at).toISOString();
    const record = db.characters[key] || {
      server,
      name,
      firstSeen: iso,
      lastSeen: iso,
      currentLevel: level,
      highestLevel: level,
      levelHistory: []
    };

    if (record.currentLevel !== level) record.levelHistory.push({ at: iso, level });
    record.server = server;
    record.name = name;
    record.lastSeen = iso;
    record.currentLevel = level;
    record.highestLevel = Math.max(Number(record.highestLevel || level), level);
    db.characters[key] = record;

    const run = currentRun();
    if (run && (!run.characterName || run.characterName === name)) {
      run.characterName = name;
      run.server = server;
      run.levelEnd = level;
    }
  }

  function isCleanCompletedRun(run) {
    return Boolean(run?.completed && run?.endedAt && Array.isArray(run?.steps) && run.steps.length === CLEAN_RUN_STEPS);
  }

  function finalizedRuns() {
    const activeId = db?.activeRunId || null;
    return (db?.runs || []).filter(run => run?.id !== activeId && isCleanCompletedRun(run));
  }

  function completedReadyRuns() {
    return finalizedRuns();
  }

  function compactEvents() {
    const out = {};
    for (const [id, event] of Object.entries(db?.events || {})) {
      out[id] = {
        id: Number(event.id ?? id),
        name: String(event.name || ''),
        basePoints: Number.isFinite(Number(event.basePoints)) ? Number(event.basePoints) : null
      };
    }
    return out;
  }

  function compactMissions() {
    const out = {};
    for (const [id, mission] of Object.entries(db?.missions || {})) {
      out[id] = {
        id: Number(mission.id ?? id),
        name: String(mission.name || ''),
        chain: Array.isArray(mission.chain) ? [...mission.chain] : [],
        successBonus: mission.successBonus ?? null,
        failurePenalty: mission.failurePenalty ?? null,
        perCompletionBonus: mission.perCompletionBonus ?? null,
        maxCompletions: mission.maxCompletions ?? null
      };
    }
    return out;
  }

  async function sha256Hex(text) {
    const bytes = new TextEncoder().encode(text);
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    return [...new Uint8Array(digest)].map(v => v.toString(16).padStart(2, '0')).join('');
  }

  async function researchRequest(payload) {
    const response = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'SF_EXPEDITION_RESEARCH_REQUEST', payload }, reply => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(reply);
      });
    });

    if (!response?.transportOk) {
      throw new Error(response?.data?.error || response?.error ||
        `Forschungsserver nicht erreichbar${response?.status ? ` (${response.status})` : ''}.`);
    }
    if (!response?.data?.ok) throw new Error(response?.data?.error || 'Upload fehlgeschlagen.');
    return response.data;
  }

  async function testResearchConnection() {
    try {
      const result = await researchRequest({ action: 'ping' });
      research.lastConnectionOk = true;
      research.lastConnectionAt = result.server_time || nowIso();
      research.lastError = '';
      await saveResearch();
      return { ok: true, ...result };
    } catch (error) {
      research.lastConnectionOk = false;
      research.lastConnectionAt = nowIso();
      research.lastError = error?.message || String(error);
      await saveResearch();
      return { ok: false, error: research.lastError };
    }
  }

  function chooseRunsForUpload(force = false) {
    const finalized = finalizedRuns();
    if (!finalized.length) return [];
    if (!force && completedReadyRuns().length < research.batchSize) return [];
    return finalized.slice(0, MAX_UPLOAD_RUNS);
  }

  async function uploadResearchNow({ force = false } = {}) {
    if (!research?.enabled) return { ok: false, skipped: true, reason: 'disabled' };
    if (researchUploading) return { ok: false, skipped: true, reason: 'already-running' };

    const runs = chooseRunsForUpload(force);
    if (!runs.length) {
      return {
        ok: true,
        skipped: true,
        reason: force ? 'no-finalized-runs' : 'threshold-not-reached',
        readyRuns: completedReadyRuns().length
      };
    }

    researchUploading = true;
    notify();

    try {
      const runIds = runs.map(run => String(run.id));
      const batchKey = await sha256Hex(`${research.reporterId}|${runIds.join('|')}`);
      const data = {
        schemaVersion: 4,
        recorderVersion: VERSION,
        extensionVersion: '1.9.18',
        exportedAt: nowIso(),
        events: compactEvents(),
        missions: compactMissions(),
        runs: JSON.parse(JSON.stringify(runs))
      };

      const result = await researchRequest({
        action: 'upload',
        reporter_id: research.reporterId,
        batch_key: batchKey,
        recorder_version: VERSION,
        data
      });

      if (!result?.stored) throw new Error('Server hat den Datensatz nicht bestätigt.');

      const uploadedIds = new Set(runIds);
      db.runs = (db.runs || []).filter(run => !uploadedIds.has(String(run.id)));
      if (db.activeRunId && !db.runs.some(run => run.id === db.activeRunId)) db.activeRunId = null;

      research.uploadedRuns += runs.length;
      research.uploadedBatches += 1;
      research.lastUploadAt = result.received_at || result.server_time || nowIso();
      research.lastBatchId = result.batch_id || batchKey;
      research.lastError = '';
      research.lastConnectionOk = true;
      research.lastConnectionAt = result.server_time || nowIso();

      await save();
      await saveResearch();

      if (research.enabled && completedReadyRuns().length >= research.batchSize) queueAutoUpload(250);

      return {
        ok: true,
        uploadedRuns: runs.length,
        duplicate: Boolean(result.duplicate),
        batchId: result.batch_id || null,
        batchKey
      };
    } catch (error) {
      research.lastError = error?.message || String(error);
      research.lastConnectionOk = false;
      research.lastConnectionAt = nowIso();
      await saveResearch();
      return { ok: false, error: research.lastError };
    } finally {
      researchUploading = false;
      notify();
    }
  }

  function queueAutoUpload(delay = 100) {
    if (!ready || !research?.enabled || researchQueued) return;
    researchQueued = true;
    setTimeout(async () => {
      researchQueued = false;
      if (!research?.enabled || completedReadyRuns().length < research.batchSize) return;
      await uploadResearchNow({ force: false });
    }, delay);
  }

  function startResearchRetryLoop() {
    if (researchTimer) return;
    researchTimer = setInterval(() => {
      if (research?.enabled && completedReadyRuns().length >= research.batchSize) queueAutoUpload(0);
    }, RETRY_INTERVAL_MS);
  }

  async function handle(data) {
    if (!enabled) return;

    if (data.type === 'CHARACTER_SNAPSHOT') {
      rememberCharacter(data.character, data.at || Date.now());
      await save();
      queueAutoUpload();
      return;
    }

    if (data.type !== 'CMD_RESPONSE') return;

    const request = data.request || {};
    const fields = data.fields || {};
    const req = request.req || '';

    if (fields.expeditions) {
      latestOffers = parseOffers(fields.expeditions);
      for (const offer of latestOffers) observeOffer(offer, data.at);
    }

    let run = currentRun();
    if (req === 'ExpeditionStart') run = startRun(data.at, request);
    else if (!run && (fields.expeditionstate || fields.expeditioncrossroad || fields.expeditionmonster)) {
      run = ensureRecoveredRun(data.at, request);
    }

    if (run && req === 'ExpeditionProceed') markChoice(run, request, data.at);
    if (fields.expeditionstate) latestStateRaw = fields.expeditionstate;

    if (run) {
      appendTimeline(run, data);
      if (run.missionId == null && stateAt(3) != null) {
        run.missionId = stateAt(3);
        run.missionName = db.missions[String(run.missionId)]?.name || null;
        queueEditorReview('mission', run.missionId);
      }
      if (fields.expeditioncrossroad) addStep(run, fields.expeditioncrossroad, data.at);
      if (fields.expeditionmonster) run.lastMonster = { at: new Date(data.at).toISOString(), raw: fields.expeditionmonster };
      if (Object.prototype.hasOwnProperty.call(fields, 'winnerid')) run.lastWinnerId = fields.winnerid;

      if (fields.expeditionrewardresources !== undefined) {
        if (Array.isArray(run.steps) && run.steps.length === CLEAN_RUN_STEPS) {
          run.completed = true;
          run.endedAt = new Date(data.at).toISOString();
          run.rewardResources = fields.expeditionrewardresources;
          run.rewardItems = fields.expeditionrewarditems ?? '';
          run.finalStateRaw = fields.expeditionstate || latestStateRaw;
          run.finalHeroism = stateAt(13, run.finalStateRaw);
          run.finalStars = stateAt(14, run.finalStateRaw);
          run.levelEnd = activeCharacter?.level ?? run.levelEnd;
          db.activeRunId = null;
        } else {
          removeRun(run);
          run = null;
        }
      }
    }

    await save();
    queueAutoUpload();
  }

  window.addEventListener('message', event => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== 'SF_EXPEDITION_STANDALONE_PAGE') return;
    if (!ready) buffered.push(data);
    else handle(data).catch(console.error);
  });

  async function setEnabled(value) {
    enabled = Boolean(value);
    await storageSet(ENABLE_KEY, enabled);
    notify();
    return enabled;
  }

  async function setResearchEnabled(value) {
    research.enabled = Boolean(value);
    research.lastError = '';
    await saveResearch();
    if (research.enabled) {
      const connection = await testResearchConnection();
      queueAutoUpload(100);
      return { enabled: true, connection };
    }
    return { enabled: false };
  }

  async function setResearchBatchSize() {
    research.batchSize = DEFAULT_BATCH_SIZE;
    await saveResearch();
    queueAutoUpload(100);
    return DEFAULT_BATCH_SIZE;
  }

  async function clearData() {
    db = makeDb();
    normalize();
    latestOffers = [];
    latestStateRaw = '';
    await save();
  }

  function exportData() {
    const payload = {
      ...db,
      runs: finalizedRuns().map(run => JSON.parse(JSON.stringify(run))),
      activeRunId: null,
      exportedAt: nowIso(),
      recorderEnabled: enabled,
      researchSharing: {
        enabled: Boolean(research?.enabled),
        batchSize: Number(research?.batchSize || DEFAULT_BATCH_SIZE),
        uploadedRuns: Number(research?.uploadedRuns || 0),
        uploadedBatches: Number(research?.uploadedBatches || 0),
        lastUploadAt: research?.lastUploadAt || null
      }
    };

    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sf-expedition-${(activeCharacter?.name || 'export').toLowerCase().replace(/[^a-z0-9_-]+/gi, '-')}-${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
    document.documentElement.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  function getStatus() {
    const active = currentRun();
    return {
      enabled,
      ready,
      runs: finalizedRuns().length,
      activeRun: Boolean(active),
      activeRunSteps: Array.isArray(active?.steps) ? active.steps.length : 0,
      version: VERSION,
      researchEnabled: Boolean(research?.enabled),
      researchBatchSize: DEFAULT_BATCH_SIZE,
      researchReadyRuns: completedReadyRuns().length,
      researchFinalizedRuns: finalizedRuns().length,
      researchUploading,
      researchUploadedRuns: Number(research?.uploadedRuns || 0),
      researchUploadedBatches: Number(research?.uploadedBatches || 0),
      researchLastUploadAt: research?.lastUploadAt || null,
      researchLastError: research?.lastError || '',
      researchConnectionOk: research?.lastConnectionOk ?? null,
      researchConnectionAt: research?.lastConnectionAt || null,
      editorEnabled: Boolean(editor?.enabled),
      editorUnlocked,
      editorFocus: editorFocus ? { ...editorFocus } : null,
      editorPendingCount: editorPending.length
    };
  }

  globalThis.SFSupportExpeditionRecorder = {
    getStatus,
    getData: () => db,
    getActiveRun: currentRun,
    setEnabled,
    setResearchEnabled,
    setResearchBatchSize,
    testResearchConnection,
    uploadResearchNow,
    unlockEditor,
    setEditorEnabled,
    getEditorEntries,
    getEditorEntry,
    setEditorFocus,
    clearEditorFocus,
    saveEditorEntry,
    clearData,
    exportData,
    subscribe(fn) {
      subscribers.add(fn);
      fn(getStatus());
      return () => subscribers.delete(fn);
    }
  };

  Promise.all([
    storageGet(STORAGE_KEY),
    storageGet(ENABLE_KEY),
    storageGet(RESEARCH_STATE_KEY),
    storageGet(EDITOR_STATE_KEY)
  ]).then(([raw, on, researchRaw, editorRaw]) => {
    editor = normalizeEditor(editorRaw);
    db = raw || makeDb();
    normalize();
    applyEditorOverrides();
    research = normalizeResearch(researchRaw);
    enabled = Boolean(on);
    ready = true;
    injectHook();
    startResearchRetryLoop();
    for (const data of buffered.splice(0)) handle(data).catch(console.error);
    notify();
    queueAutoUpload(500);
  }).catch(error => {
    console.error('[S&F Expedition Recorder]', error);
    editor = makeEditorState();
    db = makeDb();
    normalize();
    research = makeResearchState();
    ready = true;
    injectHook();
    startResearchRetryLoop();
    notify();
  });
})();
