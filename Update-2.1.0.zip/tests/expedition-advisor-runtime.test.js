'use strict';

const assert = require('assert');
const fs = require('fs');
const vm = require('vm');

async function main() {
  const storage = {
    sfExpeditionAdvisorSettingsV1: { strategy: 'EXP' },
    sfExpeditionAdvisorRuntimeV2: {
      version: 2,
      round: 3,
      heroism: 2,
      stars: 0,
      missionId: 22,
      phase: 1,
      currentOptions: [{ position: 1, eventId: 2, serverPoints: 2 }],
      currentCrossroadRaw: '2/2',
      history: [131, 132],
      completed: false,
      lastUpdateAt: Date.now()
    }
  };
  const listeners = {};
  const activeRun = {
    missionId: 22,
    recovered: false,
    steps: [131, 132, 21].map(selectedEventId => ({ selectedEventId }))
  };
  const sandbox = {
    console,
    Date,
    Promise,
    Number,
    String,
    Boolean,
    Math,
    Object,
    Array,
    Set,
    Map,
    queueMicrotask,
    CustomEvent: class CustomEvent { constructor(type, init) { this.type = type; this.detail = init?.detail; } },
    chrome: {
      runtime: { lastError: null },
      storage: { local: {
        get(keys, callback) {
          const result = {};
          for (const key of keys) result[key] = storage[key];
          callback(result);
        },
        set(values, callback) { Object.assign(storage, values); callback(); }
      } }
    },
    addEventListener(type, listener) { (listeners[type] ||= []).push(listener); },
    dispatchEvent() { return true; },
    SFSupportExpeditionRecorder: { getActiveRun: () => activeRun }
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  for (const file of [
    '../modules/expedition-advisor-data.js',
    '../modules/expedition-strategy-core.js',
    '../modules/expedition-advisor.js'
  ]) {
    vm.runInContext(fs.readFileSync(require.resolve(file), 'utf8'), sandbox, { filename: file });
  }
  await new Promise(resolve => setImmediate(resolve));

  assert.deepStrictEqual(Array.from(sandbox.SFSupportExpeditionAdvisor.getState().runtime.history), [131, 132, 21]);
  assert.deepStrictEqual(storage.sfExpeditionAdvisorRuntimeV2.history, [131, 132, 21]);

  activeRun.missionId = 193;
  activeRun.steps = [];
  const values = Array(21).fill(0);
  values[0] = 10;
  values[2] = 1;
  values[3] = 193;
  values[13] = 40;
  values[14] = 3;
  const message = {
    source: 'SF_EXPEDITION_STANDALONE_PAGE',
    type: 'CMD_RESPONSE',
    request: { req: 'Sync', paramsDecoded: '' },
    fields: { expeditionstate: values.join('/'), expeditioncrossroad: '132/0/2/2' }
  };
  const windowRef = vm.runInContext('window', sandbox);
  for (const listener of listeners.message || []) listener({ source: windowRef, data: message });
  await new Promise(resolve => setImmediate(resolve));
  const state = sandbox.SFSupportExpeditionAdvisor.getState();
  assert.strictEqual(state.runtime.round, 10);
  assert.strictEqual(state.runtime.roomsRemaining, 1);
  assert.strictEqual(state.runtime.pendingMissionPenalty, -10);
  assert.ok(!state.recommendation.selected.best.reasons.some(reason => reason.startsWith('3 Sterne')));

  console.log('✓ Advisor-Verlauf wird gespeichert und mit dem Recorder synchronisiert');
  console.log('✓ Raum 10 bleibt vor der Auswahl als ein offener Raum erhalten');
  console.log('✓ Offene Missionsstrafe bleibt in der Empfehlung sichtbar');
}

main().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
