'use strict';

const assert = require('assert');
const crypto = require('crypto');
require('../modules/expedition-advisor-data.js');
const core = require('../modules/expedition-strategy-core.js');
const quality = require('../modules/expedition-research-quality.js');
const data = globalThis.SFExpeditionAdvisorData;

let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`✓ ${name}`);
  } catch (error) {
    console.error(`✗ ${name}`);
    throw error;
  }
}

const context = (overrides = {}) => ({
  round: 5,
  heroism: 10,
  missionId: 0,
  history: [],
  options: [],
  ...overrides
});

test('feste Ereignis- und Missionsdaten bleiben unverändert', () => {
  const eventsHash = crypto.createHash('sha256').update(JSON.stringify(data.events)).digest('hex');
  const missionsHash = crypto.createHash('sha256').update(JSON.stringify(data.missions)).digest('hex');
  assert.strictEqual(eventsHash, '6bcf92041ce4faef762077a44bcd8b2db0c867298cd4aa3dcea0c8671192ea01');
  assert.strictEqual(missionsHash, '8af96629e619e97679628c460264c971b52a2a61ff237361e1b13e1b7471eff4');
});

test('GOLD nimmt einen Schlüssel, wenn danach noch ein Raum bleibt', () => {
  const options = [
    { position: 1, eventId: 124, serverPoints: 35 },
    { position: 2, eventId: 131, serverPoints: 0 },
    { position: 3, eventId: 3, serverPoints: 3 }
  ];
  const result = core.recommend(data, context({ round: 9, options }), 'GOLD');
  assert.strictEqual(result.best.eventId, 131);
  assert.strictEqual(result.best.goldPriority, 3);
});

test('GOLD nimmt mit Schlüssel die angebotene Schatztruhe', () => {
  const options = [
    { position: 1, eventId: 124, serverPoints: 35 },
    { position: 2, eventId: 132, serverPoints: 0 },
    { position: 3, eventId: 3, serverPoints: 3 }
  ];
  const result = core.recommend(data, context({ history: [131], options }), 'GOLD');
  assert.strictEqual(result.best.eventId, 132);
  assert.strictEqual(result.best.goldPriority, 3);
});

test('GOLD nimmt im letzten Raum keinen nutzlosen neuen Schlüssel', () => {
  const options = [
    { position: 1, eventId: 124, serverPoints: 35 },
    { position: 2, eventId: 131, serverPoints: 0 },
    { position: 3, eventId: 3, serverPoints: 3 }
  ];
  assert.strictEqual(core.recommend(data, context({ round: 10, options }), 'GOLD').best.eventId, 124);
});

test('GOLD priorisiert nach zwei Truhen wieder den Punkteweg', () => {
  const options = [
    { position: 1, eventId: 131, serverPoints: 0 },
    { position: 2, eventId: 22, serverPoints: 10 },
    { position: 3, eventId: 2, serverPoints: 2 }
  ];
  const history = [131, 132, 131, 132];
  assert.strictEqual(core.recommend(data, context({ history, options }), 'GOLD').best.eventId, 22);
});

test('EXP erklärt 40 Punkte bei offener -10-Mission nicht als sicher', () => {
  const options = [
    { position: 1, eventId: 132, serverPoints: 0 },
    { position: 2, eventId: 2, serverPoints: 2 }
  ];
  const result = core.recommend(data, context({ round: 9, heroism: 40, missionId: 193, history: [131], options }), 'EXP');
  assert.ok(result.best.p40 < 1);
  assert.ok(!result.best.reasons.some(reason => reason.startsWith('3 Sterne')));
  assert.strictEqual(result.best.missionEndPenalty, -10);
});

test('Missionsstrafe wird erst nach dem letzten offenen Raum fällig', () => {
  assert.strictEqual(core.missionSettlement(data, 193, [], 1).penalty, 0);
  assert.strictEqual(core.missionSettlement(data, 193, [], 0).penalty, -10);
});

test('zustandsabhängige Missions- und Kettenraten werden verwendet', () => {
  assert.ok(core.missionEventHazard(data, data.missions[61], 61, 0.28) > 0.5);
  assert.strictEqual(core.nextStepHazard(data, 21, 22), 0.54);
});

test('Kopfgeld gibt beim passenden Ziel genau +10', () => {
  const option = { position: 1, eventId: 22, serverPoints: 10 };
  const scored = core.scoreOption(data, context({ history: [1002], options: [option] }), option, 'EXP');
  assert.strictEqual(scored.bountyBonus, 10);
  assert.strictEqual(core.bountyState(data, [1002, 22]), null);
});

test('Schlüssel und Schatztruhen werden als Zustandspaar gezählt', () => {
  assert.deepStrictEqual(core.buildTreasureState([131, 132, 132, 131]), { keyHeld: true, keyCount: 2, chestCount: 1 });
});

test('Forschungsfilter akzeptiert nur zehn vollständig aufgelöste Entscheidungen', () => {
  const step = {
    options: [{ position: 1, eventId: 2, serverPoints: 2 }],
    selectedPosition: 1,
    selectedEventId: 2,
    selectedServerPoints: 2
  };
  const valid = { completed: true, endedAt: new Date().toISOString(), steps: Array.from({ length: 10 }, () => ({ ...step, options: step.options.map(option => ({ ...option })) })) };
  assert.strictEqual(quality.isCleanCompletedRun(valid), true);
  valid.steps[4].selectedEventId = null;
  assert.strictEqual(quality.isCleanCompletedRun(valid), false);
});

console.log(`\n${passed} Expeditionstests erfolgreich.`);
