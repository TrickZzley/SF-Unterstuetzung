const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const server = 'eu23.sfgame.net';
const accountKey = `${server}::id:999`;
const targets = Object.fromEntries([
  ['unsafe', 10, 1, 4.99],
  ['a', 4, 100, 5],
  ['b', 4, 50, 90],
  ['c', 3, 500, 20],
  ['d', 2, 900, 30],
  ['e', 1, 100, 6],
  ['g', 1, 200, 99],
  ['complete', 0, 1, 100]
].map(([name, missingCount, rank, winChance], index) => {
  const key = `${server}::id:${index + 1}`;
  return [key, {key, server, playerId:index + 1, name, level:500, rank, missingCount, unresolvedCount:0, winChance, winChanceSamples:5000, winChanceStatus:'ready', trackedItems:[]}];
}));

let stored = {
  sfSupportScrapbookV1: {
    schemaVersion:3,
    moduleVersion:'test',
    updatedAt:new Date().toISOString(),
    activeAccountKey:accountKey,
    accounts:{
      [accountKey]:{key:accountKey,server,playerId:999,playerName:'Tester',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),scrapbook:{raw:'',legendariesRaw:'',lastSeenAt:null,snapshotsSeen:0},targets}
    },
    shared:{enabled:false,reporterId:'test',servers:{},connectionOk:null,connectionLastTestAt:null,connectionError:''}
  }
};

const ownPlayer = {id:999,name:'Tester',server,level:500,classId:1,attributes:{},items:{},dungeons:{},fortress:{},potions:{},runes:{}};
const context = {
  console,
  location:{hostname:server},
  setTimeout,
  clearTimeout,
  queueMicrotask,
  crypto:{randomUUID:()=> 'test-reporter'},
  chrome:{storage:{local:{get:async key=>({[key]:stored[key]}),set:async update=>{stored={...stored,...update};},remove:async()=>{}}},runtime:{sendMessage(){},lastError:null}},
  SFSupportCharacter:{getPlayer:()=>ownPlayer,subscribe:()=>()=>{}},
  SFSimulator:{simulateFight:()=>true},
  window:{addEventListener(){},dispatchEvent(){}},
  document:{addEventListener(){},documentElement:{appendChild(){}}}
};
context.globalThis = context;
vm.createContext(context);
const modulePath = path.join(__dirname, '..', 'modules', 'scrapbook.js');
vm.runInContext(fs.readFileSync(modulePath, 'utf8'), context, {filename:modulePath});

setImmediate(async () => {
  const top5 = context.SFSupportScrapbook.getTopTargets();
  assert.deepEqual(Array.from(top5, target => target.name), ['b', 'a', 'c', 'd', 'e']);
  assert.equal(top5.find(target => target.name === 'a').winChance, 5, '5.00% must remain eligible');
  assert.equal(top5.some(target => target.name === 'unsafe'), false, 'values below 5% must be excluded');
  assert.equal(context.SFSupportScrapbook.getStatus().eligibleTargets, 6);

  const content = fs.readFileSync(path.join(__dirname, '..', 'content.js'), 'utf8');
  assert.match(content, /toFixed\(2\).*% Siegchance/);

  const listeners = {};
  const integrationWindow = {
    addEventListener(type, listener) {(listeners[type] ||= []).push(listener);},
    dispatchEvent() {}
  };
  const integrationKey = `${server}::id:999`;
  const integrationStore = {
    sfSupportScrapbookV1:{
      schemaVersion:3,moduleVersion:'test',updatedAt:new Date().toISOString(),activeAccountKey:integrationKey,
      accounts:{[integrationKey]:{key:integrationKey,server,playerId:999,playerName:'Tester',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),scrapbook:{raw:Buffer.alloc(529).toString('base64url'),legendariesRaw:'',lastSeenAt:null,snapshotsSeen:1},targets:{}}},
      shared:{enabled:false,reporterId:'test',servers:{},connectionOk:null,connectionLastTestAt:null,connectionError:''}
    }
  };
  const counters = new Map();
  const integrationContext = {
    console,location:{hostname:server},setTimeout,clearTimeout,queueMicrotask,atob,
    crypto:{randomUUID:()=> 'test-reporter'},
    chrome:{storage:{local:{get:async key=>({[key]:integrationStore[key]}),set:async update=>Object.assign(integrationStore,update),remove:async()=>{}}},runtime:{sendMessage(){},lastError:null}},
    SFSupportCharacter:{getPlayer:()=>ownPlayer,subscribe:()=>()=>{}},
    SFSimulator:{simulateFight(_own, opponent){const count=(counters.get(opponent.id)||0)+1;counters.set(opponent.id,count);const winsPerHundred=opponent.id===1?4:5;return count%100<winsPerHundred;}},
    window:integrationWindow,document:{addEventListener(){},documentElement:{appendChild(){}}}
  };
  integrationContext.globalThis=integrationContext;
  vm.createContext(integrationContext);
  vm.runInContext(fs.readFileSync(modulePath,'utf8'),integrationContext,{filename:modulePath});
  await new Promise(resolve=>setImmediate(resolve));
  const rawEquipment=[1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0].join('/');
  const opponent=id=>({id,name:`enemy-${id}`,server,level:500,classId:1,rank:id,armor:1,rawEquipment,attributes:{},items:{},dungeons:{},fortress:{},potions:{},runes:{}});
  for(const player of [opponent(1),opponent(2)])for(const listener of listeners.message||[])listener({source:integrationWindow,data:{source:'SF_COMBAT_ADVISOR',type:'PLAYER_LOOK_AT',player}});
  const timeoutAt=Date.now()+3000;
  while(integrationContext.SFSupportScrapbook.getStatus().chancePending>0&&Date.now()<timeoutAt)await new Promise(resolve=>setTimeout(resolve,10));
  const integratedTop=integrationContext.SFSupportScrapbook.getTopTargets();
  assert.deepEqual(Array.from(integratedTop,target=>target.name),['enemy-2']);
  assert.equal(integratedTop[0].winChance,5);
  console.log('scrapbook top-5 filter: ok');
});
