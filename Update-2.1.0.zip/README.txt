Version 2.1.0

ÄNDERUNGEN 2.1.0
- GOLD arbeitet jetzt mit fester Schatz-Priorität: passende Truhe mit vorhandenem Schlüssel, sonst ein sinnvoller Schlüssel; nach zwei Truhen wieder Punkte.
- EXP rechnet mögliche Missionsstrafen bereits in die 30-/40-Punkte-Chance ein und meldet 3 Sterne nur noch, wenn sie auch nach der Endabrechnung sicher sind.
- Raum 10 wird vor der letzten Auswahl nicht mehr irrtümlich als bereits beendet behandelt.
- Die gewählten Ereignisse des laufenden Runs werden gespeichert und nach einem Neuladen zusätzlich mit dem Recorder abgeglichen.
- Wiederholbare Missionen und Ereignisketten verwenden zustandsabhängige Angebotsraten aus 96 abgeschlossenen 10/10-Runs.
- Der Recorder akzeptiert für neue Forschungsuploads nur Runs mit zehn vollständig auflösbaren Entscheidungen.
- Regressionsprüfungen decken EXP, GOLD, Missionen, Kopfgelder, Schlüssel und Schatztruhen ab.
- Die Sammelalbum-Top-5 zeigt nur Gegner ab 5,00 % Siegchance; jeder Eintrag enthält wieder seine berechnete Prozentanzeige.
- Ereignis- und Missionsdefinitionen wurden nicht verändert.
- Die Forschungsbasis wird bewusst nur nach manueller Prüfung aktualisiert.

ÄNDERUNGEN 2.0.1
- Missionsboni werden jetzt nach ihrem echten Auszahlungszeitpunkt getrennt: sofort oder erst beim 10/10-Abschluss.
- Bereits verdiente Endboni fließen in die 30-/40-Punkte-Prognose ein.
- Misserfolgsabzüge werden am Expeditionsende berücksichtigt, wenn sie sicher fällig sind.
- "Expeditionsdaten bearbeiten" wurde aus der Hauptoberfläche entfernt.
- Neue Forschungsuploads tragen die korrekte Extension-Version 2.0.1.

ÄNDERUNGEN 2.0.0
- Expedition Advisor 2.0 mit Forschungsmodell aus 95 sauberen 10/10-Runs.
- EXP priorisiert 40 Heldentum; GOLD priorisiert 2 Schatztruhen mit 30/40-Punkte-Absicherung.
- Missionsbezogene Namensauflösung behebt doppelte Ereignisnamen wie Köder (21/142).
- Kopfgelder, Ereignisketten, Folgeräume mit 1/2/3 Auswahlen und Schatz-Planung werden probabilistisch bewertet.
- Kopfgeld: Meermann (1014 -> Meermann 143, +10) bestätigt.
- Automatische Prüfansicht und Passwort entfernt.


ÄNDERUNGEN 1.9.18
-----------------
- Expedition-Recorder speichert/exportiert/überträgt nur vollständige 10/10-Runs.
- Unvollständige/recovered/interrupted Fragmente werden nicht mehr als Runs gezählt oder hochgeladen.
- Automatischer Forschungsupload ist fest auf 20 vollständige Runs eingestellt.
- Sammelalbum-Kampffilter entfernt; Top 5 basiert wieder nur auf fehlenden Items.
- Sammelalbum-Oberfläche bereinigt; unnötige Import/Export-/Sammelkopier-Elemente entfernt.
- Einstellungen kompakter gestaltet.
- Passwortgeschützte Ereignis-/Missionsbearbeitung mit optionaler automatischer Prüfansicht hinzugefügt.

ÄNDERUNGEN 1.9.0
----------------
- Funktionierendes Hauptlayout mit bestehender Sidebar, Fantasy-Rahmen und Blackout beibehalten.
- Vorhandenes x.png als Schließen-Button eingebaut; Leuchteffekt ausschließlich per CSS.
- Expedition Advisor in den vorhandenen Expedition-Reiter integriert.
- Strategien EXP und GOLD umschaltbar.
- Aktuelle Mission, Raum, Heldentum, Sterne, Schlüssel und Schatztruhen werden passiv ausgewertet.
- Neue Expeditionsdaten ergänzt, darunter "Vom Winde Verweht" und die zuletzt bestätigten Kopfgelder.
- Expedition Advisor benötigt keine zusätzlichen S&F-Anfragen.
- Expedition Recorder bleibt optional und passiv; keine Formulare oder Nachfragen.
- Sammelalbum Hilfe um Kampf-Filter 10 / 25 / 50 Prozent und Top-10-Kandidaten erweitert.
- Siegchance dient nur als Filter. Sortierung erfolgt nach fehlenden Items, dann Ehrenhallenrang.
- Gemeinsame Gegnerdatenbank, Import/Export und vorhandene Sammelalbum-Erfassung bleiben erhalten.

INSTALLATION
------------
1. ZIP entpacken.
2. Chrome öffnen und chrome://extensions aufrufen.
3. Entwicklermodus aktivieren.
4. "Entpackte Erweiterung laden" wählen.
5. Den Ordner "S&F Unterstützung" auswählen.

DATENSCHUTZ / SPIELANFRAGEN
---------------------------
Die Spielauswertung arbeitet passiv mit Antworten, die S&F beim normalen Spielen ohnehin liefert.
Es werden für Arena, Sammelalbum und Expedition Advisor keine zusätzlichen S&F-Spielanfragen erzeugt.
Die optionale gemeinsame Sammelalbum-Datenbank verwendet ausschließlich den separaten Sync-Dienst.
SID, Cookies, Login-Daten und das persönliche scrapbook.r werden nicht hochgeladen.

--- Version 1.9.3 ---
Expedition Recorder: optionale automatische Forschungsdaten-Synchronisierung mit Supabase.
- Aktivierung separat in Einstellungen unter "Expeditions-Forschungsdaten".
- Automatischer Upload nach 20 oder 30 abgeschlossenen Runs.
- Nach bestätigtem Server-Empfang werden nur die übertragenen lokalen Run-Datensätze entfernt.
- Bei Verbindungsfehlern bleiben lokale Daten erhalten und werden später erneut versucht.
- Forschungsdaten verändern die Advisor-Logik nicht automatisch.

--- Version 1.9.4 ---
- Expeditionsdaten an den manuell geprüften Forschungsstand angeglichen.
- Event 1003: „Kopfgeld: Abgebranntes Lagerfeuer“ korrigiert.
- Event 1010 ergänzt: „Kopfgeld: Hexensud“ → Ziel Hexensud, +10 bei späterem Zieltreffer.
- Event 1011 ergänzt: „Kopfgeld: Verseuchte Feenquelle“ → Ziel Verseuchte Feenquelle, +10 bei späterem Zieltreffer.
- Event 1015 bestätigt: „Kopfgeld: Zapfender Wirt“ → Ziel Zapfender Wirt, +10 bei späterem Zieltreffer.
- Kopfgelder verwenden ein gemeinsames Limit von maximal 3 Aufnahmen pro Expedition.
- Ein aktives Kopfgeld wird erst beim Anklicken des passenden Zielereignisses eingelöst und ist danach verbraucht.
- „Hopfen und Malz Verloren?“ an die exakte Spielschreibweise angepasst.
- „Zapfender Wirt“ auf den bestätigten Grundwert +6 korrigiert.
- Weitere Bezeichnungen an den manuell geprüften Exportstand angeglichen (u. a. Füße, Köder, Erloschenes Feuer, Heiße Fleischeslust, Treppchenstürmer, Freizügige Dame).
