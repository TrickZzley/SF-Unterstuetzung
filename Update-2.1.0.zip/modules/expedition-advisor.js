(() => {
  'use strict';
  if (globalThis.__SF_EXPEDITION_ADVISOR__) return;
  globalThis.__SF_EXPEDITION_ADVISOR__ = true;

  const SETTINGS_KEY = 'sfExpeditionAdvisorSettingsV1';
  const RUNTIME_KEY = 'sfExpeditionAdvisorRuntimeV2';
  const DEFAULT_SETTINGS = { strategy: 'EXP' };
  const MAX_RUNTIME_AGE_MS = 12 * 60 * 60 * 1000;
  const listeners = new Set();
  let settings = { ...DEFAULT_SETTINGS };
  let persistQueued = false;

  const runtime = {
    round: null,
    heroism: 0,
    stars: 0,
    missionId: null,
    phase: null,
    currentOptions: [],
    currentCrossroadRaw: '',
    history: [],
    lastRecommendation: null,
    completed: false,
    lastUpdateAt: null
  };

  const storageGet = key => new Promise(resolve =>
    chrome.storage.local.get([key], value => resolve(value?.[key]))
  );
  const storageSet = (key, value) => new Promise((resolve, reject) =>
    chrome.storage.local.set({ [key]: value }, () =>
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve()
    )
  );

  function parseNumbers(raw) {
    if (!raw) return [];
    return String(raw).split('/').filter(value => value !== '').map(value => {
      const number = Number(value);
      return Number.isFinite(number) ? number : value;
    });
  }

  function parseCrossroad(raw) {
    const values = parseNumbers(raw), options = [];
    for (let index = 0; index + 1 < values.length; index += 2) {
      const eventId = Number(values[index]), serverPoints = Number(values[index + 1]);
      if (!Number.isFinite(eventId) || !Number.isFinite(serverPoints)) continue;
      options.push({ position: options.length + 1, eventId, serverPoints });
    }
    return options;
  }

  const data = () => globalThis.SFExpeditionAdvisorData;
  const core = () => globalThis.SFExpeditionStrategyCore;

  function eventName(id) {
    try {
      const name = globalThis.SFSupportExpeditionRecorder?.getData?.()?.events?.[String(id)]?.name;
      if (name) return name;
    } catch {}
    return data()?.events?.[Number(id)]?.name || `Event ${id}`;
  }

  function missionName(id) {
    try {
      const name = globalThis.SFSupportExpeditionRecorder?.getData?.()?.missions?.[String(id)]?.name;
      if (name) return name;
    } catch {}
    return data()?.missions?.[Number(id)]?.name || (id ? `Mission ${id}` : '–');
  }

  function runtimeForStorage() {
    return {
      version: 2,
      round: runtime.round,
      heroism: runtime.heroism,
      stars: runtime.stars,
      missionId: runtime.missionId,
      phase: runtime.phase,
      currentOptions: runtime.currentOptions.map(option => ({
        position: Number(option.position),
        eventId: Number(option.eventId),
        serverPoints: Number(option.serverPoints)
      })),
      currentCrossroadRaw: runtime.currentCrossroadRaw,
      history: runtime.history.map(Number).filter(Number.isFinite).slice(-10),
      completed: runtime.completed,
      lastUpdateAt: runtime.lastUpdateAt
    };
  }

  function queuePersist() {
    if (persistQueued) return;
    persistQueued = true;
    queueMicrotask(async () => {
      persistQueued = false;
      try { await storageSet(RUNTIME_KEY, runtimeForStorage()); }
      catch (error) { console.warn('[S&F Expedition Advisor] Laufzeitstatus konnte nicht gespeichert werden:', error); }
    });
  }

  function restoreRuntime(raw) {
    if (!raw || typeof raw !== 'object' || Number(raw.version) !== 2) return false;
    const updatedAt = Number(raw.lastUpdateAt || 0);
    if (!updatedAt || Date.now() - updatedAt > MAX_RUNTIME_AGE_MS) return false;
    const options = Array.isArray(raw.currentOptions) ? raw.currentOptions.map(option => ({
      position: Number(option.position),
      eventId: Number(option.eventId),
      serverPoints: Number(option.serverPoints)
    })).filter(option => Number.isInteger(option.position) && option.position >= 1 && option.position <= 3 && Number.isFinite(option.eventId) && Number.isFinite(option.serverPoints)) : [];
    Object.assign(runtime, {
      round: raw.round != null && Number.isFinite(Number(raw.round)) ? Number(raw.round) : null,
      heroism: Number.isFinite(Number(raw.heroism)) ? Number(raw.heroism) : 0,
      stars: Number.isFinite(Number(raw.stars)) ? Number(raw.stars) : 0,
      missionId: raw.missionId != null && Number.isFinite(Number(raw.missionId)) ? Number(raw.missionId) : null,
      phase: raw.phase != null && Number.isFinite(Number(raw.phase)) ? Number(raw.phase) : null,
      currentOptions: options,
      currentCrossroadRaw: String(raw.currentCrossroadRaw || ''),
      history: (Array.isArray(raw.history) ? raw.history : []).map(Number).filter(Number.isFinite).slice(-10),
      lastRecommendation: null,
      completed: Boolean(raw.completed),
      lastUpdateAt: updatedAt
    });
    return true;
  }

  function resetRuntime({ notify = true } = {}) {
    Object.assign(runtime, {
      round: null,
      heroism: 0,
      stars: 0,
      missionId: null,
      phase: null,
      currentOptions: [],
      currentCrossroadRaw: '',
      history: [],
      lastRecommendation: null,
      completed: false,
      lastUpdateAt: Date.now()
    });
    queuePersist();
    if (notify) emit();
  }

  function syncHistoryFromRecorder() {
    let run;
    try { run = globalThis.SFSupportExpeditionRecorder?.getActiveRun?.(); }
    catch { return false; }
    if (!run || !Array.isArray(run.steps)) return false;
    if (runtime.missionId != null && run.missionId != null && Number(runtime.missionId) !== Number(run.missionId)) return false;
    const selected = run.steps.filter(step => step?.selectedEventId != null)
      .map(step => Number(step.selectedEventId)).filter(Number.isFinite).slice(-10);
    if (!selected.length || selected.length < runtime.history.length) return false;
    if (selected.length === runtime.history.length && selected.every((id, index) => id === runtime.history[index])) return false;
    runtime.history = selected;
    return true;
  }

  function recordPreviousChoice(request) {
    if (String(request?.req || '') !== 'ExpeditionProceed') return;
    const position = Number(String(request?.paramsDecoded || ''));
    if (!Number.isInteger(position) || position < 1 || position > 3 || !runtime.currentOptions.length) return;
    const selected = runtime.currentOptions.find(option => option.position === position);
    if (!selected) return;
    runtime.history.push(Number(selected.eventId));
    runtime.history = runtime.history.slice(-10);
    runtime.currentOptions = [];
    runtime.currentCrossroadRaw = '';
  }

  function updateFromState(raw) {
    const values = parseNumbers(raw);
    if (!values.length) return;
    const incomingRound = Number(values[0]), incomingPhase = Number(values[2]), incomingMission = Number(values[3]);
    if (incomingRound <= 1 && (runtime.round > 1 || (Number.isFinite(incomingMission) && runtime.missionId != null && incomingMission !== Number(runtime.missionId)))) {
      runtime.history = [];
      runtime.currentOptions = [];
      runtime.currentCrossroadRaw = '';
    }
    const set = (index, key) => {
      const number = Number(values[index]);
      if (Number.isFinite(number)) runtime[key] = number;
    };
    set(0, 'round');
    set(2, 'phase');
    set(3, 'missionId');
    set(13, 'heroism');
    set(14, 'stars');
    if (incomingPhase === 1 && Number.isFinite(incomingRound) && runtime.history.length > Math.max(0, incomingRound - 1)) {
      runtime.history = runtime.history.slice(0, Math.max(0, incomingRound - 1));
    }
    runtime.completed = runtime.round === 10 && runtime.phase === 4;
    runtime.lastUpdateAt = Date.now();
  }

  function context() {
    return {
      round: runtime.round,
      heroism: runtime.heroism,
      stars: runtime.stars,
      missionId: runtime.missionId,
      history: [...runtime.history],
      options: runtime.currentOptions.map(option => ({ ...option, name: eventName(option.eventId) }))
    };
  }

  function calculate() {
    const advisorData = data(), strategyCore = core();
    syncHistoryFromRecorder();
    if (!advisorData || !strategyCore || !runtime.currentOptions.length || runtime.phase !== 1) {
      runtime.lastRecommendation = null;
      queuePersist();
      emit();
      return null;
    }
    const currentContext = context();
    runtime.lastRecommendation = {
      selected: strategyCore.recommend(advisorData, currentContext, settings.strategy),
      exp: strategyCore.recommend(advisorData, currentContext, 'EXP'),
      gold: strategyCore.recommend(advisorData, currentContext, 'GOLD'),
      context: currentContext
    };
    queuePersist();
    emit();
    return runtime.lastRecommendation;
  }

  function handleMessage(message) {
    if (!message || message.source !== 'SF_EXPEDITION_STANDALONE_PAGE' || message.type !== 'CMD_RESPONSE') return;
    const request = message.request || {}, req = String(request.req || '');
    if (req === 'ExpeditionStart') resetRuntime({ notify: false });
    else recordPreviousChoice(request);
    const fields = message.fields || {};
    if (fields.expeditionstate) updateFromState(fields.expeditionstate);
    syncHistoryFromRecorder();
    if (fields.expeditioncrossroad) {
      const raw = String(fields.expeditioncrossroad);
      if (raw !== runtime.currentCrossroadRaw || !runtime.currentOptions.length) {
        runtime.currentCrossroadRaw = raw;
        runtime.currentOptions = parseCrossroad(raw);
      }
      calculate();
      return;
    }
    if (runtime.phase !== 1 || runtime.completed) {
      runtime.currentOptions = [];
      runtime.currentCrossroadRaw = '';
      runtime.lastRecommendation = null;
    }
    queuePersist();
    emit();
  }

  function getPublicState() {
    const advisorData = data(), strategyCore = core();
    const treasure = strategyCore?.buildTreasureState?.(runtime.history) || { keyHeld: false, chestCount: 0, keyCount: 0 };
    const missionProgress = strategyCore?.missionState?.(advisorData, runtime.missionId, runtime.history) || null;
    const settlementAlreadyApplied = runtime.completed || (runtime.round === 10 && runtime.phase !== 1);
    const roomsRemaining = runtime.round == null ? 0 : Math.max(0, (runtime.phase === 1 ? 11 : 10) - Number(runtime.round));
    const missionSettlement = settlementAlreadyApplied ? { bonus: 0, penalty: 0, net: 0 } :
      strategyCore?.missionSettlement?.(advisorData, runtime.missionId, runtime.history, roomsRemaining) || { bonus: 0, penalty: 0, net: 0 };
    const potentialPenalty = settlementAlreadyApplied ? 0 : Number(strategyCore?.pendingFailurePenalty?.(advisorData, runtime.missionId, runtime.history) || 0);
    const effectiveHeroism = Number(runtime.heroism || 0) + Number(missionSettlement.bonus || 0) + potentialPenalty;
    return {
      version: '2.1.0',
      researchRuns: Number(advisorData?.research?.cleanRuns || 0),
      fullySelectedResearchRuns: Number(advisorData?.research?.fullySelectedRuns || advisorData?.research?.cleanRuns || 0),
      settings: { ...settings },
      runtime: {
        round: runtime.round,
        roomsRemaining,
        heroism: runtime.heroism,
        effectiveHeroism,
        pendingMissionBonus: Number(missionSettlement.bonus || 0),
        pendingMissionPenalty: potentialPenalty,
        stars: runtime.stars,
        phase: runtime.phase,
        missionId: runtime.missionId,
        missionName: missionName(runtime.missionId),
        history: [...runtime.history],
        keyHeld: treasure.keyHeld,
        keyCount: treasure.keyCount,
        chestCount: treasure.chestCount,
        completed: runtime.completed,
        lastUpdateAt: runtime.lastUpdateAt,
        missionProgress
      },
      options: runtime.currentOptions.map(option => ({ ...option, name: eventName(option.eventId) })),
      recommendation: runtime.lastRecommendation ? {
        selected: runtime.lastRecommendation.selected,
        exp: runtime.lastRecommendation.exp,
        gold: runtime.lastRecommendation.gold
      } : null
    };
  }

  function emit() {
    const state = getPublicState();
    window.dispatchEvent(new CustomEvent('sf-expedition-advisor-updated', { detail: state }));
    for (const listener of listeners) {
      try { listener(state); }
      catch (error) { console.error('[S&F Expedition Advisor]', error); }
    }
  }

  async function setStrategy(strategy) {
    settings.strategy = String(strategy || '').toUpperCase() === 'GOLD' ? 'GOLD' : 'EXP';
    await storageSet(SETTINGS_KEY, settings);
    calculate();
    return settings.strategy;
  }

  window.addEventListener('message', event => {
    if (event.source === window) handleMessage(event.data);
  });

  globalThis.SFSupportExpeditionAdvisor = {
    getState: getPublicState,
    setStrategy,
    subscribe(listener) {
      listeners.add(listener);
      listener(getPublicState());
      return () => listeners.delete(listener);
    }
  };

  Promise.all([storageGet(SETTINGS_KEY), storageGet(RUNTIME_KEY)]).then(([rawSettings, rawRuntime]) => {
    settings = { ...DEFAULT_SETTINGS, ...(rawSettings || {}) };
    settings.strategy = settings.strategy === 'GOLD' ? 'GOLD' : 'EXP';
    restoreRuntime(rawRuntime);
    syncHistoryFromRecorder();
    if (runtime.currentOptions.length && runtime.phase === 1) calculate();
    else emit();
  }).catch(() => emit());
})();
