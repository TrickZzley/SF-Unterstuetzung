(function(root,factory){const api=factory();if(typeof module!=='undefined'&&module.exports)module.exports=api;root.SFExpeditionResearchQuality=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const EXPECTED_STEPS=10;

  function isCompleteDecision(step){
    if(!step||typeof step!=='object')return false;
    const position=Number(step.selectedPosition),eventId=Number(step.selectedEventId),points=Number(step.selectedServerPoints);
    if(step.selectedPosition==null||step.selectedEventId==null||step.selectedServerPoints==null)return false;
    if(!Number.isInteger(position)||position<1||position>3||!Number.isFinite(eventId)||!Number.isFinite(points))return false;
    const options=Array.isArray(step.options)?step.options:[];
    return options.some(option=>Number(option?.position)===position&&Number(option?.eventId)===eventId&&Number(option?.serverPoints)===points);
  }

  function classifyRun(run){
    const completed=Boolean(run?.completed&&run?.endedAt),steps=Array.isArray(run?.steps)?run.steps:[],tenSteps=steps.length===EXPECTED_STEPS,completeDecisions=tenSteps&&steps.every(isCompleteDecision);
    return{completed,tenSteps,completeDecisions,usable:completed&&tenSteps&&completeDecisions};
  }

  function isCleanCompletedRun(run){return classifyRun(run).usable;}

  return{version:'2.1.0',EXPECTED_STEPS,isCompleteDecision,classifyRun,isCleanCompletedRun};
});
