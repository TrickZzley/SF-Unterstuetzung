(() => {
  'use strict';
  if (globalThis.SFExpeditionAdvisorData) return;

  const EVENTS = {
    1:{id:1,name:'Attrappe 1.0',points:1},2:{id:2,name:'Attrappe 2.0',points:2},3:{id:3,name:'Attrappe 3.0',points:3},
    11:{id:11,name:'Klopapier',points:0},
    21:{id:21,name:'Köder',points:-2},22:{id:22,name:'Drache',points:10},
    31:{id:31,name:'Lagerfeuer',points:3},32:{id:32,name:'Phönix',points:5},33:{id:33,name:'Abgebranntes Lagerfeuer',points:0},
    41:{id:41,name:'Horn',points:1},42:{id:42,name:'Esel',points:3},43:{id:43,name:'Regenbogen',points:5},44:{id:44,name:'Einhorn',points:7},
    51:{id:51,name:'Hühnerkeule',points:3,nextChoiceCount:2},61:{id:61,name:'Spanferkel',points:5,nextChoiceCount:1},
    71:{id:71,name:'Kleine Hürde',points:-1},72:{id:72,name:'Große Hürde',points:-2},73:{id:73,name:'Siegertreppchen',points:15},
    81:{id:81,name:'Socken',points:0},82:{id:82,name:'Kleiderhaufen',points:0},83:{id:83,name:'Paar',points:12},
    91:{id:91,name:'Schwert im Stein',points:6},92:{id:92,name:'Verbogenes Schwert',points:3},93:{id:93,name:'Abgebrochenes Schwert',points:-4},
    101:{id:101,name:'Kessel',points:2},102:{id:102,name:'Hexe',points:-5},103:{id:103,name:'Hexensud',points:15},
    111:{id:111,name:'Feenquelle',points:8},112:{id:112,name:'Verseuchte Feenquelle',points:-4},
    121:{id:121,name:'Hand',points:-5},122:{id:122,name:'Füße',points:-5},123:{id:123,name:'Körper',points:-5},124:{id:124,name:'Klaus',points:35},
    131:{id:131,name:'Schlüssel',points:0,treasureType:'key'},132:{id:132,name:'Schatztruhe',points:0,treasureType:'chest'},
    141:{id:141,name:'Angel',points:0},142:{id:142,name:'Köder',points:3},143:{id:143,name:'Meermann',points:9},
    151:{id:151,name:'Krüge',points:0},152:{id:152,name:'Fassbier',points:6},153:{id:153,name:'Zapfender Wirt',points:6},
    161:{id:161,name:'Hühnchen',points:0},162:{id:162,name:'Tiger',points:9},163:{id:163,name:'Reitender Stan',points:3},
    181:{id:181,name:'Belegte Liege',points:3},182:{id:182,name:'Saufgelage',points:3},183:{id:183,name:'Badetourist',points:6},
    191:{id:191,name:'Laubbläser',points:4},192:{id:192,name:'Blätterwirbel',points:2},193:{id:193,name:'Laubbold',points:6},

    1000:{id:1000,name:'Kopfgeld: Attrappe',points:0,bountyTargets:[1,2,3],bountyBonus:10,bountyConfidence:'confirmed'},
    1002:{id:1002,name:'Kopfgeld: Drache',points:0,bountyTargets:[22],bountyBonus:10,bountyConfidence:'confirmed'},
    1003:{id:1003,name:'Kopfgeld: Abgebranntes Lagerfeuer',points:0,bountyTargets:[33],bountyBonus:10,bountyConfidence:'confirmed'},
    1004:{id:1004,name:'Kopfgeld: Einhorn',points:0,bountyTargets:[44],bountyBonus:10,bountyConfidence:'confirmed'},
    1007:{id:1007,name:'Kopfgeld: Siegertreppchen',points:0,bountyTargets:[73],bountyBonus:10,bountyConfidence:'confirmed'},
    1008:{id:1008,name:'Kopfgeld: Paar',points:0,bountyTargets:[83],bountyBonus:10,bountyConfidence:'confirmed'},
    1009:{id:1009,name:'Kopfgeld: Abgebrochenes Schwert',points:0,bountyTargets:[93],bountyBonus:10,bountyConfidence:'confirmed'},
    1010:{id:1010,name:'Kopfgeld: Hexensud',points:0,bountyTargets:[103],bountyBonus:10,bountyConfidence:'confirmed'},
    1011:{id:1011,name:'Kopfgeld: Verseuchte Feenquelle',points:0,bountyTargets:[112],bountyBonus:10,bountyConfidence:'confirmed'},
    1012:{id:1012,name:'Kopfgeld: Klaus',points:0,bountyTargets:[124],bountyBonus:10,bountyConfidence:'confirmed'},
    1014:{id:1014,name:'Kopfgeld: Meermann',points:0,bountyTargets:[143],bountyBonus:10,bountyConfidence:'confirmed'},
    1015:{id:1015,name:'Kopfgeld: Zapfender Wirt',points:0,bountyTargets:[153],bountyBonus:10,bountyConfidence:'confirmed'},
    1016:{id:1016,name:'Kopfgeld: Reitender Stan',points:0,bountyTargets:[163],bountyBonus:10,bountyConfidence:'confirmed'},
    1018:{id:1018,name:'Kopfgeld: Badetourist',points:0,bountyTargets:[183],bountyBonus:10,bountyConfidence:'confirmed'},
    1019:{id:1019,name:'Kopfgeld: Laubbold',points:0,bountyTargets:[193],bountyBonus:10,bountyConfidence:'confirmed'}
  };

  const MISSIONS = {
    11:{id:11,name:'Sanitärer Notstand',type:'repeatedCount',eventId:11,requiredCount:3,successBonus:20,failurePenalty:-5},
    22:{id:22,name:'Drachenzähmen',type:'repeatWhole',chain:[21,22],maxCycles:2,perCompletionBonus:5,failurePenalty:0},
    33:{id:33,name:'Erloschenes Feuer',type:'unlockRepeatTail',chain:[31,32,33],tailEventId:33,tailMax:8,perCompletionBonus:4,failurePenalty:0},
    44:{id:44,name:'Einhornflüsterer',type:'once',chain:[41,42,43,44],successBonus:10,failurePenalty:0},
    61:{id:61,name:'Heiße Fleischeslust',type:'singleRepeat',eventId:61,maxCompletions:10,perCompletionBonus:3,failurePenalty:0},
    73:{id:73,name:'Treppchenstürmer',type:'repeatWhole',chain:[71,72,73],maxCycles:2,perCompletionBonus:10,failurePenalty:0},
    83:{id:83,name:'Freizügige Dame',type:'once',chain:[81,82,83],successBonus:5,failurePenalty:-5},
    93:{id:93,name:'Die Schwertprobe',type:'unlockRepeatTail',chain:[91,92,93],tailEventId:93,tailMax:8,perCompletionBonus:8,failurePenalty:0},
    103:{id:103,name:'Verhexter Eintopf',type:'once',chain:[101,102,103],successBonus:5,failurePenalty:-5},
    112:{id:112,name:'Toxische Quellenkur',type:'unlockRepeatTail',chain:[111,112],tailEventId:112,tailMax:9,perCompletionBonus:8,failurePenalty:0},
    124:{id:124,name:'Bau einen Freund',type:'once',chain:[121,122,123,124],successBonus:10,failurePenalty:-5},
    143:{id:143,name:'Meer als nur ein Fisch',type:'once',chain:[141,142,143],successBonus:5,failurePenalty:-5},
    153:{id:153,name:'Hopfen und Malz Verloren?',type:'once',chain:[151,152,153],successBonus:5,failurePenalty:-5},
    163:{id:163,name:'Mit Huhn und Haar',type:'once',chain:[161,162,163],successBonus:5,failurePenalty:-5},
    183:{id:183,name:'Strandauszeit',type:'once',chain:[181,182,183],successBonus:10,failurePenalty:-10},
    193:{id:193,name:'Vom Winde Verweht',type:'once',chain:[191,192,193],successBonus:10,failurePenalty:-10}
  };

  // Relations are derived from the mission definitions so duplicate names such as
  // "Köder" never need to be resolved globally by name inside the advisor.
  for(const m of Object.values(MISSIONS)){
    const chain=Array.isArray(m.chain)?m.chain.map(Number):[];
    if(m.type==='repeatedCount'&&Number.isFinite(Number(m.eventId))&&!chain.length)m.chain=Array(Math.max(1,Number(m.requiredCount)||1)).fill(Number(m.eventId));
    if(m.type==='singleRepeat'&&Number.isFinite(Number(m.eventId))&&!chain.length)m.chain=[Number(m.eventId)];
    const effective=Array.isArray(m.chain)?m.chain.map(Number):[];
    effective.forEach((id,index)=>{
      const e=EVENTS[id];if(!e)return;
      e.missionIds=Array.from(new Set([...(e.missionIds||[]),Number(m.id)]));
      e.chain=[...effective];
      e.previousEventIds=index>0?[Number(effective[index-1])]:[];
      e.nextEventIds=index<effective.length-1?[Number(effective[index+1])]:[];
    });
  }
  EVENTS[131].chain=[131,132];EVENTS[131].nextEventIds=[132];EVENTS[131].previousEventIds=[];
  EVENTS[132].chain=[131,132];EVENTS[132].previousEventIds=[131];EVENTS[132].nextEventIds=[];

  const RESEARCH = {
    source:'Supabase expedition_research_batches',
    snapshotAt:'2026-09-03T20:08:34Z',
    cleanRuns:96,
    fullySelectedRuns:93,
    partialCompletedRuns:3,
    totalDecisionRounds:960,
    choiceExpectedMax:{'1':1.2424,'2':3.0667,'3':3.9353},
    choiceMaxDistribution:{
      '1':[[-5,.0909],[-4,.0606],[-2,.0606],[-1,.0303],[0,.1818],[1,.0303],[2,.1818],[3,.1818],[5,.1212],[9,.0606]],
      '2':[[0,.2],[2,.3],[3,.3],[5,.0333],[6,.0333],[8,.0667],[10,.0667]],
      '3':[[-2,.0022],[-1,.0033],[0,.1260],[1,.0334],[2,.2219],[3,.2542],[4,.0346],[5,.1249],[6,.0769],[7,.0033],[8,.0212],[9,.0290],[10,.0323],[12,.0167],[15,.0100],[35,.0100]]
    },
    offerRate:{
      1:.1010,2:.3667,3:.1062,11:.0115,21:.0885,22:.0323,31:.0573,32:.0240,33:.0250,41:.0427,42:.0083,43:.0052,44:.0042,51:.1875,61:.1115,71:.0740,72:.0073,73:.0052,81:.0604,82:.0167,83:.0156,91:.0240,92:.0135,93:.0146,101:.0396,102:.0146,103:.0042,111:.0229,112:.0531,121:.0698,122:.0135,123:.0094,124:.0094,131:.2552,132:.0396,141:.0615,142:.0125,143:.0104,151:.0615,152:.0250,153:.0146,161:.0563,162:.0208,163:.0156,191:.0396,192:.0187,193:.0135,1000:.1115,1002:.0063,1003:.0135,1004:.0042,1007:.0031,1008:.0073,1009:.0052,1010:.0063,1011:.0031,1012:.0052,1014:.0021,1015:.0063,1016:.0104,1019:.0083
    },
    chainTransitions:{
      '21>22':{n:26,pSeen:.9231,avgRounds:1.75,exposures:50,offered:27,hazard:.5400},'31>32':{n:22,pSeen:.7727,avgRounds:2.1176,exposures:71,offered:23,hazard:.3239},'32>33':{n:15,pSeen:.6667,avgRounds:2.2,exposures:37,offered:15,hazard:.4054},
      '41>42':{n:9,pSeen:.6667,avgRounds:1.5,exposures:19,offered:8,hazard:.4211},'42>43':{n:5,pSeen:1,avgRounds:2,exposures:10,offered:5,hazard:.5},'43>44':{n:4,pSeen:1,avgRounds:1.25,exposures:5,offered:4,hazard:.8},
      '71>72':{n:5,pSeen:1,avgRounds:1.8,exposures:10,offered:6,hazard:.6},'72>73':{n:4,pSeen:1,avgRounds:2.25,exposures:9,offered:4,hazard:.4444},'81>82':{n:12,pSeen:1,avgRounds:1.3333,exposures:23,offered:16,hazard:.6957},'82>83':{n:12,pSeen:.9167,avgRounds:1.3636,exposures:25,offered:15,hazard:.6},
      '91>92':{n:9,pSeen:1,avgRounds:1.7778,exposures:31,offered:12,hazard:.3871},'92>93':{n:5,pSeen:.8,avgRounds:1.25,exposures:6,offered:5,hazard:.8333},'101>102':{n:10,pSeen:1,avgRounds:2.5,exposures:44,offered:14,hazard:.3182},'102>103':{n:4,pSeen:1,avgRounds:1.5,exposures:6,offered:4,hazard:.6667},
      '111>112':{n:17,pSeen:.8235,avgRounds:2.2857,exposures:86,offered:34,hazard:.3953},'121>122':{n:11,pSeen:1,avgRounds:1.8182,exposures:24,offered:13,hazard:.5417},'122>123':{n:10,pSeen:.9,avgRounds:1.4444,exposures:14,offered:9,hazard:.6429},'123>124':{n:9,pSeen:1,avgRounds:1.6667,exposures:15,offered:9,hazard:.6},
      '131>132':{n:45,pSeen:.5778,avgRounds:2.7308,exposures:166,offered:35,hazard:.2108},'141>142':{n:8,pSeen:1,avgRounds:1.625,exposures:20,offered:12,hazard:.6},'142>143':{n:8,pSeen:.75,avgRounds:1.8333,exposures:25,offered:10,hazard:.4},
      '151>152':{n:16,pSeen:1,avgRounds:2.375,exposures:60,offered:24,hazard:.4},'152>153':{n:15,pSeen:.8,avgRounds:1.75,exposures:27,offered:14,hazard:.5185},'161>162':{n:17,pSeen:1,avgRounds:1.5294,exposures:39,offered:20,hazard:.5128},'162>163':{n:15,pSeen:.9333,avgRounds:1.3571,exposures:21,offered:15,hazard:.7143},
      '191>192':{n:18,pSeen:.8333,avgRounds:2.5333,exposures:50,offered:16,hazard:.32},'192>193':{n:14,pSeen:.7857,avgRounds:1.7273,exposures:27,offered:13,hazard:.4815}
    },
    missionEventHazard:{
      'repeatedCount:11':{n:13,offered:11,p:.8462},'unlockRepeatTail:33':{n:26,offered:17,p:.6538},'singleRepeat:61':{n:30,offered:17,p:.5667},'unlockRepeatTail:93':{n:23,offered:13,p:.5652},'unlockRepeatTail:112':{n:40,offered:19,p:.4750}
    },
    bountyReach:{
      1000:{n:81,pTarget:.9259},1002:{n:3,pTarget:1},1003:{n:2,pTarget:.5},1004:{n:3,pTarget:.6667},1007:{n:2,pTarget:0},1008:{n:5,pTarget:1},1009:{n:2,pTarget:1},1010:{n:2,pTarget:1},1011:{n:3,pTarget:.6667},1012:{n:2,pTarget:1},1014:{n:1,pTarget:1},1015:{n:6,pTarget:.5},1016:{n:5,pTarget:1},1019:{n:4,pTarget:1}
    },
    treasure:{keyHeldRoomExposures:166,chestOfferedAfterKey:35,chestHazardAfterKey:.2108},
    missionPrior:{
      11:{n:3,p40:1},22:{n:10,p40:.8},33:{n:5,p40:.6},44:{n:4,p40:1},61:{n:3,p40:1},73:{n:6,p40:.6667},83:{n:12,p40:.75},93:{n:4,p40:1},103:{n:4,p40:1},112:{n:5,p40:.4},124:{n:9,p40:1},143:{n:3,p40:1},153:{n:9,p40:.7778},163:{n:11,p40:.5455},193:{n:8,p40:.875}
    }
  };

  globalThis.SFExpeditionAdvisorData = {
    version:'2.1.0-research-96',
    events:EVENTS,
    missions:MISSIONS,
    research:RESEARCH,
    bountyRules:{maxActivations:3,consumeOnTarget:true},
    starThresholds:{one:20,two:30,three:40}
  };
})();
