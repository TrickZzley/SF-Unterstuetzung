'use strict';

const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_YxF1169D1W1vE5RCjYca4w_3nQd6tZY';
const SHARED_SYNC_URL =
  'https://obaxwwzlcwbawbzaqzlo.supabase.co/functions/v1/scrapbook-sync';
const EXPEDITION_RESEARCH_URL =
  'https://obaxwwzlcwbawbzaqzlo.supabase.co/functions/v1/expedition-research-sync';

function isAllowedSharedPayload(payload) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return false;
  const action = String(payload.action || '').toLowerCase();
  return action === 'ping' || action === 'push' || action === 'pull' || action === 'stats';
}

function isAllowedResearchPayload(payload) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return false;
  const action = String(payload.action || '').toLowerCase();
  return action === 'ping' || action === 'upload';
}

async function postJson(url, payload) {
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'apikey': SUPABASE_PUBLISHABLE_KEY,
      'x-sf-support-version': '1.9.4'
    },
    body: JSON.stringify(payload),
    cache: 'no-store'
  });

  let data;
  try {
    data = await response.json();
  } catch (_) {
    throw new Error(`Sync-Server antwortet ungültig (${response.status}).`);
  }

  return { transportOk: response.ok, status: response.status, data };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== 'object') return;

  if (message.type === 'SF_SHARED_SYNC_REQUEST') {
    if (!isAllowedSharedPayload(message.payload)) {
      sendResponse({ transportOk: false, error: 'Ungültige Sync-Anfrage.' });
      return;
    }

    postJson(SHARED_SYNC_URL, message.payload)
      .then(sendResponse)
      .catch(error => {
        sendResponse({ transportOk: false, error: error?.message || String(error) });
      });
    return true;
  }

  if (message.type === 'SF_EXPEDITION_RESEARCH_REQUEST') {
    if (!isAllowedResearchPayload(message.payload)) {
      sendResponse({ transportOk: false, error: 'Ungültige Forschungsdaten-Anfrage.' });
      return;
    }

    postJson(EXPEDITION_RESEARCH_URL, message.payload)
      .then(sendResponse)
      .catch(error => {
        sendResponse({ transportOk: false, error: error?.message || String(error) });
      });
    return true;
  }
});
