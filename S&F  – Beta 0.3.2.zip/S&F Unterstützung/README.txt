S&F Unterstützung – Beta 0.3.2

DIESER STAND IST DIE NEUE SAUBERE VOLLVERSION.

Character
- Character-Reiter und Character-Icon wurden aus dem vom Nutzer zuletzt hochgeladenen Backup übernommen.
- Keine funktionale Erweiterung dieses Reiters.

Expedition
- Neuester stabiler EXP/GOLD-Advisor aus 2.0.1.
- 40-Punkte-/3-Sterne-Logik, GOLD-Strategie, Missionsketten, Kopfgelder, Schlüssel/Truhen und 1/2/3-Auswahl-Folgeräume.
- Missions-Endabrechnung aus 2.0.1 enthalten.
- Bekannte Namen werden immer aus der kanonischen ID-Datenbasis gelesen.
- Alte lokale Editor-Overrides werden nicht mehr in die Laufzeit geladen.
- Keine sichtbare oder öffentliche Funktion zum Bearbeiten von Ereignissen/Missionen.
- EXPEDITION-DATENBANK.json enthält die lesbare ID↔Name-Referenz.
- Forschungsmodell bleibt bewusst auf dem geprüften 95-Run-Snapshot; neuere Runs wurden noch nicht neu gewichtet.
- Recorder zählt/exportiert/überträgt nur vollständige, nicht-recovered 10/10-Runs.

Arena
- Bis zu drei zuletzt erkannte Gegner.
- Siegchance über 5.000 Simulationen.
- Manuelles Neuberechnen über Refresh-Button.

Sammelalbum
- Neuester Speicher-/Lag-Fix (gebündelte Speicherung, kein automatischer Hintergrund-Sync).
- Top 5 nach Anzahl fehlender Items.
- Nur Gegner mit mindestens 5,00 % Siegchance.
- Prozentchance wird angezeigt.
- Sobald ein Ziel 0 fehlende Items hat, fällt es aus der Liste und der nächste geeignete Gegner rückt nach.
- Kampfsimulation wurde zusätzlich auf die für Top 5 relevanten Kandidaten begrenzt, um unnötige Last zu reduzieren.

Nicht enthalten
- Keine UI-Vergrößerung.
- Kein Ziehen/automatisches UI-Skalieren.
- Kein Expeditionsdaten-Editor.
- Keine alten ungenutzten Top-Level arena.js/scrapbook.js-Doppeldateien.
