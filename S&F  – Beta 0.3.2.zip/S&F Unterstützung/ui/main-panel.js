(() => {
  'use strict';
  if (globalThis.__SF_SUPPORT_MAIN_PANEL__) return;
  globalThis.__SF_SUPPORT_MAIN_PANEL__ = true;

  let root = null;
  let body = null;
  let title = null;
  let blackout = null;
  let currentView = 'arena';
  const renderers = new Map();

  function escapeHtml(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  let interactionShieldInstalled = false;

  function isEventInsideOpenPanel(event) {
    if (!root?.isConnected || root.classList.contains('hidden')) return false;
    const path = event.composedPath?.() || [];
    if (path.includes(root) || root.contains(event.target)) return true;
    const active = document.activeElement;
    return Boolean(active && root.contains(active));
  }

  function installInteractionShield() {
    if (interactionShieldInstalled) return;
    interactionShieldInstalled = true;

    const stopGameEvent = event => {
      if (!isEventInsideOpenPanel(event)) return;
      // Do not call preventDefault(): browser-native input/editing must keep working.
      event.stopImmediatePropagation();
      event.stopPropagation();
    };

    const hoverEvents = ['mousemove','mouseover','mouseout','pointermove','pointerover','pointerout'];
    for (const type of hoverEvents) window.addEventListener(type, stopGameEvent, true);

    // Register at document_start so S&F hotkey handlers installed later never see
    // keystrokes whose focus/target belongs to the open support panel.
    const keyboardEvents = ['keydown','keypress','keyup'];
    for (const type of keyboardEvents) window.addEventListener(type, stopGameEvent, true);
  }

  // Install immediately; root may not exist yet, but the listener order is then
  // established before the game registers its own keyboard shortcuts.
  installInteractionShield();

  function shieldPanelBubbling(panel) {
    const panelEvents = ['mousedown','mouseup','click','dblclick','contextmenu','pointerdown','pointerup','wheel'];
    for (const type of panelEvents) {
      panel.addEventListener(type, event => event.stopPropagation(), false);
    }
  }

  function updateBlackoutBounds() {
    if (!blackout?.isConnected || !root?.isConnected || root.classList.contains('hidden')) return;
    const rect = root.getBoundingClientRect();
    const extraBlackoutRight = 16;
    blackout.style.width = `${Math.ceil(rect.right + extraBlackoutRight)}px`;
  }

  function showBlackout() {
    if (!blackout?.isConnected) return;
    blackout.classList.remove('hidden');
    requestAnimationFrame(updateBlackoutBounds);
  }

  function hideBlackout() {
    if (!blackout?.isConnected) return;
    blackout.classList.add('hidden');
  }

  function assetUrl(file) {
    try { return globalThis.chrome?.runtime?.getURL?.(`assets/frame/${file}`) || ''; }
    catch { return ''; }
  }

  function frameImage(file, className) {
    const src = assetUrl(file);
    return src ? `<img class="${className}" src="${src}" alt="" draggable="false">` : '';
  }

  function ensure() {
    if (root?.isConnected) return root;
    if (!document.body) return null;

    installInteractionShield();

    blackout = document.createElement('div');
    blackout.id = 'sf-support-panel-blackout';
    blackout.classList.add('hidden');
    blackout.setAttribute('aria-hidden', 'true');
    document.body.appendChild(blackout);

    root = document.createElement('section');
    root.id = 'sf-support-main-panel';
    root.classList.add('hidden');

    const xUrl = chrome.runtime.getURL('assets/icons/x.png');

    root.innerHTML = `
      <div class="sf-support-frame-layer" aria-hidden="true">
        ${frameImage('fill.png', 'sf-support-frame-fill')}
        ${frameImage('top.png', 'sf-support-frame-edge sf-support-frame-top')}
        ${frameImage('bottom.png', 'sf-support-frame-edge sf-support-frame-bottom')}
        ${frameImage('left.png', 'sf-support-frame-edge sf-support-frame-left')}
        ${frameImage('right.png', 'sf-support-frame-edge sf-support-frame-right')}
        ${frameImage('top-left.png', 'sf-support-frame-corner sf-support-frame-top-left')}
        ${frameImage('top-right.png', 'sf-support-frame-corner sf-support-frame-top-right')}
        ${frameImage('bottom-left.png', 'sf-support-frame-corner sf-support-frame-bottom-left')}
        ${frameImage('bottom-right.png', 'sf-support-frame-corner sf-support-frame-bottom-right')}
      </div>
      <div class="sf-support-panel-surface">
        <header class="sf-support-panel-header">
          <div>
            <div class="sf-support-panel-kicker">S&F Unterstützung</div>
            <div id="sf-support-panel-title">Arena</div>
          </div>
          <button id="sf-support-panel-close" type="button" title="Panel schließen" aria-label="Panel schließen">
            <img src="${xUrl}" alt="" draggable="false">
          </button>
        </header>
        <div id="sf-support-panel-body"></div>
      </div>`;

    document.body.appendChild(root);
    shieldPanelBubbling(root);
    window.addEventListener('resize', updateBlackoutBounds);

    body = root.querySelector('#sf-support-panel-body');
    title = root.querySelector('#sf-support-panel-title');

    root.querySelector('#sf-support-panel-close').addEventListener('click', () => {
      root.classList.add('hidden');
      hideBlackout();
      globalThis.SFSupportSidebar?.clearActive?.();
    });

    render();
    return root;
  }

  function labels(id) {
    return {
      arena: 'Arena', expedition: 'Expedition', character: 'Charakter',
      scrapbook: 'Sammelalbum Hilfe', settings: 'Einstellungen'
    }[id] || id;
  }

  function show(view) {
    ensure();
    currentView = view;
    root.classList.remove('hidden');
    showBlackout();
    render();
    requestAnimationFrame(updateBlackoutBounds);
  }

  function hide() {
    if (!root?.isConnected) return;
    root.classList.add('hidden');
    hideBlackout();
  }

  function render() {
    if (!root || !body) return;
    title.textContent = labels(currentView);
    const renderer = renderers.get(currentView);
    if (renderer) renderer(body);
    else body.innerHTML = '<div class="sf-support-empty">Noch keine Ansicht verfügbar.</div>';
  }

  function registerRenderer(id, renderer) {
    renderers.set(id, renderer);
    if (id === currentView) render();
  }

  function isVisible() {
    return Boolean(root?.isConnected && !root.classList.contains('hidden'));
  }

  globalThis.SFSupportMainPanel = { ensure, show, hide, render, registerRenderer, escapeHtml, isVisible };
})();
