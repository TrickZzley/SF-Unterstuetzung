(() => {
  'use strict';
  if (globalThis.__SF_SUPPORT_LAYOUT__) return;
  globalThis.__SF_SUPPORT_LAYOUT__ = true;

  let last = null;

  function gameRect() {
    const candidates = [
      ...document.querySelectorAll('canvas'),
      ...document.querySelectorAll('#game, #content, .game, .game-container')
    ];

    let best = null;
    for (const element of candidates) {
      const rect = element.getBoundingClientRect?.();
      if (!rect || rect.width < 500 || rect.height < 400) continue;
      const area = rect.width * rect.height;
      if (!best || area > best.area) best = { rect, area };
    }

    if (best) return best.rect;

    const width = Math.min(window.innerWidth, Math.round(window.innerHeight * 1.85));
    return {
      left: Math.max(0, (window.innerWidth - width) / 2),
      top: 0,
      width,
      height: window.innerHeight
    };
  }

  function update() {
    const rect = gameRect();
    const root = document.documentElement;
    const left = Math.max(0, Math.round(rect.left));
    const top = Math.max(0, Math.round(rect.top));
    const height = Math.max(520, Math.round(rect.height || window.innerHeight));
    const menuWidth = Math.max(270, Math.min(335, Math.round((rect.width || 1500) * 0.205)));

    const next = `${left}|${top}|${height}|${menuWidth}`;
    if (next === last) return;
    last = next;

    root.style.setProperty('--sf-game-left', `${left}px`);
    root.style.setProperty('--sf-game-top', `${top}px`);
    root.style.setProperty('--sf-game-height', `${height}px`);
    root.style.setProperty('--sf-menu-width', `${menuWidth}px`);
    root.style.setProperty('--sf-sidebar-left', `${Math.max(4, left - 58)}px`);
  }

  function init() {
    update();
    window.addEventListener('resize', update, { passive: true });
    setInterval(update, 1000);
  }

  globalThis.SFSupportLayout = { update, gameRect };
  init();
})();
