(() => {
  'use strict';
  if (globalThis.__SF_SUPPORT_SIDEBAR__) return;
  globalThis.__SF_SUPPORT_SIDEBAR__ = true;

  const iconUrl = file => {
    try { return globalThis.chrome?.runtime?.getURL?.(`assets/icons/${file}`) || ''; }
    catch { return ''; }
  };

  const ITEMS = [
    { id: 'character', label: 'Charakter', iconFile: 'character.png' },
    { id: 'expedition', label: 'Expedition', iconFile: 'expedition.png' },
    { id: 'arena', label: 'Arena', iconFile: 'arena.png' }
  ];
  const SCRAPBOOK_ITEM = { id: 'scrapbook', label: 'Sammelalbum Hilfe', iconFile: 'scrapbook.png' };
  const SETTINGS_ITEM = { id: 'settings', label: 'Einstellungen', iconFile: 'settings.png' };

  const listeners = new Set();
  let active = null;
  let root = null;
  let scrapbookRoot = null;
  let settingsRoot = null;

  function makeIconMarkup(item) {
    const url = iconUrl(item.iconFile);
    if (url) return `<img class="sf-support-nav-image" src="${url}" alt="">`;
    return `<span class="sf-support-nav-icon">${item.label.slice(0, 1)}</span>`;
  }

  function makeButton(item) {
    const button = document.createElement('button');
    button.className = 'sf-support-nav-button';
    button.dataset.view = item.id;
    button.type = 'button';
    button.title = item.label;
    button.setAttribute('aria-label', item.label);
    button.innerHTML = `<span class="sf-support-nav-icon-wrap">${makeIconMarkup(item)}</span><span class="sf-support-badge"></span>`;
    button.addEventListener('click', () => select(item.id));
    return button;
  }

  function ensure() {
    if (root?.isConnected) return root;
    if (!document.body) return null;

    root = document.createElement('aside');
    root.id = 'sf-support-sidebar';

    const stack = document.createElement('div');
    stack.className = 'sf-support-nav-stack';
    ITEMS.forEach(item => stack.appendChild(makeButton(item)));
    root.appendChild(stack);
    document.body.appendChild(root);

    if (!scrapbookRoot?.isConnected) {
      scrapbookRoot = document.createElement('div');
      scrapbookRoot.id = 'sf-support-scrapbook-dock';
      const scrapbook = makeButton(SCRAPBOOK_ITEM);
      scrapbook.classList.add('sf-support-scrapbook-button');
      scrapbookRoot.appendChild(scrapbook);
      document.documentElement.appendChild(scrapbookRoot);
    }

    if (!settingsRoot?.isConnected) {
      settingsRoot = document.createElement('div');
      settingsRoot.id = 'sf-support-settings-dock';
      const settings = document.createElement('button');
      settings.className = 'sf-support-nav-button sf-support-settings-button';
      settings.dataset.view = 'settings';
      settings.type = 'button';
      settings.title = SETTINGS_ITEM.label;
      settings.setAttribute('aria-label', SETTINGS_ITEM.label);
      settings.innerHTML = `<span class="sf-support-nav-icon-wrap">${makeIconMarkup(SETTINGS_ITEM)}</span><span class="sf-support-badge"></span>`;
      settings.addEventListener('click', () => select('settings'));
      settingsRoot.appendChild(settings);
      document.documentElement.appendChild(settingsRoot);
    }

    setActiveClasses();
    return root;
  }

  function setActiveClasses() {
    for (const button of root?.querySelectorAll?.('[data-view]') || []) {
      button.classList.toggle('active', button.dataset.view === active);
    }
    for (const button of scrapbookRoot?.querySelectorAll?.('[data-view]') || []) {
      button.classList.toggle('active', button.dataset.view === active);
    }
    for (const button of settingsRoot?.querySelectorAll?.('[data-view]') || []) {
      button.classList.toggle('active', button.dataset.view === active);
    }
  }

  function select(id) {
    if (![...ITEMS.map(x => x.id), SCRAPBOOK_ITEM.id, 'settings'].includes(id)) return;
    if (active === id) {
      active = null;
      setActiveClasses();
      for (const listener of listeners) listener(null);
      return;
    }
    active = id;
    setActiveClasses();
    for (const listener of listeners) listener(id);
  }

  function onSelect(listener) {
    listeners.add(listener);
    return () => listeners.delete(listener);
  }

  function setBadge(id, text = '', kind = '') {
    ensure();
    const badge =
      root?.querySelector(`[data-view="${id}"] .sf-support-badge`) ||
      scrapbookRoot?.querySelector(`[data-view="${id}"] .sf-support-badge`) ||
      settingsRoot?.querySelector(`[data-view="${id}"] .sf-support-badge`);
    if (!badge) return;
    badge.textContent = text;
    badge.className = `sf-support-badge${kind ? ` ${kind}` : ''}`;
  }

  function clearActive() {
    active = null;
    setActiveClasses();
  }

  globalThis.SFSupportSidebar = {
    ensure, select, clearActive, onSelect, setBadge, getActive: () => active
  };
})();
