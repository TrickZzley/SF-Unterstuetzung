(() => {
  'use strict';
  if (globalThis.__SF_SUPPORT_SIMULATOR__) return;
  globalThis.__SF_SUPPORT_SIMULATOR__ = true;

  const CLASSES = {
    1: { name: 'Krieger', attribute: 'strength', health: 5, weapon: 2, damage: 1, maxDR: 50, drMul: 1, skip: 0.25, skipType: 'block', useBlockChance: true },
    2: { name: 'Magier', attribute: 'intelligence', health: 2, weapon: 4.5, damage: 1, maxDR: 10, drMul: 1, skip: 0, bypassDR: true, bypassSkip: true, bypassSpecial: true },
    3: { name: 'Kundschafter', attribute: 'dexterity', health: 4, weapon: 2.5, damage: 1, maxDR: 25, drMul: 1, skip: 0.50, skipType: 'evade' },
    4: { name: 'Assassine', attribute: 'dexterity', health: 4, weapon: 2, damage: 0.625, maxDR: 25, drMul: 1, skip: 0.50, skipType: 'evade' },
    5: { name: 'Kampfmagier', attribute: 'strength', health: 5, weapon: 2, damage: 1, maxDR: 10, drMul: 5, skip: 0 },
    6: { name: 'Berserker', attribute: 'strength', health: 4, weapon: 2, damage: 1.25, maxDR: 50, drMul: 0.5, skip: 0.50, controlSkip: true, skipLimit: 14 },
    7: { name: 'Dämonenjäger', attribute: 'dexterity', health: 4, weapon: 2.5, damage: 1, maxDR: 50, drMul: 1, skip: 0 },
    8: { name: 'Druide', attribute: 'intelligence', health: 5, weapon: 4.5, damage: 1 / 3, maxDR: 25, drMul: 1, skip: 0.35, skipType: 'evade' },
    9: { name: 'Barde', attribute: 'intelligence', health: 2, weapon: 4.5, damage: 1.125, maxDR: 25, drMul: 2, skip: 0 },
    10: { name: 'Nekromant', attribute: 'intelligence', health: 4, weapon: 4.5, damage: 5 / 9, maxDR: 10, drMul: 2, skip: 0 },
    11: { name: 'Paladin', attribute: 'strength', health: 6, weapon: 2, damage: 0.833, maxDR: 45, drMul: 1, skip: 0 },
    12: { name: 'Seuchendoktor', attribute: 'dexterity', health: 4, weapon: 2, damage: 1.25, maxDR: 10, drMul: 2, skip: 0.20, skipType: 'evade' }
  };

  const RUNE_FIRE = 40, RUNE_COLD = 41, RUNE_LIGHTNING = 42;
  const rand = p => p > 0 && Math.random() < p;
  const between = (min, max) => Math.random() * (1 + max - min) + min;
  const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
  const cfg = player => CLASSES[player?.classId] || CLASSES[1];
  const className = id => CLASSES[id]?.name || `Unbekannt (${id})`;
  const attr = (player, name) => Number(player?.attributes?.[name]?.total || 0);

  function calculateHealth(player) {
    let hp = attr(player, 'constitution');
    hp *= cfg(player).health;
    hp *= (Number(player.level) || 0) + 1;
    hp = Math.ceil(hp * (1 + Number(player?.potions?.life || 0) / 100));
    hp = Math.ceil(hp * (1 + Number(player?.dungeons?.player || 0) / 100));
    hp = Math.ceil(hp * (1 + Number(player?.runes?.health || 0) / 100));
    return Math.max(1, hp);
  }

  function baseDamageRange(player, secondary = false) {
    if ((player.level || 0) <= 10) return { min: 1, max: 2 };
    let multiplier = 0.7;
    if (player.classId === 4) multiplier = secondary ? 1.25 : 0.875;
    const n = multiplier * (player.level - 9) * cfg(player).weapon;
    return { min: Math.max(1, Math.ceil(n * 2 / 3)), max: Math.max(2, Math.round(n * 4 / 3)) };
  }

  function weaponInfo(player, secondary = false) {
    const item = secondary ? player?.items?.wpn2 : player?.items?.wpn1;
    const fallback = secondary ? player?.damage2 : player?.damage;
    const base = baseDamageRange(player, secondary);
    const rawMin = Number(item?.damageMin || fallback?.min || 0);
    const rawMax = Number(item?.damageMax || fallback?.max || 0);
    const useRaw = rawMin >= base.min || rawMax >= base.max;
    return {
      min: Math.max(1, useRaw ? rawMin : base.min),
      max: Math.max(2, useRaw ? rawMax : base.max),
      runeType: Number(item?.runeType || 0),
      runeValue: Number(item?.runeValue || 0),
      enchanted: !!item?.hasEnchantment
    };
  }

  function resistanceForRune(defender, runeType) {
    if (runeType === RUNE_FIRE) return Number(defender?.runes?.resistanceFire || 0);
    if (runeType === RUNE_COLD) return Number(defender?.runes?.resistanceCold || 0);
    if (runeType === RUNE_LIGHTNING) return Number(defender?.runes?.resistanceLightning || 0);
    return 0;
  }

  function elementalMultiplier(weapon, defender) {
    if (![RUNE_FIRE, RUNE_COLD, RUNE_LIGHTNING].includes(weapon.runeType)) return 1;
    const runeDamage = Math.min(60, Math.max(0, weapon.runeValue));
    const resistance = Math.min(75, Math.max(0, resistanceForRune(defender, weapon.runeType)));
    return 1 + (1 - resistance / 100) * (runeDamage / 100);
  }

  function maximumDamageReduction(defenderState) {
    let max = cfg(defenderState.player).maxDR;
    if (defenderState.player.classId === 11 && defenderState.paladinStance === 2) max -= 25;
    return max;
  }

  function damageReduction(defenderState, attackerState) {
    if (cfg(attackerState.player).bypassDR) return 0;
    const max = maximumDamageReduction(defenderState);
    return cfg(defenderState.player).drMul * Math.min(max, defenderState.player.armor / Math.max(1, attackerState.player.level));
  }

  function classDamageMultiplier(attacker, defender, specialBonus = 0) {
    let value = cfg(attacker).damage + specialBonus;
    if (attacker.classId === 10 && defender.classId === 7) value += 0.10;
    if (attacker.classId === 2 && defender.classId === 11) value *= 1.50;
    if (attacker.classId === 8 && defender.classId === 7) value *= 1.15;
    if (attacker.classId === 8 && defender.classId === 2) value *= 4 / 3;
    if (attacker.classId === 9 && defender.classId === 12) value *= 1.05;
    if (attacker.classId === 11 && defender.classId === 2) value *= 1.50;
    if (attacker.classId === 12 && defender.classId === 7) value *= 1.065;
    return value;
  }

  function damageBase(attackerState, defenderState, weapon, specialBonus = 0) {
    const attacker = attackerState.player, defender = defenderState.player;
    const main = attr(attacker, cfg(attacker).attribute);
    const defenseAttribute = attr(defender, cfg(attacker).attribute) / 2;
    const attributeFactor = 1 + Math.max(main / 2, main - defenseAttribute) / 10;
    const groupBonus = 1 + Number(attacker?.dungeons?.group || 0) / 100;
    const armorFactor = 1 - damageReduction(defenderState, attackerState) / 100;
    return groupBonus * armorFactor * elementalMultiplier(weapon, defender) * classDamageMultiplier(attacker, defender, specialBonus) * attributeFactor;
  }

  function criticalChance(attacker, defender, maxChance = 0.50, bonus = 0) {
    return Math.min(maxChance, bonus + attr(attacker, 'luck') * 2.5 / Math.max(1, defender.level) / 100);
  }

  function baseCriticalMultiplier(attacker, defender) {
    const w1 = weaponInfo(attacker, false);
    const w2 = attacker.classId === 4 ? weaponInfo(attacker, true) : null;
    let multiplier = 2;
    if (w1.enchanted || w2?.enchanted) multiplier += 0.05;
    const ownGladiator = Number(attacker?.fortress?.gladiator || 0);
    const enemyGladiator = Number(defender?.fortress?.gladiator || 0);
    multiplier += 0.11 * Math.max(0, ownGladiator - enemyGladiator);
    return multiplier;
  }

  function specialCriticalMultiplier(attacker, defender, critBonus = 0) {
    return baseCriticalMultiplier(attacker, defender) * ((2 + critBonus) / 2);
  }

  function createFighter(player, index) {
    const maxHp = calculateHealth(player);
    return { index, player, hp: maxHp, maxHp, skipCount: 0, deathTriggers: 0, druidRageRequested: false,
      druidRageActive: false, swoopChance: 0.15, bardRound: 4, bardEffect: null, bardRemaining: 0,
      minion: null, paladinStance: 0, tinctureDuration: 0, attackFirst: !!player.attackFirst };
  }

  function skipChance(defenderState, attackerState) {
    if (cfg(attackerState.player).bypassSkip) return 0;
    const defender = defenderState.player;
    if (defender.classId === 1 && typeof defender.blockChance !== 'undefined') return clamp(Number(defender.blockChance) / 100, 0, 1);
    if (defender.classId === 11) {
      if (defenderState.paladinStance === 0) return 0.30;
      if (defenderState.paladinStance === 1) return 0.50;
      return 0.25;
    }
    if (defender.classId === 10 && defenderState.minion?.type === 3) return 0.25;
    if (defender.classId === 12 && defenderState.tinctureDuration > 0) {
      if (defenderState.tinctureDuration === 3) return 0.65;
      if (defenderState.tinctureDuration === 2) return 0.50;
      return 0.35;
    }
    if (defender.classId === 8 && defenderState.druidRageActive) return 0;
    return cfg(defender).skip || 0;
  }

  function getRage(battle) { return 1 + battle.turn++ / 6; }

  function applyDamage(defender, attacker, damage, skipped, battle) {
    if (skipped) {
      defender.skipCount++;
      if (defender.player.classId === 8 && !defender.druidRageActive) defender.druidRageRequested = true;
      if (defender.player.classId === 11 && defender.paladinStance === 1) {
        const missing = Math.max(0, defender.maxHp - defender.hp);
        defender.hp += Math.min(missing, Math.max(0, damage) * 0.30);
      }
      return true;
    }
    defender.skipCount = 0;
    defender.hp -= Math.trunc(damage);
    if (defender.hp <= 0 && defender.player.classId === 7 && !cfg(attacker.player).bypassSpecial) {
      const reviveChance = 0.44 - 0.11 * defender.deathTriggers;
      if (reviveChance > 0 && rand(reviveChance)) {
        const hpFraction = Math.max(0.10, 0.90 - 0.10 * defender.deathTriggers);
        defender.hp = defender.maxHp * hpFraction;
        defender.deathTriggers++;
        getRage(battle);
      }
    }
    return defender.hp > 0;
  }

  function performAttack(attacker, defender, battle, options = {}) {
    if (attacker.hp <= 0 || defender.hp <= 0) return false;
    const weapon = weaponInfo(attacker.player, !!options.secondary);
    const base = damageBase(attacker, defender, weapon, options.damageBonus || 0);
    let damage = getRage(battle) * between(base * weapon.min, base * weapon.max);
    if (options.damageMultiplier) damage *= options.damageMultiplier;
    if (rand(criticalChance(attacker.player, defender.player, options.critMax ?? 0.50, options.critChanceBonus ?? 0))) {
      damage *= specialCriticalMultiplier(attacker.player, defender.player, options.critBonus || 0);
    }
    const skipped = options.unskippable ? false : rand(skipChance(defender, attacker));
    return applyDamage(defender, attacker, damage, skipped, battle);
  }

  function battlemageFireball(attacker, defender, battle) {
    if (attacker.player.classId !== 5) return;
    getRage(battle);
    if (cfg(defender.player).bypassSpecial) return;
    const damage = Math.min(Math.ceil(defender.maxHp / 3), Math.ceil(attacker.maxHp * 0.05 * cfg(defender.player).health));
    applyDamage(defender, attacker, damage, false, battle);
  }

  function updateBard(attacker, defender) {
    if (attacker.player.classId !== 9 || cfg(defender.player).bypassSpecial) return;
    attacker.bardRound++;
    if (attacker.bardRound >= 4) {
      const roll = Math.random();
      if (roll <= 0.25) { attacker.bardEffect = 1.20; attacker.bardRemaining = 3; }
      else if (roll <= 0.75) { attacker.bardEffect = 1.40; attacker.bardRemaining = 3; }
      else { attacker.bardEffect = 1.60; attacker.bardRemaining = 4; }
      attacker.bardRound = 0;
    }
  }

  function consumeBard(attacker) {
    if (!attacker.bardEffect || attacker.bardRemaining <= 0) return 1;
    const mult = attacker.bardEffect;
    attacker.bardRemaining--;
    if (attacker.bardRemaining <= 0) attacker.bardEffect = null;
    return mult;
  }

  function summonMinion(attacker) {
    const type = 1 + Math.floor(Math.random() * 3);
    if (type === 1) attacker.minion = { type, duration: 3, damageBonus: 0.25, critBonus: 0, critMax: 0.50, critChanceBonus: 0, revives: 1, reviveChance: 0.50 };
    else if (type === 2) attacker.minion = { type, duration: 2, damageBonus: 1, critBonus: 0.50, critMax: 0.60, critChanceBonus: 0.10, revives: 0, reviveChance: 0 };
    else attacker.minion = { type, duration: 4, damageBonus: 0, critBonus: 0, critMax: 0.50, critChanceBonus: 0, revives: 0, reviveChance: 0 };
  }

  function minionAttack(attacker, defender, battle) {
    if (!attacker.minion) return false;
    const m = attacker.minion;
    const alive = performAttack(attacker, defender, battle, { damageBonus: m.damageBonus, critBonus: m.critBonus, critMax: m.critMax, critChanceBonus: m.critChanceBonus });
    m.duration--;
    if (m.duration <= 0) {
      if (m.revives > 0 && rand(m.reviveChance)) { m.duration = 1; m.revives--; }
      else attacker.minion = null;
    }
    return alive;
  }

  function paladinDamageBonus(fighter) {
    if (fighter.player.classId !== 11) return 0;
    if (fighter.paladinStance === 1) return -0.265;
    if (fighter.paladinStance === 2) return 0.42;
    return 0;
  }

  function maybeChangePaladinStance(attacker, defender) {
    if (attacker.player.classId !== 11 || cfg(defender.player).bypassSpecial) return;
    if (rand(0.50)) attacker.paladinStance = (attacker.paladinStance + 1) % 3;
  }

  function plagueBonusByDuration(duration) {
    if (duration === 3) return -0.20;
    if (duration === 2) return -0.55;
    if (duration === 1) return -0.90;
    return 0;
  }

  function takeTurn(attacker, defender, battle) {
    if (attacker.hp <= 0 || defender.hp <= 0) return;
    const id = attacker.player.classId;
    maybeChangePaladinStance(attacker, defender);

    if (id === 8) {
      if (attacker.druidRageRequested) { attacker.druidRageRequested = false; attacker.druidRageActive = true; }
      else if (attacker.druidRageActive) attacker.druidRageActive = false;
      if (!cfg(defender.player).bypassSpecial && !attacker.druidRageActive && attacker.swoopChance > 0 && rand(attacker.swoopChance)) {
        attacker.swoopChance = clamp(attacker.swoopChance + 0.05, 0, 0.50);
        const swoopMultiplier = (cfg(attacker.player).damage + 0.8) / cfg(attacker.player).damage;
        if (!performAttack(attacker, defender, battle, { damageMultiplier: swoopMultiplier })) return;
      }
    }

    updateBard(attacker, defender);

    if (id === 10 && !cfg(defender.player).bypassSpecial) {
      if (attacker.minion) {
        if (!performAttack(attacker, defender, battle)) return;
        minionAttack(attacker, defender, battle);
        return;
      }
      if (rand(0.50)) { getRage(battle); summonMinion(attacker); minionAttack(attacker, defender, battle); return; }
    }

    if (id === 12 && !cfg(defender.player).bypassSpecial) {
      if (attacker.tinctureDuration > 0) {
        if (!performAttack(attacker, defender, battle, { damageBonus: plagueBonusByDuration(attacker.tinctureDuration), unskippable: true })) return;
        const alive2 = performAttack(attacker, defender, battle);
        attacker.tinctureDuration--;
        if (!alive2) return;
        return;
      }
      if (rand(0.50)) {
        attacker.tinctureDuration = 3;
        performAttack(attacker, defender, battle, { damageBonus: plagueBonusByDuration(3) });
        return;
      }
    }

    if (id === 4) {
      const alive = performAttack(attacker, defender, battle);
      if (alive) performAttack(attacker, defender, battle, { secondary: true });
      return;
    }

    const options = { damageBonus: paladinDamageBonus(attacker), damageMultiplier: consumeBard(attacker) };
    if (id === 8 && attacker.druidRageActive) { options.critMax = 0.75; options.critChanceBonus = 0.10; options.critBonus = 4; }
    performAttack(attacker, defender, battle, options);
  }

  function controlSkip(fighter, opponent) {
    if (!cfg(fighter.player).controlSkip || cfg(opponent.player).bypassSkip) return false;
    if (fighter.skipCount < (cfg(fighter.player).skipLimit || 14) && rand(cfg(fighter.player).skip)) { fighter.skipCount++; return true; }
    return false;
  }

  function simulateFight(playerA, playerB) {
    let a = createFighter(playerA, 0), b = createFighter(playerB, 1);
    const originalA = a, battle = { turn: 0 };
    if (a.attackFirst === b.attackFirst ? rand(0.50) : b.attackFirst) [a, b] = [b, a];
    battlemageFireball(a, b, battle); battlemageFireball(b, a, battle);
    let safety = 0;
    while (a.hp > 0 && b.hp > 0 && safety++ < 1000) {
      if (controlSkip(b, a)) getRage(battle); else takeTurn(a, b, battle);
      [a, b] = [b, a];
    }
    return originalA.hp > 0;
  }

  function simulate(player, opponent, iterations = 5000) {
    let wins = 0;
    for (let i = 0; i < iterations; i++) if (simulateFight(player, opponent)) wins++;
    const chance = wins / iterations * 100;
    return { wins, losses: iterations - wins, iterations, chance, chanceFormatted: `${chance.toFixed(2)}%`, playerClass: className(player.classId), opponentClass: className(opponent.classId) };
  }

  globalThis.SFSimulator = { simulate, simulateFight, className, classes: CLASSES, version: '2.0.0-arena' };
})();
