(() => {
  'use strict';
  if(globalThis.__SF_SUPPORT_CONTENT__)return;globalThis.__SF_SUPPORT_CONTENT__=true;
  const esc=v=>globalThis.SFSupportMainPanel?.escapeHtml?.(v)??String(v??'');
  const number=v=>new Intl.NumberFormat('de-DE').format(Number(v||0));
  const className=id=>globalThis.SFSimulator?.className?.(Number(id))||`Klasse ${id??'?'}`;
  const chanceClass=c=>c>=70?'good':c>=35?'medium':'bad';
  const scrapbookApi=()=>globalThis.SFSupportScrapbook;
  const scrapbookFightApi=()=>globalThis.SFSupportScrapbookFightFilter;
  const recorderApi=()=>globalThis.SFSupportExpeditionRecorder;
  const advisorApi=()=>globalThis.SFSupportExpeditionAdvisor;

  function copyText(value){const text=String(value||'');if(!text)return Promise.resolve(false);if(navigator.clipboard?.writeText)return navigator.clipboard.writeText(text).then(()=>true).catch(()=>false);try{const ta=document.createElement('textarea');ta.value=text;ta.style.position='fixed';ta.style.left='-9999px';document.documentElement.appendChild(ta);ta.select();const ok=document.execCommand('copy');ta.remove();return Promise.resolve(Boolean(ok));}catch{return Promise.resolve(false);}}

  function renderArena(host){const arena=globalThis.SFSupportArena;const state=arena?.getState?.()||{myPlayer:null,opponents:[],simulationRunning:false},me=state.myPlayer;if(!me){host.innerHTML='<div class="sf-support-empty"><b>Warte auf Charakterdaten …</b><br>Öffne bzw. aktualisiere S&F einmal. Es werden keine zusätzlichen Spielanfragen gesendet.</div>';return;}const needsSimulation=state.opponents.some(entry=>!entry.result);if(needsSimulation&&!state.simulationRunning)setTimeout(()=>arena?.ensureSimulated?.(),0);const cards=state.opponents.length?state.opponents.map((entry,index)=>{const result=entry.result,chance=Number(result?.chance||0);return`<article class="sf-support-card arena-card ${result?chanceClass(chance):''}"><div class="sf-support-card-head"><b>${index+1}. ${esc(entry.player.name)}</b><span>Lv. ${number(entry.player.level)}</span></div><div class="sf-support-muted">${esc(className(entry.player.classId))}</div><div class="sf-support-chance">${result?`${result.chance.toFixed(2)} %`:'Berechnung …'}</div><div class="sf-support-muted">${result?'5.000 Simulationen':'Simulation nur bei geöffnetem Arena-Tool'}</div></article>`;}).join(''):'<div class="sf-support-empty">Noch keine Gegnerdaten erkannt. Sobald S&F Gegnerdaten liefert, erscheinen hier bis zu drei Arena-Gegner.</div>';const refreshDisabled=!state.opponents.length;host.innerHTML=`<article class="sf-support-card me-card"><div class="sf-support-card-head"><b>${esc(me.name||'Du')}</b><span>Lv. ${number(me.level)}</span></div><div class="sf-support-muted">${esc(className(me.classId))}</div></article><div class="sf-arena-header"><div class="sf-support-section-title">Arena</div><button type="button" id="sf-arena-rerun" class="sf-arena-rerun ${state.simulationRunning?'is-running':''}" ${refreshDisabled?'disabled':''} title="Kämpfe neu simulieren" aria-label="Kämpfe neu simulieren"><img src="${chrome.runtime.getURL('assets/icons/refresh.png')}" alt=""></button></div>${cards}`;host.querySelector('#sf-arena-rerun')?.addEventListener('click',()=>arena?.rerunSimulations?.());}

  function renderCharacter(host) {
    const player = globalThis.SFSupportCharacter?.getPlayer?.();

    if (!player) {
      host.innerHTML = '<div class="sf-support-empty">Noch keine Charakterdaten erkannt.</div>';
      return;
    }

    const a = player.attributes || {};
    const runes = player.runes || {};
    const knightHall = player.knightHall || {};

    const runeRows = [
      ['Goldbonus', runes.gold],
      ['Epic-Chance', runes.epicChance],
      ['Gegenstandsqualität', runes.itemQuality],
      ['Erfahrungsbonus', runes.experience],
      ['Lebenspunkte', runes.health],
      ['Feuerresistenz', runes.resistanceFire],
      ['Kälteresistenz', runes.resistanceCold],
      ['Blitzresistenz', runes.resistanceLightning],
      ['Feuerschaden', runes.damageFire],
      ['Kälteschaden', runes.damageCold],
      ['Blitzschaden', runes.damageLightning],
      ['Waffe 2 · Feuerschaden', runes.damage2Fire],
      ['Waffe 2 · Kälteschaden', runes.damage2Cold],
      ['Waffe 2 · Blitzschaden', runes.damage2Lightning]
    ].filter(([, value]) => Number(value || 0) > 0);

    const runeHtml = runeRows.length
      ? `<div class="sf-support-rune-grid">${runeRows.map(([label, value]) => `<div class="sf-support-rune-row"><span>${esc(label)}</span><b>+${number(value)} %</b></div>`).join('')}</div>`
      : '<div class="sf-support-empty sf-support-compact-empty">Auf der aktuell erkannten Ausrüstung wurden noch keine Runen gefunden.</div>';

    const knownHall = value => value == null || !Number.isFinite(Number(value)) ? '–' : number(value);
    const hallSeen = Boolean(knightHall.sourceSeen);

    host.innerHTML = `
      <article class="sf-support-card">
        <div class="sf-support-card-head"><b>${esc(player.name)}</b><span>Lv. ${number(player.level)}</span></div>
        <div class="sf-support-muted">${esc(className(player.classId))}</div>
      </article>
      <div class="sf-support-section-title">Attribute</div>
      <div class="sf-support-stat-grid">
        <div><span>Rüstung</span><b>${number(player.armor)}</b></div>
        <div><span>Schaden</span><b>${number(player.damage?.min)}–${number(player.damage?.max)}</b></div>
        <div><span>Stärke</span><b>${number(a.strength?.total)}</b></div>
        <div><span>Geschick</span><b>${number(a.dexterity?.total)}</b></div>
        <div><span>Intelligenz</span><b>${number(a.intelligence?.total)}</b></div>
        <div><span>Ausdauer</span><b>${number(a.constitution?.total)}</b></div>
        <div><span>Glück</span><b>${number(a.luck?.total)}</b></div>
      </div>
      <div class="sf-support-section-title">Runen</div>
      ${runeHtml}
      <div class="sf-support-section-title">Ritterhalle</div>
      <div class="sf-support-knight-grid sf-support-knight-grid-single">
        <div><span>Eigene Ritterhalle</span><b>${knownHall(knightHall.own)}</b></div>
      </div>
      <div class="sf-support-character-note">${hallSeen
        ? 'Eigene Ritterhalle wurde passiv aus den zuletzt gesehenen Gildendaten übernommen.'
        : 'Eigene Ritterhalle noch nicht passiv erkannt. Es werden keine zusätzlichen Anfragen gesendet.'}</div>`;
  }

  function renderExpedition(host){
    const advisor=advisorApi()?.getState?.()||{},rec=recorderApi(),recStatus=rec?.getStatus?.()||{enabled:false,runs:0},rt=advisor.runtime||{},recommend=advisor.recommendation?.selected?.best,options=advisor.options||[],strategy=advisor.settings?.strategy||'EXP';
    const heroism=Number(rt.heroism||0),pendingBonus=Number(rt.pendingMissionBonus||0),pendingPenalty=Number(rt.pendingMissionPenalty||0),effective=Number.isFinite(Number(rt.effectiveHeroism))?Number(rt.effectiveHeroism):heroism+pendingBonus+pendingPenalty;
    const starLabel=heroism>=40?'★★★':heroism>=30?'★★':heroism>=20?'★':'–';const reasons=Array.isArray(recommend?.reasons)?recommend.reasons.slice(0,4):[];
    const settlementLabel=pendingBonus||pendingPenalty?`${pendingBonus?`+${number(pendingBonus)} Bonus`:''}${pendingBonus&&pendingPenalty?' · ':''}${pendingPenalty?`${number(pendingPenalty)} Strafe`:''} am Ende`:'–';
    host.innerHTML=`
      <div class="sf-exp-hero"><img src="${chrome.runtime.getURL('assets/icons/expedition.png')}" alt=""><div><div class="sf-exp-hero-title">Expedition Advisor · Beta 0.3.2</div><div class="sf-support-muted">Passive Empfehlung auf Basis der bereits vom Spiel gelieferten Expeditionsdaten.</div></div></div>
      <div class="sf-exp-strategy" role="group" aria-label="Expeditionsstrategie"><button type="button" data-exp-strategy="EXP" class="${strategy==='EXP'?'active':''}">EXP</button><button type="button" data-exp-strategy="GOLD" class="${strategy==='GOLD'?'active':''}">GOLD</button></div>
      <div class="sf-exp-summary"><div><span>Mission</span><b>${esc(rt.missionName||'Noch keine')}</b></div><div><span>Raum</span><b>${rt.round!=null?`${number(rt.round)}/10`:'–'}</b></div><div><span>Heldentum</span><b>${number(heroism)}</b></div><div><span>Sterne aktuell</span><b>${starLabel}</b></div><div><span>Schatztruhen</span><b>${number(rt.chestCount||0)}/2</b></div><div><span>Schlüssel</span><b>${rt.keyHeld?'vorhanden':'–'}</b></div>${pendingBonus||pendingPenalty?`<div><span>Missionsabrechnung</span><b>${esc(settlementLabel)}</b></div><div><span>inkl. sicherer Abrechnung</span><b>${number(effective)}</b></div>`:''}</div>
      ${recommend?`<article class="sf-support-card sf-exp-recommend"><div class="sf-support-card-head"><b>Empfehlung</b><span>${esc(strategy)}</span></div><div class="sf-exp-choice">${number(recommend.position)}. ${esc(recommend.name)}</div><div class="sf-exp-points">${recommend.serverPoints>=0?'+':''}${number(recommend.serverPoints)} Punkte${recommend.missionBonus?` · Mission sofort +${number(recommend.missionBonus)}`:''}${recommend.deferredMissionBonus?` · Mission am Ende +${number(recommend.deferredMissionBonus)}`:''}${recommend.bountyBonus?` · Kopfgeld +${number(recommend.bountyBonus)}`:''}</div><div class="sf-support-muted">${reasons.length?esc(reasons.join(' · ')):'Beste aktuelle Regelbewertung.'}</div></article>`:`<div class="sf-support-empty"><b>Warte auf eine Kreuzung …</b><br>${rt.missionName&&rt.missionName!=='–'?`Aktive Expedition: ${esc(rt.missionName)}.`:'Starte eine Expedition oder öffne die nächste Kreuzung.'}</div>`}
      ${options.length?`<div class="sf-support-section-title">Aktuelle Auswahl</div><div class="sf-exp-options">${options.map(o=>`<div class="sf-exp-option ${recommend?.position===o.position?'recommended':''}"><b>${number(o.position)}. ${esc(o.name)}</b><span>${Number(o.serverPoints)>=0?'+':''}${number(o.serverPoints)} P.</span></div>`).join('')}</div>`:''}
      <div class="sf-support-section-title">Recorder</div><article class="sf-support-card"><div class="sf-support-card-head"><b>Passiver Expedition-Recorder</b><span class="${recStatus.enabled?'state-on':'state-off'}">${recStatus.enabled?'EIN':'AUS'}</span></div><div class="sf-support-muted">${number(recStatus.runs||0)} Runs gespeichert${recStatus.activeRun?' · Expedition läuft':''}. Keine zusätzlichen S&F-Anfragen.</div></article>`;
    host.querySelectorAll('[data-exp-strategy]').forEach(b=>b.addEventListener('click',()=>advisorApi()?.setStrategy?.(b.dataset.expStrategy)));
  }

  function renderScrapbookHelp(host){
    const api=scrapbookApi(),status=api?.getStatus?.()||{},fight=scrapbookFightApi(),fightStatus=fight?.getStatus?.()||{};
    const top5=fight?.getEligibleTargets?.(5)||[];
    const rows=top5.length?top5.map((t,i)=>{
      const slots=(t.missingSlots||[]).join(', '),chance=Number(t.winChance||0);
      return `<article class="sf-support-card sf-hof-target"><div class="sf-hof-target-rank">${i+1}</div><div class="sf-hof-target-content"><div class="sf-support-card-head"><b>${esc(t.name)}</b><span class="sf-hof-missing-count">${number(t.missingCount)} fehlt</span></div><div class="sf-support-muted">Lv. ${number(t.level)}${t.rank?` · Rang ${number(t.rank)}`:''} · <span class="sf-hof-win-chance">${chance.toFixed(2)} % Siegchance</span></div>${slots?`<div class="sf-hof-slots">${esc(slots)}</div>`:''}</div><button class="sf-hof-copy" type="button" data-copy-name="${esc(t.name)}">Kopieren</button></article>`;
    }).join(''):`<div class="sf-support-empty">${fightStatus.simulationRunning?'Kampfchancen werden berechnet …':'Noch kein Ziel mit mindestens 5 % berechneter Siegchance. Gegner ohne vollständige lokale Kampfwerte werden nicht angezeigt.'}</div>`;

    host.innerHTML=`<div class="sf-scrapbook-hero"><img class="sf-scrapbook-hero-icon" src="${chrome.runtime.getURL('assets/icons/scrapbook.png')}" alt=""><div><div class="sf-scrapbook-hero-title">Sammelalbum Hilfe</div><div class="sf-support-muted">Top 5 nach fehlenden Items · nur Gegner mit mindestens 5 % Siegchance.</div></div></div><div class="sf-hof-summary"><div><span>Aktive Ziele</span><b>${number(status.activeTargets||0)}</b></div><div><span>≥ 5 % Siegchance</span><b>${number(fightStatus.eligibleTargets||0)}</b></div><div><span>Gescannt</span><b>${number(status.totalScanned||0)}</b></div></div>
    <div class="sf-support-section-title">Top 5</div>${rows}
    <article class="sf-support-card sf-shared-db-card"><div class="sf-support-card-head"><b>Gemeinsame Gegnerdatenbank</b><span class="${status.sharedEnabled?'sf-online-ok':'sf-online-off'}">${status.sharedEnabled?(!status.sharedServer?'Warte auf Server':status.sharedLastError?'Verbindungsfehler':status.sharedSyncRunning?'Synchronisiert…':'Aktiv'):'Aus'}</span></div><div class="sf-shared-db-stats"><div><span>Verbindung</span><b>${status.sharedConnectionOk===true?'Verbunden':status.sharedConnectionOk===false?'Nicht verbunden':'Nicht getestet'}</b></div><div><span>Spielserver</span><b>${esc(status.sharedServer||'–')}</b></div><div><span>Online bekannt</span><b>${number(status.sharedKnownPlayers||0)}</b></div><div><span>Mitwirkende</span><b>${number(status.sharedContributingInstallations||0)}</b></div><div><span>Lokal geladen</span><b>${number(status.sharedCached||0)}</b></div><div><span>Wartet auf Upload</span><b>${number(status.sharedPendingUploads||0)}</b></div></div>${status.sharedConnectionError?`<div class="sf-shared-error">Verbindung: ${esc(status.sharedConnectionError)}</div>`:''}${status.sharedLastError?`<div class="sf-shared-error">Sync: ${esc(status.sharedLastError)}</div>`:''}<div class="sf-shared-controls sf-shared-controls-three"><button type="button" id="sf-shared-toggle">${status.sharedEnabled?'DB deaktivieren':'DB aktivieren'}</button><button type="button" id="sf-shared-test">Verbindung testen</button><button type="button" id="sf-shared-sync-now" ${!status.sharedEnabled||!status.sharedServer||status.sharedSyncRunning?'disabled':''}>Jetzt synchronisieren</button></div></article>
    <div class="sf-hof-actions sf-hof-actions-single"><button type="button" id="sf-hof-clear" class="danger">Lokale Daten löschen</button></div><div id="sf-hof-feedback" class="sf-hof-feedback"></div>`;

    host.querySelectorAll('[data-copy-name]').forEach(b=>b.addEventListener('click',async()=>{const ok=await copyText(b.dataset.copyName);const f=host.querySelector('#sf-hof-feedback');if(f)f.textContent=ok?`Name kopiert: ${b.dataset.copyName}`:'Name konnte nicht kopiert werden.';}));
    host.querySelector('#sf-shared-test')?.addEventListener('click',async()=>{const f=host.querySelector('#sf-hof-feedback');if(f)f.textContent='Teste Verbindung…';const r=await api?.testSharedConnection?.();renderScrapbookHelp(host);const nf=host.querySelector('#sf-hof-feedback');if(nf)nf.textContent=r?.ok?'Verbindung erfolgreich.':`Verbindung fehlgeschlagen: ${r?.error||'Unbekannter Fehler'}`;});
    host.querySelector('#sf-shared-toggle')?.addEventListener('click',async()=>{await api?.setSharedEnabled?.(!status.sharedEnabled);renderScrapbookHelp(host);});
    host.querySelector('#sf-shared-sync-now')?.addEventListener('click',async()=>{const f=host.querySelector('#sf-hof-feedback');if(f)f.textContent='Synchronisiere…';const r=await api?.manualSyncNow?.();renderScrapbookHelp(host);const nf=host.querySelector('#sf-hof-feedback');if(nf)nf.textContent=r?.reason==='server-not-detected'?'Spielserver noch nicht erkannt.':r?.reason==='already-running'?'Synchronisierung läuft bereits.':`Fertig · ${number(r?.uploaded||0)} hochgeladen · ${number(r?.received||0)} geladen.`;});
    host.querySelector('#sf-hof-clear')?.addEventListener('click',async()=>{if(!confirm('Lokale Sammelalbum-Zielliste wirklich löschen? Online-Daten bleiben bestehen.'))return;await api?.clearTargets?.();renderScrapbookHelp(host);});
  }

  function renderSettings(host){
    const rec=recorderApi(),status=rec?.getStatus?.()||{enabled:false,runs:0};
    const readyRuns=Number(status.researchReadyRuns||0),batch=20;
    const lastUpload=status.researchLastUploadAt?new Date(status.researchLastUploadAt).toLocaleString('de-DE'):'Noch keiner';
    const researchState=status.researchUploading?'UPLOAD…':status.researchEnabled?(status.researchLastError?'FEHLER':'AKTIV'):'AUS';
    const researchClass=status.researchEnabled&&!status.researchLastError?'state-on':'state-off';
    host.innerHTML=`
      <div class="sf-support-section-title">Expedition</div>
      <article class="sf-support-card settings-card sf-compact-setting"><div class="sf-support-setting-row"><div><b>Expedition-Recorder</b><div class="sf-setting-state ${status.enabled?'state-on':'state-off'}">${status.enabled?'EIN':'AUS'}</div></div><button id="sf-rec-switch" class="sf-support-switch ${status.enabled?'on':''}" type="button" aria-pressed="${status.enabled}"><span></span></button></div></article>
      <article class="sf-support-card settings-card sf-research-card"><div class="sf-support-card-head"><b>Expeditions-Forschungsdaten</b><span class="${researchClass}">${researchState}</span></div><div class="sf-support-setting-row sf-research-toggle-row"><div><b>Automatisch teilen</b><div class="sf-support-muted">Vollständige 10/10-Runs werden automatisch nach 20 Runs übertragen.</div></div><button id="sf-research-switch" class="sf-support-switch ${status.researchEnabled?'on':''}" type="button" aria-pressed="${status.researchEnabled}"><span></span></button></div><div class="sf-research-stats"><div><span>Bereit für Upload</span><b>${number(readyRuns)} / ${batch}</b></div><div><span>Bereits übertragen</span><b>${number(status.researchUploadedRuns||0)} Runs</b></div><div><span>Upload-Batches</span><b>${number(status.researchUploadedBatches||0)}</b></div><div><span>Letzter Upload</span><b>${esc(lastUpload)}</b></div></div>${status.researchLastError?`<div class="sf-shared-error">Upload: ${esc(status.researchLastError)}</div>`:''}<div class="sf-support-actions"><button id="sf-research-test" type="button" ${!status.researchEnabled||status.researchUploading?'disabled':''}>Verbindung testen</button><button id="sf-research-upload" type="button" ${!status.researchEnabled||status.researchUploading||Number(status.researchFinalizedRuns||0)<1?'disabled':''}>Jetzt hochladen</button></div><div id="sf-research-feedback" class="sf-hof-feedback"></div></article>
      <div class="sf-support-section-title">Advisor</div>
      <article class="sf-support-card"><div class="sf-support-card-head"><b>Expedition Advisor · Beta 0.3.2</b><span class="state-on">AKTIV</span></div><div class="sf-support-muted">Bewertet Punkte, Missionsketten, sofortige und erst am 10/10-Ende ausgezahlte Missionsboni, Kopfgeld-Reichweite, 1/2/3-Auswahl-Folgeräume sowie Schlüssel und Schatztruhen. Forschungsbasis: ${number(globalThis.SFExpeditionAdvisorData?.research?.cleanRuns||0)} saubere 10/10-Runs · 65 Ereignisse · 16 Missionen.</div></article>`;
    host.querySelector('#sf-rec-switch')?.addEventListener('click',async()=>{await rec?.setEnabled?.(!status.enabled);globalThis.SFSupportMainPanel.render();});
    host.querySelector('#sf-research-switch')?.addEventListener('click',async()=>{await rec?.setResearchEnabled?.(!status.researchEnabled);globalThis.SFSupportMainPanel.render();});
    host.querySelector('#sf-research-test')?.addEventListener('click',async()=>{const f=host.querySelector('#sf-research-feedback');if(f)f.textContent='Teste Verbindung…';const result=await rec?.testResearchConnection?.();globalThis.SFSupportMainPanel.render();const nf=document.querySelector('#sf-support-panel-body #sf-research-feedback');if(nf)nf.textContent=result?.ok?'Verbindung erfolgreich.':`Verbindung fehlgeschlagen: ${result?.error||'Unbekannter Fehler'}`;});
    host.querySelector('#sf-research-upload')?.addEventListener('click',async()=>{const f=host.querySelector('#sf-research-feedback');if(f)f.textContent='Lade vollständige Runs hoch…';const result=await rec?.uploadResearchNow?.({force:true});globalThis.SFSupportMainPanel.render();const nf=document.querySelector('#sf-support-panel-body #sf-research-feedback');if(nf)nf.textContent=result?.ok&&!result?.skipped?`${number(result.uploadedRuns||0)} Run(s) übertragen.`:result?.skipped?'Keine vollständigen 10/10-Runs zum Hochladen.':`Upload fehlgeschlagen: ${result?.error||'Unbekannter Fehler'}`;});
  }

  function boot(){if(!document.body)return false;globalThis.SFSupportLayout?.update?.();globalThis.SFSupportSidebar?.ensure?.();globalThis.SFSupportMainPanel?.ensure?.();globalThis.SFSupportMainPanel.registerRenderer('arena',renderArena);globalThis.SFSupportMainPanel.registerRenderer('expedition',renderExpedition);globalThis.SFSupportMainPanel.registerRenderer('character',renderCharacter);globalThis.SFSupportMainPanel.registerRenderer('scrapbook',renderScrapbookHelp);globalThis.SFSupportMainPanel.registerRenderer('settings',renderSettings);globalThis.SFSupportSidebar.onSelect(view=>{if(view)globalThis.SFSupportMainPanel.show(view);else globalThis.SFSupportMainPanel.hide();});globalThis.SFSupportArena?.subscribe?.(()=>{if(globalThis.SFSupportSidebar?.getActive?.()==='arena')globalThis.SFSupportMainPanel.render();});globalThis.SFSupportCharacter?.subscribe?.(()=>{const a=globalThis.SFSupportSidebar?.getActive?.();if(['character','arena','scrapbook'].includes(a))globalThis.SFSupportMainPanel.render();});recorderApi()?.subscribe?.(()=>{const a=globalThis.SFSupportSidebar?.getActive?.();if(a==='expedition'||a==='settings')globalThis.SFSupportMainPanel.render();});advisorApi()?.subscribe?.(()=>{if(globalThis.SFSupportSidebar?.getActive?.()==='expedition'&&globalThis.SFSupportMainPanel?.isVisible?.())globalThis.SFSupportMainPanel.render();});scrapbookApi()?.subscribe?.(status=>{const a=globalThis.SFSupportSidebar?.getActive?.();if(a==='scrapbook'&&globalThis.SFSupportMainPanel?.isVisible?.())globalThis.SFSupportMainPanel.render();globalThis.SFSupportSidebar?.setBadge?.('scrapbook',status?.activeTargets?String(status.activeTargets):'',status?.activeTargets?'album':'');});scrapbookFightApi()?.subscribe?.(()=>{if(globalThis.SFSupportSidebar?.getActive?.()==='scrapbook'&&globalThis.SFSupportMainPanel?.isVisible?.())globalThis.SFSupportMainPanel.render();});return true;}
  if(!boot()){const timer=setInterval(()=>{if(boot())clearInterval(timer);},50);}
})();
