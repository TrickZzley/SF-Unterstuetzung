(function () {
  'use strict';
  if (window.__SF_SUPPORT_PAGE_HOOK__) return;
  window.__SF_SUPPORT_PAGE_HOOK__ = true;

  function parseFields(text) {
    const fields = {};
    if (!text || typeof text !== 'string') return fields;
    for (const part of text.split('&')) {
      if (!part) continue;
      const i = part.indexOf(':');
      if (i < 0) continue;
      fields[part.slice(0, i)] = part.slice(i + 1);
    }
    return fields;
  }

  function getPotionType(type) { if (type === 16) return 6; if (type === 0) return 0; return 1 + ((type - 1) % 5); }
  function parsePotions(text) {
    const result = { life: 0, slots: [] };
    if (!text) return result;
    const data = text.split('/').map(Number);
    if (data.length < 10) return result;
    for (let i=0;i<3;i++) {
      const rawType=data[1+i]||0,type=getPotionType(rawType),expires=data[4+i]||0,size=data[7+i]||0;
      const active=type!==0&&(expires===0||expires*1000>Date.now());
      result.slots.push({rawType,type,expires,size,active});
      if(type===6&&active) result.life=25;
    }
    return result;
  }

  function parseItem(block) {
    if (!block || block.length < 19) return {type:0,socket:0,enchantment:0,damageMin:0,damageMax:0,attributeTypes:[0,0,0],attributes:[0,0,0],upgrades:0,gemValue:0,itemLevel:0,hasEnchantment:false,runeType:0,runeValue:0};
    const attributeTypes=[block[7]||0,block[8]||0,block[9]||0],attributes=[block[10]||0,block[11]||0,block[12]||0];
    const runeType=attributeTypes[2]>30?attributeTypes[2]:0,runeValue=runeType?attributes[2]:0;
    return {type:block[0]||0,socket:block[1]||0,enchantment:block[2]||0,picture:block[3]||0,damageMin:block[5]||0,damageMax:block[6]||0,attributeTypes,attributes,upgrades:block[15]||0,gemValue:block[16]||0,itemLevel:block[17]||0,hasEnchantment:(block[2]||0)>0,runeType,runeValue};
  }

  function parseEquipment(text) {
    if (!text) return null;
    const data=text.split('/').map(Number), names=['head','body','hand','feet','neck','belt','ring','misc','wpn1','wpn2'], items={};
    for(let i=0;i<names.length;i++) items[names[i]]=parseItem(data.slice(i*19,i*19+19));
    return items;
  }

  function calculateRunes(items) {
    const r={gold:0,epicChance:0,itemQuality:0,experience:0,health:0,resistanceAll:0,resistanceFire:0,resistanceCold:0,resistanceLightning:0,damage:0,damageFire:0,damageCold:0,damageLightning:0,damage2:0,damage2Fire:0,damage2Cold:0,damage2Lightning:0};
    if(!items)return r;
    for(const slot of ['head','body','hand','feet','neck','belt','ring','misc']){
      const it=items[slot];if(!it)continue;const t=it.runeType,v=it.runeValue;
      if(t===31)r.gold+=v;else if(t===32)r.epicChance+=v;else if(t===33)r.itemQuality+=v;else if(t===34)r.experience+=v;else if(t===35)r.health+=v;
      else if(t===36)r.resistanceFire+=v;else if(t===37)r.resistanceCold+=v;else if(t===38)r.resistanceLightning+=v;else if(t===39){r.resistanceAll+=v;r.resistanceFire+=v;r.resistanceCold+=v;r.resistanceLightning+=v;}
    }
    for(const [it,suffix] of [[items.wpn1,''],[items.wpn2,'2']]){if(!it)continue;const t=it.runeType,v=it.runeValue;if([40,41,42].includes(t))r[`damage${suffix}`]+=v;if(t===40)r[`damage${suffix}Fire`]=v;else if(t===41)r[`damage${suffix}Cold`]=v;else if(t===42)r[`damage${suffix}Lightning`]=v;}
    r.gold=Math.min(50,r.gold);r.epicChance=Math.min(50,r.epicChance);r.itemQuality=Math.min(5,r.itemQuality);r.experience=Math.min(10,r.experience);r.health=Math.min(15,r.health);r.resistanceAll=Math.min(75,r.resistanceAll);
    for(const k of ['resistanceFire','resistanceCold','resistanceLightning'])r[k]=Math.min(75,r[k]);for(const k of ['damage','damage2','damageFire','damageCold','damageLightning','damage2Fire','damage2Cold','damage2Lightning'])r[k]=Math.min(60,r[k]);
    return r;
  }

  function parseNumberList(text){if(!text)return[];return String(text).split(/[\/,;|]/).map(Number).filter(Number.isFinite);}
  function firstMatchingField(fields,exactNames,heuristic){for(const n of exactNames){if(fields[n]!=null&&fields[n]!=='')return fields[n];}for(const [k,v] of Object.entries(fields)){if(v&&heuristic(k,v))return v;}return '';}
  function readGuildPayload(fields){
    const saveText=firstMatchingField(fields,['groupsave','groupsave.r','guildsave','guildsave.r','group_save','guild_save'],(k,v)=>/(group|guild)/i.test(k)&&/save/i.test(k)&&String(v).split('/').length>=372);
    const knightsText=firstMatchingField(fields,['groupknights','groupknights.r','guildknights','guildknights.r','knights','knights.r'],(k,v)=>/knight/i.test(k)&&parseNumberList(v).length>=10&&parseNumberList(v).length<=60);
    return {saveText,knightsText};
  }
  function calculateKnightHall(groupSaveText,knightsText,playerId){const groupSave=parseNumberList(groupSaveText),knights=parseNumberList(knightsText).filter(v=>Number.isFinite(v)&&v>=0);const result={own:null,guildTotal:null,guildTotal15:null,sourceSeen:false};if(knights.length){result.sourceSeen=true;result.guildTotal=knights.reduce((s,v)=>s+v,0);result.guildTotal15=knights.filter(v=>v>=15).length;}if(groupSave.length>=64&&playerId&&knights.length){const ids=groupSave.slice(14,64),idx=ids.findIndex(id=>Number(id)===Number(playerId));if(idx>=0&&idx<knights.length)result.own=knights[idx];}return result;}

  function buildPlayer(saveText,name,potionText,equipmentText,groupSaveText='',groupKnightsText='') {
    if(!saveText)return null;const save=saveText.split('/').map(Number),items=parseEquipment(equipmentText),potions=parsePotions(potionText),runes=calculateRunes(items),knightHall=calculateKnightHall(groupSaveText,groupKnightsText,save[1]||0);
    const player={name:name||'Unbekannt',id:save[1]||0,level:save[3]||0,xp:save[4]||0,xpNext:save[5]||0,honor:save[6]||0,rank:save[7]||0,raceId:save[18]||0,gender:(save[19]||0)&0xFF,classId:(save[20]||0)&0xFFFF,mountId:(save[21]||0)&0xFFFF,armor:save[23]||0,damage:{min:save[24]||0,max:save[25]||0,average:((save[24]||0)+(save[25]||0))/2},dungeons:{group:save[26]||0,player:save[28]||0},attributes:{strength:{base:save[30]||0,bonus:save[35]||0,total:(save[30]||0)+(save[35]||0)},dexterity:{base:save[31]||0,bonus:save[36]||0,total:(save[31]||0)+(save[36]||0)},intelligence:{base:save[32]||0,bonus:save[37]||0,total:(save[32]||0)+(save[37]||0)},constitution:{base:save[33]||0,bonus:save[38]||0,total:(save[33]||0)+(save[38]||0)},luck:{base:save[34]||0,bonus:save[39]||0,total:(save[34]||0)+(save[39]||0)}},fortress:{gladiator:save[69]||0},potions,items,runes,knightHall,rawEquipment:equipmentText||'',snapshotComplete:Boolean(saveText&&equipmentText)};
    if(player.classId===4&&items?.wpn2)player.damage2={min:items.wpn2.damageMin,max:items.wpn2.damageMax,average:(items.wpn2.damageMin+items.wpn2.damageMax)/2};if(player.classId===1&&items?.wpn2)player.blockChance=items.wpn2.damageMin||0;player.attackFirst=!!items?.hand?.hasEnchantment;player.weaponEnchantment=!!items?.wpn1?.hasEnchantment;player.weapon2Enchantment=!!items?.wpn2?.hasEnchantment;return player;
  }

  const ownCache={save:'',name:'Du',potions:'',equipment:'',groupSave:'',groupKnights:''};
  const opponentCache={save:'',name:'',potions:'',equipment:''};
  function analyseResponse(text){if(!text)return;const fields=parseFields(text);
    if(fields['scrapbook.r']!=null)window.postMessage({source:'SF_COMBAT_ADVISOR',type:'SCRAPBOOK_SNAPSHOT',scrapbook:fields['scrapbook.r'],legendaries:fields['legendaries.r']||''},'*');
    const incomingOwnName=fields['playername.r']||fields['ownplayername.r']||fields.playername||'';if(incomingOwnName)ownCache.name=incomingOwnName;if(fields.ownplayersavecharacter)ownCache.save=fields.ownplayersavecharacter;if(fields.ownplayersavepotions)ownCache.potions=fields.ownplayersavepotions;if(fields.ownplayersaveequipment)ownCache.equipment=fields.ownplayersaveequipment;const guild=readGuildPayload(fields);if(guild.saveText)ownCache.groupSave=guild.saveText;if(guild.knightsText)ownCache.groupKnights=guild.knightsText;
    if((incomingOwnName||fields.ownplayersavecharacter||fields.ownplayersavepotions||fields.ownplayersaveequipment||guild.saveText||guild.knightsText)&&ownCache.save){const player=buildPlayer(ownCache.save,ownCache.name||'Du',ownCache.potions,ownCache.equipment,ownCache.groupSave,ownCache.groupKnights);if(player){if(lastServerContext)player.server=lastServerContext;window.postMessage({source:'SF_COMBAT_ADVISOR',type:'MY_PLAYER',player},'*');}}
    const incomingOpponentName=fields['otherplayername.r']||fields.otherplayername||'';if(incomingOpponentName&&opponentCache.name&&incomingOpponentName!==opponentCache.name){opponentCache.save='';opponentCache.potions='';opponentCache.equipment='';}if(incomingOpponentName)opponentCache.name=incomingOpponentName;if(fields.otherplayersavecharacter)opponentCache.save=fields.otherplayersavecharacter;if(fields.otherplayersavepotions)opponentCache.potions=fields.otherplayersavepotions;if(fields.otherplayersaveequipment)opponentCache.equipment=fields.otherplayersaveequipment;
    if((incomingOpponentName||fields.otherplayersavecharacter||fields.otherplayersavepotions||fields.otherplayersaveequipment)&&opponentCache.save){const player=buildPlayer(opponentCache.save,opponentCache.name||'Unbekannt',opponentCache.potions,opponentCache.equipment);if(player){if(lastServerContext)player.server=lastServerContext;window.postMessage({source:'SF_COMBAT_ADVISOR',type:'PLAYER_LOOK_AT',player},'*');}}
    if(Object.prototype.hasOwnProperty.call(fields,'winnerid'))window.postMessage({source:'SF_COMBAT_ADVISOR',type:'FIGHT_RESULT',at:Date.now(),winnerId:Number(fields.winnerid||0),opponent:{id:0,name:opponentCache.name||''}},'*');
  }

  let lastServerContext='';
  function extractConcreteSfServer(rawUrl){if(!rawUrl)return'';try{const u=new URL(String(rawUrl),location.href),host=String(u.hostname||'').trim().toLowerCase(),path=String(u.pathname||'').toLowerCase();if(!path.includes('/cmd.php')&&!path.endsWith('cmd.php'))return'';if(!(host.endsWith('.sfgame.eu')||host.endsWith('.sfgame.net')))return'';if(new Set(['sfgame.eu','www.sfgame.eu','sfgame.net','www.sfgame.net','cdn.sfgame.net','cdn.sfgame.eu']).has(host))return'';return host;}catch{return'';}}
  function emitServerContext(rawUrl){const s=extractConcreteSfServer(rawUrl);if(!s||s===lastServerContext)return;lastServerContext=s;window.postMessage({source:'SF_COMBAT_ADVISOR',type:'SERVER_CONTEXT',server:s},'*');}

  const originalFetch=window.fetch;
  if(typeof originalFetch==='function')window.fetch=async function(...args){
    const response=await originalFetch.apply(this,args);
    try{
      const url=typeof args[0]==='string'?args[0]:args[0]?.url||'';
      const responseUrl=String(response?.url||'');
      emitServerContext(responseUrl||url);
      emitServerContext(url);
      if(url.includes('PlayerGetHallOfFame')||responseUrl.includes('PlayerGetHallOfFame'))window.postMessage({source:'SF_COMBAT_ADVISOR',type:'HALL_OF_FAME_SEEN'},'*');
      if(url.includes('cmd.php')||responseUrl.includes('cmd.php')){
        // Wichtig: Die Antwort des Spiels niemals auf unsere Analyse warten lassen.
        // Wir lesen nur eine Kopie und verschieben die eigentliche Auswertung in einen
        // späteren Task, nachdem S&F die originale Response bereits erhalten hat.
        const clone=response.clone();
        void clone.text().then((text)=>{
          setTimeout(()=>{
            try{analyseResponse(text);}catch(e){console.error('[S&F Unterstützung] Fetch-Auswertung:',e);}
          },0);
        }).catch((e)=>console.error('[S&F Unterstützung] Fetch-Kopie:',e));
      }
    }catch(e){console.error('[S&F Unterstützung] Fetch-Hook:',e);}
    return response;
  };

  const originalXhrOpen=XMLHttpRequest.prototype.open,originalXhrSend=XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open=function(method,url,...rest){try{this.__sfSupportRequestUrl=String(url||'');emitServerContext(this.__sfSupportRequestUrl);}catch{}return originalXhrOpen.call(this,method,url,...rest);};
  XMLHttpRequest.prototype.send=function(...args){
    try{
      this.addEventListener('load',function(){
        try{
          const req=this.__sfSupportRequestUrl||'',res=this.responseURL||'';
          emitServerContext(res);
          emitServerContext(req);
          if(req.includes('PlayerGetHallOfFame')||res.includes('PlayerGetHallOfFame'))window.postMessage({source:'SF_COMBAT_ADVISOR',type:'HALL_OF_FAME_SEEN'},'*');
          if((req.includes('cmd.php')||res.includes('cmd.php'))&&(!this.responseType||this.responseType==='text')){
            const text=this.responseText||'';
            // Auch beim XHR nicht innerhalb des load-Events analysieren. So können die
            // Listener des Spiels zuerst fertiglaufen; unsere Analyse folgt danach.
            setTimeout(()=>{
              try{analyseResponse(text);}catch(e){console.error('[S&F Unterstützung] XHR-Auswertung:',e);}
            },0);
          }
        }catch(e){console.error('[S&F Unterstützung] XHR-Hook:',e);}
      },{once:true});
    }catch{}
    return originalXhrSend.apply(this,args);
  };
})();
