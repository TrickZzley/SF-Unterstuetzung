(() => {
  'use strict';
  if (globalThis.__SF_SUPPORT_ARENA__) return;
  globalThis.__SF_SUPPORT_ARENA__ = true;

  let myPlayer = null;
  let opponents = [];
  let simulationRunning = false;
  let simulationGeneration = 0;
  const listeners = new Set();

  const key = player => Number(player?.id || 0)
    ? `id:${Number(player.id)}`
    : `name:${String(player?.name || '').toLowerCase()}`;

  function playerFingerprint(player) {
    if (!player) return '';
    return JSON.stringify({
      id: player.id,
      name: player.name,
      level: player.level,
      classId: player.classId,
      armor: player.armor,
      damage: player.damage,
      damage2: player.damage2,
      attributes: player.attributes,
      dungeons: player.dungeons,
      fortress: player.fortress,
      potions: player.potions,
      runes: player.runes,
      items: player.items
    });
  }

  function getState() {
    return {
      myPlayer,
      opponents: opponents.map(entry => ({ ...entry })),
      simulationRunning
    };
  }

  function notify() {
    const snapshot = getState();
    for (const listener of listeners) {
      try { listener(snapshot); }
      catch (error) { console.error(error); }
    }
  }

  function simulateOpponent(player) {
    if (!myPlayer || !player || !globalThis.SFSimulator?.simulate) return null;
    try {
      return globalThis.SFSimulator.simulate(myPlayer, player, 5000);
    } catch (error) {
      console.error('[S&F Arena] Simulation:', error);
      return null;
    }
  }

  function invalidateResults() {
    simulationGeneration += 1;
    simulationRunning = false;
    const ownFingerprint = playerFingerprint(myPlayer);
    opponents = opponents.map(entry => ({
      ...entry,
      result: null,
      simulatedOwnFingerprint: '',
      simulatedOpponentFingerprint: '',
      ownFingerprint
    }));
  }

  function upsertOpponent(player) {
    const opponentKey = key(player);
    const fingerprint = playerFingerprint(player);
    const existing = opponents.find(entry => entry.key === opponentKey);

    const canReuse = Boolean(
      existing?.result &&
      existing.simulatedOpponentFingerprint === fingerprint &&
      existing.simulatedOwnFingerprint === playerFingerprint(myPlayer)
    );

    opponents = opponents.filter(entry => entry.key !== opponentKey);
    opponents.unshift({
      key: opponentKey,
      player,
      result: canReuse ? existing.result : null,
      seenAt: Date.now(),
      simulatedOwnFingerprint: canReuse ? existing.simulatedOwnFingerprint : '',
      simulatedOpponentFingerprint: canReuse ? existing.simulatedOpponentFingerprint : ''
    });
    opponents = opponents.slice(0, 3);

    // Beim reinen Durchblättern nicht sofort simulieren.
    notify();
  }

  async function ensureSimulated() {
    if (simulationRunning || !myPlayer || !globalThis.SFSimulator?.simulate) return false;

    simulationRunning = true;
    simulationGeneration += 1;
    const generation = simulationGeneration;
    const ownFingerprint = playerFingerprint(myPlayer);
    notify();

    try {
      for (let index = 0; index < opponents.length; index += 1) {
        if (generation !== simulationGeneration) return false;

        const entry = opponents[index];
        const opponentFingerprint = playerFingerprint(entry.player);
        const reusable = Boolean(
          entry.result &&
          entry.simulatedOwnFingerprint === ownFingerprint &&
          entry.simulatedOpponentFingerprint === opponentFingerprint
        );

        if (reusable) continue;

        const result = simulateOpponent(entry.player);
        if (generation !== simulationGeneration) return false;

        const current = opponents.find(item => item.key === entry.key);
        if (!current) continue;

        current.result = result;
        current.simulatedOwnFingerprint = ownFingerprint;
        current.simulatedOpponentFingerprint = opponentFingerprint;
        notify();

        await new Promise(resolve => setTimeout(resolve, 0));
      }
      return true;
    } finally {
      if (generation === simulationGeneration) {
        simulationRunning = false;
        notify();
      }
    }
  }

  async function rerunSimulations() {
    if (!opponents.length || !myPlayer) return false;
    invalidateResults();
    notify();
    return ensureSimulated();
  }

  window.addEventListener('message', event => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== 'SF_COMBAT_ADVISOR') return;

    if (data.type === 'MY_PLAYER' && data.player) {
      const oldFingerprint = playerFingerprint(myPlayer);
      myPlayer = data.player;
      if (playerFingerprint(myPlayer) !== oldFingerprint) invalidateResults();
      notify();
      return;
    }

    if (data.type === 'PLAYER_LOOK_AT' && data.player) {
      upsertOpponent(data.player);
    }
  });

  globalThis.SFSupportArena = {
    getState,
    ensureSimulated,
    rerunSimulations,
    clearOpponents() {
      simulationGeneration += 1;
      simulationRunning = false;
      opponents = [];
      notify();
    },
    subscribe(fn) {
      listeners.add(fn);
      fn(getState());
      return () => listeners.delete(fn);
    }
  };
})();
