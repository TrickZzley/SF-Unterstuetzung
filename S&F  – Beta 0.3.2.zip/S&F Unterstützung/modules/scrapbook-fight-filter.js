(() => {
  'use strict';
  if (globalThis.__SF_SUPPORT_SCRAPBOOK_FIGHT_FILTER__) return;
  globalThis.__SF_SUPPORT_SCRAPBOOK_FIGHT_FILTER__ = true;

  const STORAGE_KEY = 'sfSupportScrapbookFightFilterV1';
  const THRESHOLD = 5;
  const MAX_OPPONENTS = 350;
  const listeners = new Set();

  let state = {
    version: 1,
    activeOwnKey: '',
    own: {},
    opponents: {}
  };
  let loaded = false;
  let queueTimer = null;
  let simulationRunning = false;
  let generation = 0;

  const currentServer = () => String(
    globalThis.SFSupportCharacter?.getPlayer?.()?.server || location.hostname || ''
  ).trim().toLowerCase();

  function playerKey(player) {
    const server = String(player?.server || currentServer() || '').trim().toLowerCase();
    const id = Number(player?.id || player?.playerId || 0);
    if (id > 0) return `${server}::id:${id}`;
    const name = String(player?.name || '').trim().toLowerCase();
    return name ? `${server}::name:${name}` : '';
  }

  function compactPlayer(player) {
    if (!player || typeof player !== 'object') return null;
    return {
      id: Number(player.id || 0),
      name: String(player.name || ''),
      server: String(player.server || currentServer() || '').toLowerCase(),
      level: Number(player.level || 0),
      classId: Number(player.classId || 0),
      armor: Number(player.armor || 0),
      damage: player.damage || null,
      damage2: player.damage2 || null,
      attributes: player.attributes || null,
      dungeons: player.dungeons || null,
      fortress: player.fortress || null,
      potions: player.potions || null,
      runes: player.runes || null,
      items: player.items || null,
      blockChance: player.blockChance,
      attackFirst: player.attackFirst,
      weaponEnchantment: player.weaponEnchantment,
      weapon2Enchantment: player.weapon2Enchantment,
      snapshotComplete: player.snapshotComplete !== false
    };
  }

  function fingerprint(player) {
    if (!player) return '';
    return JSON.stringify({
      id: player.id,
      level: player.level,
      classId: player.classId,
      armor: player.armor,
      damage: player.damage,
      damage2: player.damage2,
      attributes: player.attributes,
      dungeons: player.dungeons,
      fortress: player.fortress,
      potions: player.potions,
      runes: player.runes,
      items: player.items,
      blockChance: player.blockChance,
      attackFirst: player.attackFirst,
      weaponEnchantment: player.weaponEnchantment,
      weapon2Enchantment: player.weapon2Enchantment
    });
  }

  function normalizeState(raw) {
    const next = raw && typeof raw === 'object' ? raw : {};
    return {
      version: 1,
      activeOwnKey: String(next.activeOwnKey || ''),
      own: next.own && typeof next.own === 'object' ? next.own : {},
      opponents: next.opponents && typeof next.opponents === 'object' ? next.opponents : {}
    };
  }

  async function saveState() {
    try { await chrome.storage.local.set({ [STORAGE_KEY]: state }); } catch (error) {
      console.error('[S&F Unterstützung] Sammelalbum-Kampffilter speichern:', error);
    }
  }

  function notify() {
    const snapshot = getStatus();
    for (const listener of listeners) {
      try { listener(snapshot); } catch (error) { console.error(error); }
    }
  }

  function activeOwn() {
    return state.own[state.activeOwnKey] || null;
  }

  function targetKey(target) {
    if (target?.key) return String(target.key);
    return playerKey(target);
  }

  function getTargetChance(target) {
    const key = targetKey(target);
    const record = key ? state.opponents[key] : null;
    const chance = Number(record?.chance);
    return Number.isFinite(chance) ? chance : null;
  }

  function isEligible(target) {
    const chance = getTargetChance(target);
    return chance != null && chance >= THRESHOLD;
  }

  function getEligibleTargets(limit = 5) {
    const targets = globalThis.SFSupportScrapbook?.getTargets?.() || [];
    return targets
      .filter(target => Number(target?.missingCount || 0) > 0)
      .map(target => ({ ...target, winChance: getTargetChance(target) }))
      .filter(target => Number.isFinite(target.winChance) && target.winChance >= THRESHOLD)
      // Reihenfolge des Sammelalbum-Moduls beibehalten: fehlende Items bleiben Hauptpriorität.
      .slice(0, Math.max(0, Number(limit || 0)));
  }

  function relevantTargetsInPriorityOrder() {
    return (globalThis.SFSupportScrapbook?.getTargets?.() || [])
      .filter(target => Number(target?.missingCount || 0) > 0);
  }

  function scheduleRecalculate(delay = 80) {
    clearTimeout(queueTimer);
    queueTimer = setTimeout(() => {
      queueTimer = null;
      recalculate().catch(error => console.error('[S&F Unterstützung] Sammelalbum-Kampffilter:', error));
    }, delay);
  }

  async function recalculate() {
    if (!loaded || simulationRunning) return getEligibleTargets(5);
    const own = activeOwn();
    if (!own?.player || own.player.snapshotComplete === false || !globalThis.SFSimulator?.simulate) {
      notify();
      return [];
    }

    simulationRunning = true;
    generation += 1;
    const runGeneration = generation;
    const ownFingerprint = own.fingerprint;

    try {
      let eligibleFound = 0;
      for (const target of relevantTargetsInPriorityOrder()) {
        if (runGeneration !== generation || eligibleFound >= 5) break;
        const key = targetKey(target);
        const record = key ? state.opponents[key] : null;
        if (!record?.player || record.player.snapshotComplete === false) continue;

        const oppFingerprint = fingerprint(record.player);
        const reusable = Number.isFinite(Number(record.chance)) &&
          record.ownFingerprint === ownFingerprint &&
          record.opponentFingerprint === oppFingerprint;

        if (!reusable) {
          // Derselbe Simulator wie in der Arena, aber nur für Kandidaten, die für die Top 5 relevant sind.
          const result = globalThis.SFSimulator.simulate(own.player, record.player, 5000);
          record.chance = Number(result?.chance || 0);
          record.ownFingerprint = ownFingerprint;
          record.opponentFingerprint = oppFingerprint;
          record.simulatedAt = Date.now();
          notify();
          // Browser zwischen Kandidaten wieder Luft geben -> kein langer blockierender Simulations-Loop.
          await new Promise(resolve => setTimeout(resolve, 0));
        }

        if (Number(record.chance) >= THRESHOLD) eligibleFound += 1;
      }
      await saveState();
      notify();
      return getEligibleTargets(5);
    } finally {
      simulationRunning = false;
    }
  }

  async function updateOwnPlayer(player) {
    if (!player || player.snapshotComplete === false) return;
    const compact = compactPlayer(player);
    const key = playerKey(compact);
    if (!key) return;
    const fp = fingerprint(compact);
    const previous = state.own[key];
    state.own[key] = { key, player: compact, fingerprint: fp, updatedAt: Date.now() };
    state.activeOwnKey = key;
    if (!previous || previous.fingerprint !== fp) {
      generation += 1;
      scheduleRecalculate(40);
    } else {
      notify();
    }
    await saveState();
  }

  async function updateOpponent(player) {
    if (!player || player.snapshotComplete === false) return;
    const compact = compactPlayer(player);
    const key = playerKey(compact);
    if (!key) return;
    const old = state.opponents[key] || {};
    state.opponents[key] = {
      ...old,
      key,
      name: compact.name,
      server: compact.server,
      playerId: compact.id,
      player: compact,
      lastSeenAt: Date.now()
    };

    const entries = Object.values(state.opponents);
    if (entries.length > MAX_OPPONENTS) {
      entries.sort((a, b) => Number(b.lastSeenAt || 0) - Number(a.lastSeenAt || 0));
      const keep = new Set(entries.slice(0, MAX_OPPONENTS).map(entry => entry.key));
      for (const candidateKey of Object.keys(state.opponents)) {
        if (!keep.has(candidateKey)) delete state.opponents[candidateKey];
      }
    }

    await saveState();
    scheduleRecalculate(120);
  }

  function getStatus() {
    const allTargets = globalThis.SFSupportScrapbook?.getTargets?.() || [];
    const missingTargets = allTargets.filter(target => Number(target?.missingCount || 0) > 0);
    const knownChance = missingTargets.filter(target => getTargetChance(target) != null).length;
    const eligible = missingTargets.filter(isEligible).length;
    return {
      threshold: THRESHOLD,
      simulationRunning,
      missingTargets: missingTargets.length,
      knownChance,
      eligibleTargets: eligible,
      top5: getEligibleTargets(5)
    };
  }

  window.addEventListener('message', event => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== 'SF_COMBAT_ADVISOR') return;
    if (data.type === 'MY_PLAYER' && data.player) updateOwnPlayer(data.player).catch(console.error);
    if (data.type === 'PLAYER_LOOK_AT' && data.player) updateOpponent(data.player).catch(console.error);
  });

  globalThis.SFSupportScrapbookFightFilter = {
    version: '1.1.0-top5-lag-safe',
    threshold: THRESHOLD,
    getStatus,
    getEligibleTargets,
    getTargetChance,
    recalculate,
    subscribe(listener) {
      if (typeof listener !== 'function') return () => {};
      listeners.add(listener);
      listener(getStatus());
      return () => listeners.delete(listener);
    }
  };

  (async () => {
    try {
      const stored = await chrome.storage.local.get(STORAGE_KEY);
      state = normalizeState(stored?.[STORAGE_KEY]);
    } catch {
      state = normalizeState(null);
    }
    loaded = true;
    const own = globalThis.SFSupportCharacter?.getPlayer?.();
    if (own) await updateOwnPlayer(own);
    scheduleRecalculate(160);
    notify();
  })().catch(error => console.error('[S&F Unterstützung] Sammelalbum-Kampffilter Init:', error));
})();
