(function(root,factory){const api=factory();if(typeof module!=='undefined'&&module.exports)module.exports=api;root.SFExpeditionStrategyCore=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const num=(v,f=0)=>Number.isFinite(Number(v))?Number(v):f;
  const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
  const asIds=v=>Array.isArray(v)?v.map(Number).filter(Number.isFinite):[];
  const countOf=(h,id)=>(h||[]).reduce((n,x)=>n+(Number(x)===Number(id)?1:0),0);
  const limit=(obj,field,unlimitedField,fallback)=>obj?.[unlimitedField]===true?Infinity:Math.max(0,num(obj?.[field],fallback));

  function eventData(data,id,serverPoints){const known=data.events?.[Number(id)]||{};return{...known,id:Number(id),name:known.name||`Event ${id}`,points:Number.isFinite(Number(serverPoints))?Number(serverPoints):num(known.points,0)};}
  function buildTreasureState(history){let keyHeld=false,chestCount=0,keyCount=0;for(const raw of history||[]){const id=Number(raw);if(id===131){if(!keyHeld)keyCount++;keyHeld=true;}else if(id===132&&keyHeld){chestCount++;keyHeld=false;}}return{keyHeld,keyCount,chestCount};}
  function bountyProgress(data,history){let active=null,picked=0;const max=Math.max(0,num(data.bountyRules?.maxActivations,3));for(const raw of history||[]){const id=Number(raw),e=data.events?.[id];if(e?.bountyTargets?.length){picked++;active=e;continue;}if(active&&active.bountyTargets.some(t=>Number(t)===id))active=null;}return{active,picked,max,remaining:Math.max(0,max-picked)};}
  function bountyState(data,history){return bountyProgress(data,history).active;}
  function oneTimeProgress(chain,h){let p=0;for(const raw of h||[]){if(p<chain.length&&Number(raw)===Number(chain[p]))p++;}return Math.min(p,chain.length);}
  function repeatWholeProgress(m,h){const chain=asIds(m.chain);let progress=0,cycles=0;for(const raw of h||[]){if(chain.length&&Number(raw)===Number(chain[progress])){progress++;if(progress>=chain.length){cycles++;progress=0;}}}return{progress,cycles};}
  function unlockTailProgress(m,h){const chain=asIds(m.chain),prefix=chain.slice(0,-1),tail=Number(m.tailEventId||chain[chain.length-1]),prefixProgress=oneTimeProgress(prefix,h);return{prefixProgress,unlocked:prefix.length===0||prefixProgress>=prefix.length,tailCount:countOf(h,tail)};}

  function missionState(data,missionId,history){
    const m=data.missions?.[Number(missionId)];if(!m)return{completed:false,nextEventId:null};
    if(m.type==='once'){const chain=asIds(m.chain),progress=oneTimeProgress(chain,history);return{progress,completed:chain.length>0&&progress>=chain.length,nextEventId:progress<chain.length?Number(chain[progress]):null};}
    if(m.type==='repeatWhole'){const s=repeatWholeProgress(m,history),max=limit(m,'maxCycles','unlimitedCycles',1);return{...s,completed:Number.isFinite(max)&&s.cycles>=max,nextEventId:!Number.isFinite(max)||s.cycles<max?Number(asIds(m.chain)[s.progress]):null};}
    if(m.type==='unlockRepeatTail'){const s=unlockTailProgress(m,history),prefix=asIds(m.chain).slice(0,-1),max=limit(m,'tailMax','unlimitedTail',999);return{...s,completed:Number.isFinite(max)&&s.unlocked&&s.tailCount>=max,nextEventId:!s.unlocked?Number(prefix[s.prefixProgress]):Number(m.tailEventId||asIds(m.chain)[asIds(m.chain).length-1])};}
    if(m.type==='repeatedCount'){const count=countOf(history,m.eventId),required=Math.max(1,num(m.requiredCount,1));return{count,completed:count>=required,nextEventId:count<required?Number(m.eventId):null};}
    if(m.type==='singleRepeat'){const count=countOf(history,m.eventId),max=limit(m,'maxCompletions','unlimitedCompletions',10);return{count,completed:Number.isFinite(max)&&count>=max,nextEventId:!Number.isFinite(max)||count<max?Number(m.eventId):null};}
    return{completed:false,nextEventId:null};
  }

  function currentMissionBonus(m,s,eventId){
    if(!m)return 0;eventId=Number(eventId);
    // Forschungsdaten zeigen zwei verschiedene Auszahlungsarten:
    // - einmalige/repeatedCount-Missionen schreiben den Erfolgsbonus sofort gut.
    // - wiederholbare Missionsboni werden gesammelt und erst beim 10/10-Abschluss gutgeschrieben.
    if(m.type==='once'){const c=asIds(m.chain);if(eventId===Number(c[c.length-1])&&s.progress===c.length-1)return num(m.successBonus,0);}
    if(m.type==='repeatedCount'&&eventId===Number(m.eventId)&&s.count===Math.max(1,num(m.requiredCount,1))-1)return num(m.successBonus,0);
    return 0;
  }

  function deferredMissionBonus(m,s){
    if(!m||!s)return 0;const bonus=num(m.perCompletionBonus,0);if(!bonus)return 0;
    if(m.type==='repeatWhole'){
      const max=limit(m,'maxCycles','unlimitedCycles',1),cycles=Math.max(0,num(s.cycles,0));return Math.max(0,Math.min(Number.isFinite(max)?max:cycles,cycles))*bonus;
    }
    if(m.type==='unlockRepeatTail'){
      const max=limit(m,'tailMax','unlimitedTail',99),count=Math.max(0,num(s.tailCount,0));return Math.max(0,Math.min(Number.isFinite(max)?max:count,count))*bonus;
    }
    if(m.type==='singleRepeat'){
      const max=limit(m,'maxCompletions','unlimitedCompletions',10),count=Math.max(0,num(s.count,0));return Math.max(0,Math.min(Number.isFinite(max)?max:count,count))*bonus;
    }
    return 0;
  }

  function missionSettlement(data,missionId,history,roomsRemaining=0){
    const m=data.missions?.[Number(missionId)];if(!m)return{bonus:0,penalty:0,net:0,completed:false};
    const s=missionState(data,missionId,history),bonus=deferredMissionBonus(m,s);
    // Fehlschlagsabzüge werden laut vollständigen Runs erst am Expeditionsende verrechnet.
    // Solange noch Räume offen sind, ist der Abzug nicht garantiert, weil die Mission noch gelingen kann.
    const penalty=Math.max(0,Math.floor(num(roomsRemaining,0)))===0&&!s.completed&&['once','repeatedCount'].includes(m.type)?Math.min(0,num(m.failurePenalty,0)):0;
    return{bonus,penalty,net:bonus+penalty,completed:Boolean(s.completed),state:s};
  }

  function research(data){return data?.research||{};}
  function offerRate(data,eventId){return clamp(num(research(data).offerRate?.[Number(eventId)],0.035),0.002,0.85);}
  function chainPairStats(data,prev,next){return research(data).chainTransitions?.[`${Number(prev)}>${Number(next)}`]||null;}
  function nextStepHazard(data,prev,next){
    const s=chainPairStats(data,prev,next);if(s){const avg=Math.max(1,num(s.avgRounds,2.2)),seen=clamp(num(s.pSeen,0.75),0.05,1);return clamp((1/avg)*(0.72+0.28*seen),0.12,0.82);}
    return clamp(Math.max(offerRate(data,next),0.16),0.05,0.55);
  }
  function primaryMissionHazard(data,eventId){return clamp(Math.max(offerRate(data,eventId)*2.2,0.28),0.12,0.58);}

  function sequenceProbability(data,sequence,rooms,{primary=false,previous=null}={}){
    sequence=asIds(sequence);rooms=Math.max(0,Math.floor(num(rooms,0)));if(!sequence.length)return 1;if(!rooms)return 0;
    const memo=new Map();
    function rec(i,r,prev){if(i>=sequence.length)return 1;if(r<=0)return 0;const key=`${i}|${r}|${prev??'x'}`;if(memo.has(key))return memo.get(key);const id=sequence[i];let p;if(prev!=null)p=nextStepHazard(data,prev,id);else p=primary?primaryMissionHazard(data,id):offerRate(data,id);p=clamp(p,0.002,0.9);const hit=p*rec(i+1,r-1,id),miss=(1-p)*rec(i,r-1,prev);const out=clamp(hit+miss);memo.set(key,out);return out;}
    return rec(0,rooms,previous);
  }

  function choiceDistribution(data,count){const raw=research(data).choiceMaxDistribution?.[String(Number(count))]||research(data).choiceMaxDistribution?.['3']||[[0,1]];return raw.map(x=>Array.isArray(x)?[num(x[0],0),num(x[1],0)]:[num(x.points,0),num(x.p,0)]).filter(x=>x[1]>0);}
  function futureThresholdProbability(data,current,rooms,target,firstChoiceCount=3){
    rooms=Math.max(0,Math.floor(num(rooms,0)));if(current>=target)return 1;if(!rooms)return 0;
    let states=new Map([[0,1]]);
    for(let i=0;i<rooms;i++){
      const dist=choiceDistribution(data,i===0?firstChoiceCount:3),next=new Map();
      for(const [sum,p0] of states){for(const [pts,p1] of dist){const s=sum+pts;if(current+s>=target){next.set(target-current,(next.get(target-current)||0)+p0*p1);}else{next.set(s,(next.get(s)||0)+p0*p1);}}}
      states=next;
    }
    let success=0;for(const [sum,p] of states)if(current+sum>=target)success+=p;return clamp(success);
  }

  function eventChain(data,event){
    const chain=asIds(event?.chain);if(chain.length)return chain;
    for(const m of Object.values(data.missions||{})){const c=asIds(m?.chain);if(c.includes(Number(event?.id)))return c;}
    return [];
  }
  function chainProgressToTarget(data,targetId,history){
    const target=data.events?.[Number(targetId)]||{id:Number(targetId)},chain=eventChain(data,target);if(!chain.length)return{chain:[],targetIndex:-1,progress:0,sequence:[Number(targetId)],previous:null};
    const idx=chain.indexOf(Number(targetId));if(idx<0)return{chain,targetIndex:-1,progress:0,sequence:[Number(targetId)],previous:null};
    const prefix=chain.slice(0,idx+1);const progress=oneTimeProgress(prefix,history);const sequence=prefix.slice(progress);const previous=progress>0?prefix[progress-1]:null;return{chain,targetIndex:idx,progress,sequence,previous};
  }
  function targetReachProbability(data,targetId,history,rooms){
    if(rooms<=0)return 0;const e=data.events?.[Number(targetId)]||{};const max=e.unlimitedOccurrences===true?Infinity:(Number.isFinite(Number(e.maxOccurrences))?Number(e.maxOccurrences):Infinity);if(Number.isFinite(max)&&countOf(history,targetId)>=max)return 0;
    const s=chainProgressToTarget(data,targetId,history);if(!s.sequence.length){return clamp(1-Math.pow(1-offerRate(data,targetId),rooms));}
    if(s.chain.length<=1)return clamp(1-Math.pow(1-offerRate(data,targetId),rooms));
    return sequenceProbability(data,s.sequence,rooms,{primary:false,previous:s.previous});
  }

  function bountyCandidateValue(data,event,history,rooms){
    const targets=asIds(event?.bountyTargets);if(!targets.length||rooms<=0)return{p:0,expected:0};
    let model=0;for(const id of targets)model=Math.max(model,targetReachProbability(data,id,history,rooms));
    const stat=research(data).bountyReach?.[Number(event.id)];if(stat){const n=Math.max(0,num(stat.n,0)),emp=clamp(num(stat.pTarget,model));const weight=n/(n+8);model=weight*emp+(1-weight)*model;}
    return{p:clamp(model),expected:clamp(model)*num(event.bountyBonus,10)};
  }

  function expectedMissionValue(data,missionId,history,rooms){
    const m=data.missions?.[Number(missionId)];if(!m||rooms<=0)return 0;const s=missionState(data,missionId,history);if(s.completed)return 0;
    if(m.type==='once'){
      const c=asIds(m.chain),progress=num(s.progress,0),remaining=c.slice(progress);if(!remaining.length)return 0;const prev=progress>0?c[progress-1]:null,p=sequenceProbability(data,remaining,rooms,{primary:true,previous:prev});let gain=0;for(const id of remaining)gain+=num(data.events?.[id]?.points,0);gain+=num(m.successBonus,0);const fail=Math.min(0,num(m.failurePenalty,0));return p*gain+(1-p)*fail;
    }
    if(m.type==='repeatWhole'){
      const c=asIds(m.chain),remaining=c.slice(num(s.progress,0)),prev=s.progress>0?c[s.progress-1]:null,p=sequenceProbability(data,remaining,rooms,{primary:true,previous:prev});let gain=remaining.reduce((a,id)=>a+num(data.events?.[id]?.points,0),0)+num(m.perCompletionBonus,0);return p*gain;
    }
    if(m.type==='unlockRepeatTail'){
      const c=asIds(m.chain),tail=Number(m.tailEventId||c[c.length-1]);if(s.unlocked){const max=limit(m,'tailMax','unlimitedTail',99),left=Number.isFinite(max)?Math.max(0,max-num(s.tailCount,0)):rooms;const p=offerRate(data,tail),expected=Math.min(left,rooms*p*1.35);return expected*(num(data.events?.[tail]?.points,0)+num(m.perCompletionBonus,0));}
      const prefix=c.slice(0,-1),remaining=prefix.slice(num(s.prefixProgress,0)),prev=s.prefixProgress>0?prefix[s.prefixProgress-1]:null;remaining.push(tail);const p=sequenceProbability(data,remaining,rooms,{primary:true,previous:prev});const gain=remaining.reduce((a,id)=>a+num(data.events?.[id]?.points,0),0)+num(m.perCompletionBonus,0);return p*gain;
    }
    if(m.type==='repeatedCount'){
      const missing=Math.max(0,Math.max(1,num(m.requiredCount,1))-num(s.count,0));if(!missing)return 0;const p=primaryMissionHazard(data,m.eventId);const expected=Math.min(missing,rooms*p);const completion=sequenceProbability(data,Array(missing).fill(Number(m.eventId)),rooms,{primary:true});return expected*num(data.events?.[m.eventId]?.points,0)+completion*num(m.successBonus,0)+(1-completion)*Math.min(0,num(m.failurePenalty,0));
    }
    if(m.type==='singleRepeat'){
      const max=limit(m,'maxCompletions','unlimitedCompletions',10),left=Number.isFinite(max)?Math.max(0,max-num(s.count,0)):rooms;return Math.min(left,rooms*primaryMissionHazard(data,m.eventId))*(num(data.events?.[m.eventId]?.points,0)+num(m.perCompletionBonus,0));
    }
    return 0;
  }

  function applyTreasureChoice(t,eventId){const n={...t};if(Number(eventId)===131){if(!n.keyHeld){n.keyHeld=true;n.keyCount++;}}else if(Number(eventId)===132&&n.keyHeld){n.chestCount++;n.keyHeld=false;}return n;}
  function treasureCompletionProbability(data,state,rooms,targetChests=2){
    rooms=Math.max(0,Math.floor(num(rooms,0)));const need=Math.max(0,targetChests-num(state.chestCount,0));if(!need)return 1;if(!rooms)return 0;
    const keyHaz=clamp(Math.max(offerRate(data,131),0.20),0.12,0.45),chestHaz=clamp(num(research(data).treasure?.chestHazardAfterKey,0.24),0.12,0.45),memo=new Map();
    function rec(r,key,n){if(n<=0)return 1;if(r<=0)return 0;const k=`${r}|${key?1:0}|${n}`;if(memo.has(k))return memo.get(k);let out;if(key)out=chestHaz*rec(r-1,false,n-1)+(1-chestHaz)*rec(r-1,true,n);else out=keyHaz*rec(r-1,true,n)+(1-keyHaz)*rec(r-1,false,n);memo.set(k,out);return out;}
    return clamp(rec(rooms,Boolean(state.keyHeld),need));
  }

  function genericUnlockValue(data,event,history,rooms){
    const next=asIds(event?.nextEventIds);if(!next.length||rooms<=0)return{value:0,p:0};let best=0,bestP=0;for(const id of next){const p=targetReachProbability(data,id,[...(history||[]),Number(event.id)],rooms),pts=Math.max(0,num(data.events?.[id]?.points,0));const v=p*pts;if(v>best){best=v;bestP=p;}}return{value:best,p:bestP};
  }

  function scoreOption(data,context,option,mode='EXP'){
    mode=String(mode).toUpperCase()==='GOLD'?'GOLD':'EXP';
    const history=context.history||[],heroism=num(context.heroism,0),round=Math.max(1,num(context.round,1)),roomsAfter=Math.max(0,10-round),event=eventData(data,option.eventId,option.serverPoints),mission=data.missions?.[Number(context.missionId)]||null,ms=missionState(data,context.missionId,history),treasure=buildTreasureState(history),bounty=bountyProgress(data,history),activeBounty=bounty.active;
    const settlementBefore=missionSettlement(data,context.missionId,history,roomsAfter+1),basePoints=num(option.serverPoints,event.points),missionBonus=currentMissionBonus(mission,ms,event.id),bountyBonus=activeBounty?.bountyTargets?.some(t=>Number(t)===event.id)?num(activeBounty.bountyBonus,10):0,immediate=basePoints+missionBonus+bountyBonus,projected=heroism+immediate;
    const afterHistory=[...history,Number(event.id)],settlementAfter=missionSettlement(data,context.missionId,afterHistory,roomsAfter),deferredMissionBonus=Math.max(0,num(settlementAfter.bonus,0)-num(settlementBefore.bonus,0)),projectedFinalHeroism=projected+num(settlementAfter.net,0);
    const nextChoices=[1,2,3].includes(Number(event.nextChoiceCount))?Number(event.nextChoiceCount):3,p40=futureThresholdProbability(data,projectedFinalHeroism,roomsAfter,40,nextChoices),p30=futureThresholdProbability(data,projectedFinalHeroism,roomsAfter,30,nextChoices);
    const missionBefore=expectedMissionValue(data,context.missionId,history,roomsAfter+1),missionAfter=expectedMissionValue(data,context.missionId,afterHistory,roomsAfter),missionDelta=missionAfter-missionBefore;
    const afterTreasure=applyTreasureChoice(treasure,event.id),pTreasure=treasureCompletionProbability(data,afterTreasure,roomsAfter,2),unlock=genericUnlockValue(data,event,history,roomsAfter);
    let score=basePoints*26+missionBonus*34+deferredMissionBonus*34+num(settlementAfter.penalty,0)*30+bountyBonus*38+missionDelta*18+unlock.value*5;const reasons=[];

    const occurrenceLimit=event.unlimitedOccurrences===true?Infinity:(Number.isFinite(Number(event.maxOccurrences))?Math.max(0,Number(event.maxOccurrences)):Infinity);if(Number.isFinite(occurrenceLimit)&&countOf(history,event.id)>=occurrenceLimit){score-=100000;reasons.push(`Limit ${occurrenceLimit}/${occurrenceLimit} erreicht`);}
    if(basePoints)reasons.push(`${basePoints>=0?'+':''}${basePoints} Heldentum`);if(missionBonus)reasons.push(`Missionsbonus sofort +${missionBonus}`);if(deferredMissionBonus)reasons.unshift(`Missionsbonus am Ende +${deferredMissionBonus}`);else if(settlementBefore.bonus>0)reasons.push(`Missionsbonus am Ende +${settlementBefore.bonus} sicher`);if(settlementAfter.penalty<0)reasons.push(`Missionsstrafe am Ende ${settlementAfter.penalty}`);if(bountyBonus)reasons.push(`Kopfgeld +${bountyBonus}`);

    const missionIsNext=!ms.completed&&Number(ms.nextEventId)===Number(event.id);if(missionIsNext){const mAfter=expectedMissionValue(data,context.missionId,afterHistory,roomsAfter);score+=65+Math.max(0,mAfter)*8;reasons.push('richtiger Missionsschritt');}else if(missionDelta<-1){reasons.push('kostet Missionschance');}
    if(unlock.value>=2){score+=25;reasons.push(`öffnet Folgeereignis (~${Math.round(unlock.p*100)}%)`);}

    if(event.bountyTargets?.length){
      if(bounty.picked>=bounty.max){score-=100000;reasons.push(`Kopfgeld-Limit ${bounty.max}/${bounty.max}`);}else{
        const b=bountyCandidateValue(data,event,afterHistory,roomsAfter);let expected=b.expected;if(activeBounty){const oldTarget=Math.max(...asIds(activeBounty.bountyTargets).map(id=>targetReachProbability(data,id,history,roomsAfter+1)),0);expected-=oldTarget*num(activeBounty.bountyBonus,10);reasons.push('ersetzt offenes Kopfgeld');}
        score+=expected*32+Math.max(0,b.p-0.45)*70;reasons.push(`Kopfgeld-Ziel ~${Math.round(b.p*100)}% erreichbar`);
      }
    }

    const expected3=num(research(data).choiceExpectedMax?.['3'],3.93),expectedNext=num(research(data).choiceExpectedMax?.[String(nextChoices)],expected3),choiceCost=Math.max(0,expected3-expectedNext);if(choiceCost>0.4){score-=choiceCost*24;reasons.push(`danach nur ${nextChoices} Auswahl${nextChoices===1?'':'en'}`);}

    const bestVisible=Math.max(...(context.options||[]).map(o=>num(o.serverPoints,0)),basePoints),pointCost=Math.max(0,bestVisible-basePoints);
    if(mode==='EXP'){
      score+=p40*1450+p30*90;
      if(heroism+num(settlementBefore.bonus,0)>=40){score+=250;reasons.push(settlementBefore.bonus>0?'3 Sterne inkl. Endbonus bereits sicher':'3 Sterne bereits sicher');}
      else reasons.push(`40-Punkte-Chance ~${Math.round(p40*100)}%`);
      if(treasure.chestCount<2){
        if(event.treasureType==='chest'){
          if(!treasure.keyHeld){score-=500;reasons.push('Truhe ohne Schlüssel');}
          else if(p40>=0.72||projectedFinalHeroism>=40){score+=360;reasons.unshift('optionale Schatztruhe ohne großes EXP-Risiko');}else{score-=220;reasons.push('Truhe gefährdet 40 Punkte');}
        }else if(event.treasureType==='key'){
          if(treasure.keyHeld){score-=150;reasons.push('Schlüssel bereits vorhanden');}
          else if(roomsAfter>=6&&pointCost<=1){score+=390+140*pTreasure;reasons.unshift('früher Schlüssel kostet kaum Punkte');}
          else if(roomsAfter>=4&&pointCost<=2&&p40>=0.45){score+=230+120*pTreasure;reasons.unshift('Schlüssel mit vertretbarem Punkteverlust');}
          else if(roomsAfter<=3&&p40<0.55){score-=180;reasons.push('für Schlüssel ist es zu spät/riskant');}
        }else if(p40>=0.82&&pTreasure>0.25)score+=pTreasure*70;
      }
    }else{
      if(treasure.chestCount>=2){score+=p40*1250+p30*120;reasons.push('2 Truhen erreicht → Punkte priorisieren');}
      else{
        score+=pTreasure*1900+p30*520+p40*410;
        reasons.push(`2-Truhen-Chance ~${Math.round(pTreasure*100)}%`);
        if(event.treasureType==='chest'){
          if(!treasure.keyHeld){score-=650;reasons.push('Truhe ohne Schlüssel');}
          else{score+=1050;reasons.unshift('Schatztruhe hat GOLD-Priorität');}
        }else if(event.treasureType==='key'){
          if(treasure.keyHeld){score-=220;reasons.push('Schlüssel bereits vorhanden');}
          else if(roomsAfter>=1){score+=680-Math.min(260,pointCost*55);reasons.unshift('Schlüssel für GOLD-Ziel');}
        }
        if(p30<0.45)score-=(0.45-p30)*850;
      }
    }

    // Tie breaker: immediate game points, then stable position.
    score+=basePoints*0.02;
    return{position:Number(option.position),eventId:Number(option.eventId),name:event.name,serverPoints:basePoints,projectedHeroism:projected,projectedFinalHeroism,score,reasons:[...new Set(reasons)].slice(0,6),missionBonus,deferredMissionBonus,pendingMissionBonus:num(settlementAfter.bonus,0),missionEndPenalty:num(settlementAfter.penalty,0),bountyBonus,treasureType:event.treasureType||null,p40,p30,pTreasure,missionExpectedDelta:missionDelta};
  }

  function recommend(data,context,mode='EXP'){mode=String(mode).toUpperCase()==='GOLD'?'GOLD':'EXP';const options=Array.isArray(context?.options)?context.options:[];if(!options.length)return{mode,best:null,evaluated:[]};const evaluated=options.map(o=>scoreOption(data,context,o,mode)).sort((a,b)=>Math.abs(b.score-a.score)>.0001?b.score-a.score:a.position-b.position);return{mode,best:evaluated[0]||null,evaluated,researchRuns:num(data?.research?.cleanRuns,0)};}
  return{version:'0.3.2-research',recommend,missionState,missionSettlement,bountyState,bountyProgress,buildTreasureState,scoreOption,targetReachProbability,futureThresholdProbability,treasureCompletionProbability};
});
