(() => {
  'use strict';
  if (globalThis.__SF_SUPPORT_CHARACTER__) return;
  globalThis.__SF_SUPPORT_CHARACTER__ = true;

  let player = null;
  let server = '';
  const listeners = new Set();

  function injectPageHook() {
    if (document.documentElement.dataset.sfSupportPageHook === '1') return;
    document.documentElement.dataset.sfSupportPageHook = '1';
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('page-hook.js');
    script.async = false;
    script.onload = () => script.remove();
    (document.head || document.documentElement).appendChild(script);
  }

  function notify() {
    for (const listener of listeners) {
      try { listener(player); } catch (error) { console.error(error); }
    }
  }

  window.addEventListener('message', event => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== 'SF_COMBAT_ADVISOR') return;

    if (data.type === 'SERVER_CONTEXT') {
      const nextServer = String(data.server || '').trim().toLowerCase();

      const isConcreteSfServer =
        nextServer &&
        (
          nextServer.endsWith('.sfgame.eu') ||
          nextServer.endsWith('.sfgame.net')
        ) &&
        ![
          'sfgame.eu',
          'www.sfgame.eu',
          'sfgame.net',
          'www.sfgame.net',
          'cdn.sfgame.net',
          'cdn.sfgame.eu'
        ].includes(nextServer);

      if (isConcreteSfServer) {
        server = nextServer;

        if (player) {
          player = { ...player, server };
          notify();
        }
      }

      return;
    }

    if (data.type !== 'MY_PLAYER') return;
    if (!data.player) return;

    player = {
      ...data.player,
      ...(server ? { server } : {})
    };

    notify();
  });

  globalThis.SFSupportCharacter = {
    getPlayer: () => player,
    subscribe(listener) {
      listeners.add(listener);
      if (player) listener(player);
      return () => listeners.delete(listener);
    }
  };

  injectPageHook();
})();
